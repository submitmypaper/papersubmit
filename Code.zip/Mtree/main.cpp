#include<iostream>
#include<stdio.h>
#include"Test.h"
#include"TStream.h"
#include"mTree.h"
#include<fstream>
#pragma warning(disable:4996)
using namespace std;

int main() {

	clock_t startTime, endTime, initTime, createTime;
	for (int j = 0; j < 5; j++) {
		Test t;
		TStream tstream;
		vector<Test> vecTestFile;
		t.Init(vecTestFile,j);
		tstream.Init(vecTestFile[0],j);
		for (int i = 0; i < vecTestFile.size(); i++) {
			mTree mtree;
			mtree.SetmaxNodeNum(8);
			tstream.SetDataStreamBegin(0);
			tstream.SetDataStreamTag(vecTestFile[i].GetWindowSize() / vecTestFile[i].GetDimension());
			startTime = clock();
			mTree::Node* root = mtree.InitMtree(tstream, vecTestFile[i]);
			endTime = clock();
			createTime = (double)(endTime - startTime) / CLOCKS_PER_SEC;
			int dataNum = 0;
			mtree.findNearestNeighborPair(tstream, vecTestFile[i], root, dataNum);
			endTime = clock();
			initTime = (double)(endTime - startTime) / CLOCKS_PER_SEC;
			cout << "Init Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << 's' << endl;

			startTime = clock();
			mtree.updateDataFlow(tstream, vecTestFile[i], root);
			endTime = clock();
			cout << "Running Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
			
			cout << "Process " << 52428800 / ((double)(endTime - startTime) / CLOCKS_PER_SEC) << " data per second " << endl;
		}
	}
	return 0;
}