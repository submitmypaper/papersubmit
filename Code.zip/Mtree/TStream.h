#pragma once
#include <vector>
#include <math.h>
#include"Test.h"
using namespace std;
class TStream {
public:
	TStream();
	~TStream();

	void ReadDataFile(Test& test,int j);
	double GetDataStream(int intObjectNumber);
	vector<double> GetData(int dataId,int dimension);
	int GetDataStreamLength();
	int GetDataStreamBegin();
	int GetDataStreamTag();
	vector<double> GetCentralCoordinate();
	void SetDataStreamBegin(int begin);
	void SetDataStreamTag(int tag);
	void Init(Test& test,int j);
	void AddDataStreamBegin(int outFlow);
	void AddDataStreamTag(int inFlow);
	double GetFirstRadius();


private:
	vector<double> vecDataStream;
	int dataStreamBegin = 0;
	int dataStreamTag = 0;
	vector<double> centralCoordinate;
	double firstRadius = 0;

};