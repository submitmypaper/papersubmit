#pragma once
#include <vector>
#include <list>
#include <queue>
#include <map>
#include <cassert>
#include <math.h>
#include <algorithm>
#include "TStream.h"
#include "Test.h"
#include<stack>
#include <unordered_map>
#include<set>
typedef vector<double> Data;
class mTree {

public:

	struct Node {
		list<int> entryId;
		list<Node*> childrenNode;
		double radius;
		double disToParent;
		vector<double> coordinate;
		Node* parentNode;
		int depth;
		bool bIns=false;
		double maxRadius;
		bool operator==(const Node& node) {
			return ((radius == node.radius) && (coordinate == node.coordinate) && (disToParent == node.disToParent) && (parentNode == node.parentNode));
		}
	};
	mTree();
	~mTree();
	void SetmaxNodeNum(int max_NodeNum);
	int GetmaxNodeNum();
	Node* InitMtree(TStream& tstream, Test& test);
	Node* addNode(TStream& tstream, Test& test,Node* node,int dataId);
	void updateNotLeafNodeRadius(TStream& tstream, Test& test, stack<Node*> stackNode);
	void checkMaxCapacity(TStream& tstream, Test& test,Node* node,Node* &targetNode, int targetId);
	void nodePromotion(TStream& tstream, Test& test,list<Node*> candidateSet, vector<vector<double>>& resultSet);
	void nodePartition(TStream& tstream, Test& test,vector<vector<double>>& promotionNode, Node* node);
	void leafPromotion(TStream& tstream, Test& test, list<int> dataSet, vector<vector<double>>& resultSet);
	void leafPartition(TStream& tstream, Test& test, vector<vector<double>>& promotionNode, Node* node, Node* &targetNode, int targetId);
	double calculateDistanceById(TStream& tstream, Test& test, int id1, int id2);
	double calculateDistanceBycoordinate(TStream& tstream, Test& test, int id, Data data);
	double calculateDistanceBetweenTwoData(TStream& tstream, Test& test, Data data1, Data data2);
	double maxNumInThreeDouble(double d1, double d2, double d3) ;
	void findNearestNeighborPair(TStream& tstream, Test& test, Node* node, int& dataNum);
	double getNeighborRadiusByDataIdAndNode(TStream& tstream, Test& test, Node* node, int id,int& neighborId,int& dataNum);
	void findNeighborInOtherSubTree(TStream& tstream, Test& test, int id, int& neighborId, double& radius, int tstreamBegin, Node* node, int& dataNum);
	bool judgeNodeSame(TStream& tstream, Test& test, Node* node1, Node* node2);
	void Prune(TStream& tstream, Test& test, Node* node, int id, double radius, queue<Node*>& findNeghborSet);
	void insertNNPairSet(TStream& tstream, Test& test, int i1,int neighborId, double distance);
	void insertNodeFunc(TStream& tstream, Test& test, double dis, Node* node, Node* child);
	void addNodeToVec(TStream& tstream, Test& test, vector<double>& subTreecoordinate, int id1, int id2,int& availableNodeNum,double radius);
	void createNode(TStream& tstream, Test& test, vector<double>& subTreecoordinate, Node* node,int i);
	void initRootEntryId(TStream& tstream, Test& test, Node* node);
	void addEntryToChildNode(TStream& tstream, Test& test, Node* node);
	void chooseSubInSurplusEntry(TStream& tstream, Test& test, vector<double>& subTreecoordinate, int availableNodeNum,Node* node);
	bool chooseBestCoordinate(TStream& tstream, Test& test, vector<double>& subTreecoordinate, vector<double>& temNode,double radius);
	void test(TStream& tstream, Test& test, Node* node);
	void addEntryToNode(TStream& tstream, Test& test, int entryId, Node* node, double dis);
	void printlogmain(TStream& tstream, Test& test, int id, int num);
	void updateDataFlow(TStream& tstream, Test& test, Node* node);
	void chooseCoordinateInPromotion(TStream& tstream, Test& test, vector<vector<double>>& resultSet, vector<double>& vec1, vector<double>& vec2);
	void updateNNPairSet(int tstreamBegin);
	void dealExpiredEntry(TStream& tstream, Test& test, Node* node);
	void checkMiddleNode(TStream& tstream, Test& test, Node* node);
	void updateRadiusInTree(TStream& tstream, Test& test, Node* node);
	void createNewLeaf(TStream& tstream, Test& test, Node* node, int dataId, Node* &targetNode);
	void PrintMapSet(Test& test, int datasBegin);

private:
	Node* root;
	int maxNodeNum;
	unordered_map<double, pair<int, int>> nnPairSet;
};