#include <vector>
#include <list>
#include <queue>
#include <map>
#include <set>
#include <cassert>
#include <math.h>
#include <algorithm>
#include "TStream.h"
#include "mTree.h"
#include<stack>
#include<unordered_map>
#include <numeric> 
#include<fstream>
#define checkCapacity 10240
int leafNodeNum = 0;
int notleafNodeNum = 0;
int maxdepth = 0;
int findleafnum = 0;

mTree::mTree() {

}

mTree::~mTree(){
}

void mTree::SetmaxNodeNum(int max_NodeNum) {
	maxNodeNum = max_NodeNum;
}

int mTree::GetmaxNodeNum() {
	return maxNodeNum;
}

mTree::Node* mTree::InitMtree(TStream& tstream, Test& test) {
	int dimension = test.GetDimension();
	queue<Node*> needSplitNode;
	root = new Node;
	root->coordinate = tstream.GetCentralCoordinate();
	root->disToParent = 0;
	root->parentNode = nullptr;
	root->radius = tstream.GetFirstRadius();
	root->maxRadius = root->radius;
	root->depth = 0;
	initRootEntryId(tstream, test, root);
	vector<double> subTreeCoordinate;
	needSplitNode.push(root);
	Node* splitNode;
	while (!needSplitNode.empty()) {
		subTreeCoordinate.clear();
		splitNode = needSplitNode.front();
		while (splitNode->entryId.size() != 0) {
			if (splitNode->childrenNode.size() == maxNodeNum * 0.75 ) {
				break;
			}
			chooseSubInSurplusEntry(tstream, test, subTreeCoordinate, maxNodeNum * 0.75  - splitNode->childrenNode.size(), splitNode);
			for (int i = 0; i < subTreeCoordinate.size() / dimension; ++i) {
				createNode(tstream, test, subTreeCoordinate, splitNode, i);
			}
			subTreeCoordinate.clear();
			addEntryToChildNode(tstream, test, splitNode);
		}
		double dis;
		double disMin ;
		Node* node;
		Node* temNode = nullptr;
		while (splitNode->entryId.size() != 0) {
			for (auto id = splitNode->entryId.begin(); id != splitNode->entryId.end();) {
				node = nullptr;
				disMin = DBL_MAX;
				for (auto child : splitNode->childrenNode) {
					dis = calculateDistanceBycoordinate(tstream, test, *id, child->coordinate);
					if (dis < disMin) {
						disMin = dis;
						node = child;
					}
				}
				if (node != nullptr) {
					node->entryId.push_back(*id);
					node->radius = max(node->radius, disMin);
					node->maxRadius = node->radius;
					splitNode->entryId.erase(id++);
				}
			}
		}
		for (auto child = splitNode->childrenNode.begin(); child != splitNode->childrenNode.end();) {
			if ((*child)->childrenNode.size()==0&&(*child)->entryId.size()==0) {
				temNode = *child;
				splitNode->childrenNode.erase(child++);
				delete temNode;
				temNode = nullptr;
				continue;
			}
			child++;
		}
		for (auto child = splitNode->childrenNode.begin(); child != splitNode->childrenNode.end();) {
			if ((*child)->entryId.size() > maxNodeNum) {
				if (splitNode->childrenNode.size() > 1) {
					needSplitNode.push(*child);
				}
			}
			child++;
		}
		needSplitNode.pop();
	}
	return root;
}

void mTree::createNode(TStream& tstream, Test& test, vector<double>& subTreecoordinate, Node* node,int id) {
	int dimension = test.GetDimension();
	Node* childnode = new Node();
	childnode->parentNode = node;
	childnode->maxRadius = node->maxRadius * 0.5;
	for (int i = 0; i < dimension; ++i) {
		childnode->coordinate.push_back(subTreecoordinate[id * dimension + i]);
	}
	childnode->disToParent = calculateDistanceBetweenTwoData(tstream, test, childnode->coordinate, node->coordinate);
	childnode->depth = node->depth + 1;
	if (maxdepth < childnode->depth) {
		maxdepth = childnode->depth;
	}
	node->childrenNode.push_back(childnode);
}

void mTree::findNearestNeighborPair(TStream& tstream, Test& test, Node* node, int& dataNum) {
	queue<Node*> leafNodeQueue;
	Node* queueNode;
	leafNodeQueue.push(node);
	int neighborId;
	double nodeNeighborRadius = 0;
	while (!leafNodeQueue.empty()) {
		queueNode = leafNodeQueue.front();
		if (queueNode->childrenNode.size() == 0) {
			for (auto entryid = queueNode->entryId.begin(); entryid != queueNode->entryId.end(); ++entryid) {
				findleafnum = 0;
				neighborId = -1;
				queueNode->bIns = true;
				nodeNeighborRadius = getNeighborRadiusByDataIdAndNode(tstream, test, queueNode, *entryid, neighborId, dataNum);
				if (nodeNeighborRadius != 0) {
					findNeighborInOtherSubTree(tstream, test, *entryid, neighborId, nodeNeighborRadius, 0, queueNode, dataNum);
				}
				if (neighborId != -1) {
					insertNNPairSet(tstream, test, *entryid, neighborId, nodeNeighborRadius);
				}
			}
		}
		else
		{
			for (auto child : queueNode->childrenNode) {
				leafNodeQueue.push(child);
			}
		}
		leafNodeQueue.pop();
	}
}

double mTree::getNeighborRadiusByDataIdAndNode(TStream& tstream, Test& test, Node* node, int id, int& neighborId, int& dataNum) {
	double minDis = DBL_MAX;
	double dis = DBL_MAX;
	if (node->entryId.size() > 1) {
		for (auto dataid = node->entryId.begin(); dataid != node->entryId.end();) {
			if (*dataid != id) {
				if (*dataid < tstream.GetDataStreamBegin()) {
					node->entryId.erase(dataid++);
					dataNum--;
					continue;
				}
				dis = calculateDistanceById(tstream, test, id, *dataid);
				if (dis < minDis) {
					minDis = dis;
					neighborId = *dataid;
				}
				dataid++;
				continue;
			}
			dataid++;
		}
	}
	if (node->entryId.size() == 1) {
		return node->parentNode->radius;
	}
	return minDis;
}

void mTree::findNeighborInOtherSubTree(TStream& tstream, Test& test, int id, int& neighborId, double& radius, int tstreamBegin, Node* node, int& dataNum) {
	if (node->parentNode == nullptr) {
		return;
	}
	Node* temNode = node->parentNode;
	queue<Node*> parentNodeSet;
	queue<Node*> findNeighborSet;
	parentNodeSet.push(temNode);
	while (temNode->parentNode != nullptr) {
		temNode = temNode->parentNode;
		parentNodeSet.push(temNode);
	}
	Node* intermediateNode;
	Node* getFindNeighborSetNode;
	double dis;
	while (!parentNodeSet.empty()) {
		intermediateNode = parentNodeSet.front();
		for (auto n_Node : intermediateNode->childrenNode) {
			double temdis = (calculateDistanceBycoordinate(tstream, test, id, n_Node->coordinate) - n_Node->radius);
			if (!n_Node->bIns && temdis <= radius) {
				findNeighborSet.push(n_Node);
			}
			n_Node->bIns = false;
		}
		intermediateNode->bIns = true;
		parentNodeSet.pop();
		while (!findNeighborSet.empty()) {
			getFindNeighborSetNode = findNeighborSet.front();
			if (getFindNeighborSetNode->childrenNode.size() == 0) {
				getFindNeighborSetNode->bIns = true;
				for (auto dataid = getFindNeighborSetNode->entryId.begin(); dataid != getFindNeighborSetNode->entryId.end();) {
					if (*dataid < tstream.GetDataStreamBegin()) {
						getFindNeighborSetNode->entryId.erase(dataid++);
						dataNum--;
						continue;
					}
					dis = calculateDistanceById(tstream, test, *dataid, id);
					if (dis < radius) {
						radius = dis;
						neighborId = *dataid;
					}
					dataid++;
				}
			}
			else {
				Prune(tstream, test, getFindNeighborSetNode, id, radius, findNeighborSet);
			}
			getFindNeighborSetNode->bIns = true;
			findNeighborSet.pop();
		}
	}
}

void mTree::Prune(TStream& tstream, Test& test, Node* node, int id, double radius, queue<Node*>& findNeghborSet) {
	double dis;
	for (auto n_Node : node->childrenNode) {
		dis = calculateDistanceBycoordinate(tstream, test, id, n_Node->coordinate) - n_Node->radius;
		if (!n_Node->bIns&&dis <= radius) {
			findNeghborSet.push(n_Node);
		}
		n_Node->bIns = false;
	}
}

void mTree::insertNNPairSet(TStream& tstream, Test& test, int id, int neighborId, double distance) {
	double temdis = distance;
	while (nnPairSet.count(distance)) {
		return; 
	}
	nnPairSet.emplace(distance, make_pair(id, neighborId));
}

double mTree::calculateDistanceById(TStream& tstream, Test& test, int id1, int id2) {
	int dimension = test.GetDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(tstream.GetDataStream(id1 * dimension + i) - tstream.GetDataStream(id2 * dimension + i),2);
	}
	return sqrt(dis);
}

double mTree::calculateDistanceBycoordinate(TStream& tstream, Test& test, int id, Data data) {
	int dimension = test.GetDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(tstream.GetDataStream(id * dimension + i) - data[i], 2);
	}
	return sqrt(dis);
}

double mTree::calculateDistanceBetweenTwoData(TStream& tstream, Test& test, Data data1, Data data2) {
	int dimension = test.GetDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(data1[i] - data2[i], 2);
	}
	return sqrt(dis);
}

double mTree::maxNumInThreeDouble(double d1, double d2, double d3) {
	return d1 > d2 ? (d1 > d3 ? d1 : d3) : (d2 > d3 ? d2 : d3);
}

bool mTree::judgeNodeSame(TStream& tstream, Test& test, Node* node1, Node* node2) {
	if (node1->radius == node2->radius&& node1->coordinate == node2->coordinate&& node1->disToParent==node2->disToParent&& node1->parentNode==node2->parentNode) {
		return true;
	}
	return false;
}

static bool cmp(const vector<double>& v1, const vector<double>& v2) {
	return v1[0] > v2[0];
}

void mTree::initRootEntryId(TStream& tstream, Test& test, Node* node) {
	int dimension = test.GetDimension();
	for (int i = 0; i < test.GetWindowSize() / test.GetDimension(); ++i) {
		node->entryId.push_back(i);
	}
}

void mTree::addEntryToChildNode(TStream& tstream, Test& test, Node* node) {
	Node* chooseNode;
	double dis;
	double minDis;
	for (auto id = node->entryId.begin(); id != node->entryId.end();) {
		minDis = DBL_MAX;
		chooseNode = nullptr;
		for (auto child : node->childrenNode) {
			dis = calculateDistanceBycoordinate(tstream, test, *id, child->coordinate);
			if (dis < minDis && dis<=child->maxRadius) {
				minDis = dis;
				chooseNode = child;
			}
		}
		if (chooseNode != nullptr) {
			chooseNode->entryId.push_back(*id);
			chooseNode->radius = max(chooseNode->radius, minDis);
			node->entryId.erase(id++);
			continue;
		}
		id++;
	}
}

void mTree::chooseSubInSurplusEntry(TStream& tstream, Test& test, vector<double>& subTreecoordinate, int availableNodeNum, Node* node) {
	bool cmp(const vector<double>&v1, const vector<double>&v2);
	int dimension = test.GetDimension();
	double maxNum;
	double minNum;
	vector<vector<double>> dif(dimension, vector<double>(3, 0));
	for (int i = 0; i < dimension; ++i) {
		maxNum = -10;
		minNum = DBL_MAX;
		for (list<int>::iterator j = node->entryId.begin(); j != node->entryId.end(); ++j) {
			double data = tstream.GetDataStream((*j) * dimension + i);
			if (data > maxNum) {
				maxNum = data;
				dif[i][1] = *j;
			}
			if (data < minNum) {
				minNum = data;
				dif[i][2] = *j;
			}
		}
		dif[i][0] = maxNum - minNum;
	}
	sort(dif.begin(), dif.end(), cmp);
	set<double> flagNodeSet;
	for (int i = 0; i < dimension; ++i) {
		if (!flagNodeSet.count(dif[i][1]) && !flagNodeSet.count(dif[i][2])&&availableNodeNum>0) {
			flagNodeSet.insert(dif[i][1]);
			flagNodeSet.insert(dif[i][2]);
			addNodeToVec(tstream, test, subTreecoordinate, (int)dif[i][1], (int)dif[i][2], availableNodeNum, node->radius);
		}
	}
}

void mTree::addNodeToVec(TStream& tstream, Test& test, vector<double>& subTreecoordinate, int id1, int id2, int& availableNodeNum, double radius) {
	int dimension = test.GetDimension();
	double c1 = 0;
	double c2 = 0;
	vector<double> temNode(dimension);
	if (subTreecoordinate.size() == 0) {
		for (int i = 0; i < dimension; ++i) {
			c1 = tstream.GetDataStream(id1 * dimension + i);
			c2 = tstream.GetDataStream(id2 * dimension + i);
			subTreecoordinate.push_back((3 * c1 + c2) / 4);
		}
		availableNodeNum--;
		if (availableNodeNum == 0) {
			return;
		}
		for (int i = 0; i < dimension; ++i) {
			c1 = tstream.GetDataStream(id1 * dimension + i);
			c2 = tstream.GetDataStream(id2 * dimension + i);
			subTreecoordinate.push_back((c1 + 3 * c2) / 4);
		}
		availableNodeNum--;
	}
	else {
		for (int i = 0; i < dimension; ++i) {
			c1 = tstream.GetDataStream(id1 * dimension + i);
			c2 = tstream.GetDataStream(id2 * dimension + i);
			temNode.push_back((3 * c1 + c2) / 4);
		}
		if (chooseBestCoordinate(tstream, test, subTreecoordinate, temNode, radius)) {
			for (int i = 0; i < dimension; ++i) {
				subTreecoordinate.push_back(temNode[i]);
			}
			availableNodeNum--;
		}
		temNode.clear();
		if (availableNodeNum == 0) {
			return;
		}
		for (int i = 0; i < dimension; ++i) {
			c1 = tstream.GetDataStream(id1 * dimension + i);
			c2 = tstream.GetDataStream(id2 * dimension + i);
			temNode.push_back((c1 + 3 * c2) / 4);
		}
		if (chooseBestCoordinate(tstream, test, subTreecoordinate, temNode, radius)) {
			for (int i = 0; i < dimension; ++i) {
				subTreecoordinate.push_back(temNode[i]);
			}
			availableNodeNum--;
		}
	}
}

bool mTree::chooseBestCoordinate(TStream& tstream, Test& test, vector<double>& subTreecoordinate, vector<double>& temNode,double radius) {
	double dis = 0;
	int dimension = test.GetDimension();
	for (int i = 0; i < subTreecoordinate.size() / dimension; ++i) {
		dis = 0;
		for (int j = 0; j < dimension; ++j) {
			dis += pow((subTreecoordinate[i * dimension + j] - temNode[j]), 2);
		}
		if (sqrt(dis) <= radius / 2) {
			return false;
		}
	}
	return true;
}

void mTree::updateDataFlow(TStream& tstream, Test& test, Node* node) {
	int dimension = test.GetDimension();
	int windowSize = test.GetWindowSize() / dimension;
	tstream.SetDataStreamTag(windowSize);
	tstream.SetDataStreamBegin(0);
	int newEntryId = tstream.GetDataStreamTag();
	int neighborId = -1;
	double queryRadius = 0;
	int entryNum = windowSize;
	int entryNum1 = windowSize;
	clock_t startTime1, endTime1;
	Node* chooseNode;
	for (; tstream.GetDataStreamTag() < 52428800+ windowSize;) {
		tstream.AddDataStreamBegin(1);
		tstream.AddDataStreamTag(1);
		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 1)
		{
			startTime1 = clock();
		}
		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 0 && tstream.GetDataStreamTag() >= 1048576)
		{
			endTime1 = clock();
			cout << "Current cursor:" << tstream.GetDataStreamTag() << "     Time = " << (double)(endTime1 - startTime1) / CLOCKS_PER_SEC << "s" << endl;
		}

		if ((tstream.GetDataStreamTag() - tstream.GetDataStreamBegin()) >= 10 * (test.GetWindowSize() / test.GetDimension()))
		{
			tstream.SetDataStreamBegin(tstream.GetDataStreamTag() - (test.GetWindowSize() / test.GetDimension()));
		}

		if ((tstream.GetDataStreamTag() - tstream.GetDataStreamBegin()) <= 0.1 * (test.GetWindowSize() / test.GetDimension()))
		{
			tstream.SetDataStreamTag(tstream.GetDataStreamBegin() + (test.GetWindowSize() / test.GetDimension()));
			if (tstream.GetDataStreamTag() > tstream.GetDataStreamLength() / test.GetDimension())
			{
				tstream.SetDataStreamTag(tstream.GetDataStreamLength() / test.GetDimension());
			}
		}
		entryNum++;
		entryNum1++;
		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 0) {
			updateNNPairSet(tstream.GetDataStreamBegin());
		}
		if (entryNum > 1.2 * windowSize) {
			dealExpiredEntry(tstream, test, node);
			checkMiddleNode(tstream, test, node);
			updateRadiusInTree(tstream, test, node);
			entryNum = windowSize;
		}
		for (int i = newEntryId; i < tstream.GetDataStreamTag(); i++)
		{
			queryRadius = 0;
			neighborId = -1;
			chooseNode = addNode(tstream, test, node, i);
			chooseNode->bIns = true;
			queryRadius = getNeighborRadiusByDataIdAndNode(tstream, test, chooseNode, i, neighborId, entryNum);
			if (queryRadius != 0) {
				findNeighborInOtherSubTree(tstream, test, i, neighborId, queryRadius, tstream.GetDataStreamBegin(), chooseNode, entryNum);
			}
			if (neighborId != -1) {
				insertNNPairSet(tstream, test, i, neighborId, queryRadius);
			}
			chooseNode = nullptr;
		}
		newEntryId = tstream.GetDataStreamTag();
	}
}




mTree::Node* mTree::addNode(TStream& tstream, Test& test, Node* node, int dataId) {
	Node* temNode = node;
	stack<Node*> stackNode;
	double minDis = DBL_MAX;
	double minToIncrease = DBL_MAX;
	double disToLeafNode;
	Node* nodeTemInRadius = nullptr; 
	Node* nodeTemToIncress = nullptr;
	Node* targetNode=nullptr;
	while (1) {
		minDis = DBL_MAX;
		minToIncrease = DBL_MAX;
		nodeTemInRadius = nullptr;
		nodeTemToIncress = nullptr;
		if (temNode->childrenNode.size() == 0) {
			temNode->entryId.push_back(dataId);
			disToLeafNode = calculateDistanceBycoordinate(tstream, test, dataId, temNode->coordinate);
			if (temNode->radius < disToLeafNode) {
				disToLeafNode < temNode->maxRadius ? (temNode->radius = disToLeafNode) : (temNode->radius = temNode->maxRadius);
			}
			targetNode = temNode;
			break;
		}
		else {
			for (auto c : temNode->childrenNode) {
				double disTochildrenNode = calculateDistanceBycoordinate(tstream, test, dataId, c->coordinate);
				if (disTochildrenNode <= c->radius && disTochildrenNode < minDis) {
					nodeTemInRadius = c;
					minDis = disTochildrenNode;
				}
				else {
					double increase = disTochildrenNode - c->radius;
					if (increase < minToIncrease && disTochildrenNode < c->maxRadius) {
						nodeTemToIncress = c;
						minToIncrease = increase;
					}
				}
			}
			if (nodeTemInRadius == nullptr && nodeTemToIncress == nullptr) {
				createNewLeaf(tstream, test, temNode, dataId, targetNode);
				break;
			}
			else {
				if (nodeTemInRadius != nullptr) {
					temNode = nodeTemInRadius;
				}
				else {
					stackNode.push(temNode);
					temNode = nodeTemToIncress;
				}
			}
			
		}
	}
	updateNotLeafNodeRadius(tstream, test, stackNode);
	checkMaxCapacity(tstream, test, temNode, targetNode, dataId);
	return targetNode;
}

void mTree::createNewLeaf(TStream& tstream, Test& test, Node* node, int dataId, Node* &targetNode) {
	int dimension = test.GetDimension();
	Node* newLeafNode = new Node();
	newLeafNode->entryId.push_back(dataId);
	newLeafNode->radius = 0;
	newLeafNode->disToParent = calculateDistanceBycoordinate(tstream, test, dataId, node->coordinate);
	newLeafNode->coordinate = tstream.GetData(dataId, dimension);
	newLeafNode->parentNode = node;
	newLeafNode->maxRadius = node->maxRadius * 0.5;
	newLeafNode->depth = node->depth + 1;
	node->childrenNode.push_back(newLeafNode);
	if (node != root) {
		if (node->radius < newLeafNode->disToParent) {
			newLeafNode->disToParent < node->maxRadius ? (node->radius = newLeafNode->disToParent) : (node->radius = node->maxRadius);
		}
	}
	targetNode = newLeafNode;
}

void mTree::updateNotLeafNodeRadius(TStream& tstream, Test& test, stack<Node*> stackNode) {
	Node* node;
	while (!stackNode.empty()) {
		node = stackNode.top();
		if (!(node == root)) {
			for (auto nodeChild : node->childrenNode) {
				if ((nodeChild->disToParent + nodeChild->radius) > node->maxRadius) {
					node->radius = node->maxRadius;
				}
				else {
					node->radius = max(node->radius, nodeChild->disToParent + nodeChild->radius);
				}
			}
		}
		stackNode.pop();
	}
}

void mTree::checkMaxCapacity(TStream& tstream, Test& test, Node* node,Node* &targetNode,int targetId) {
	Node* tem;
	vector<vector<double>> newNodeSplit;
	vector<vector<double>> newLeafSplit;
	while (1) {
		if (node == nullptr) {
			break;
		}
		if (node->childrenNode.size() != 0 && node->childrenNode.size() > maxNodeNum) {
			nodePromotion(tstream, test, node->childrenNode, newNodeSplit);
			nodePartition(tstream, test, newNodeSplit, node);
			tem = node;
			node = node->parentNode;
			if (node != nullptr) {
				node->childrenNode.remove(tem);
				delete tem;
				tem = nullptr;
			}
			continue;
		}
		if (node->entryId.size() != 0 && node->entryId.size() > maxNodeNum) {
			leafPromotion(tstream, test, node->entryId, newLeafSplit);
			leafPartition(tstream, test, newLeafSplit, node, targetNode, targetId);
			tem = node;
			node = node->parentNode;
			if (node != nullptr) {
				node->childrenNode.remove(tem);
				delete tem;
				tem = nullptr;
			}
			continue;
		}
		break;
	}
}

void mTree::nodePromotion(TStream& tstream, Test& test, list<Node*> candidateSet, vector<vector<double>>& resultSet) {
	resultSet.clear();
	int dimension = test.GetDimension();
	vector<double> minnum(dimension, DBL_MAX);
	vector<double> maxnum(dimension, 0.0);
	vector<pair<double, vector<double>>> minDimension(dimension);
	vector<pair<double, vector<double>>> maxDimension(dimension);
	for (auto child : candidateSet) {
		for (int i = 0; i < dimension; ++i) {
			if (child->coordinate[i] < minnum[i]) {
				minnum[i] = child->coordinate[i];
				minDimension[i] = make_pair(child->coordinate[i], child->coordinate);
			}
			if (child->coordinate[i] > maxnum[i]) {
				maxnum[i] = child->coordinate[i];
				maxDimension[i] = make_pair(child->coordinate[i], child->coordinate);
			}
		}
	}
	double differenceValue = 0;
	int key = 0;
	for (int i = 0; i < dimension; ++i) {
		if (maxDimension[i].first - minDimension[i].first > differenceValue) {
			key = i;
			differenceValue = maxDimension[i].first - minDimension[i].first;
		}
	}
	chooseCoordinateInPromotion(tstream, test, resultSet, maxDimension[key].second, minDimension[key].second);
}

void mTree::nodePartition(TStream& tstream, Test& test, vector<vector<double>>& promotionNode, Node* node) {
	Node* node1 = new Node();
	Node* node2 = new Node();
	node1->coordinate = promotionNode[0];
	node2->coordinate = promotionNode[1];
	Node* temParentNode;
	double maxR;
	if (node->parentNode != nullptr) {
		temParentNode = node->parentNode;
	}
	else {
		temParentNode = node;
	}
	node1->disToParent = calculateDistanceBetweenTwoData(tstream, test, temParentNode->coordinate, node1->coordinate);
	node2->disToParent = calculateDistanceBetweenTwoData(tstream, test, temParentNode->coordinate, node2->coordinate);
	node1->parentNode = temParentNode;
	node2->parentNode = temParentNode;
	node1->maxRadius = temParentNode->maxRadius * 0.5;
	node2->maxRadius = temParentNode->maxRadius * 0.5;
	node1->depth = temParentNode->depth + 1;
	node2->depth = temParentNode->depth + 1;
	for (auto child : node->childrenNode) {
		double dis1 = calculateDistanceBetweenTwoData(tstream, test, child->coordinate, node1->coordinate);
		double dis2 = calculateDistanceBetweenTwoData(tstream, test, child->coordinate, node2->coordinate);
		dis1 <= dis2 ? insertNodeFunc(tstream, test, dis1, node1, child) : insertNodeFunc(tstream, test, dis2, node2, child);
	}
	if (node->parentNode == nullptr) {
		node->childrenNode.clear();
	}
	temParentNode->childrenNode.push_back(node1);
	temParentNode->childrenNode.push_back(node2);
	if (!(temParentNode == root)) {
		maxR = maxNumInThreeDouble(temParentNode->radius, node1->disToParent + node1->radius, node2->disToParent + node2->radius);
		if (temParentNode->radius < maxR) {
			maxR < temParentNode->maxRadius ? (temParentNode->radius = maxR) : (temParentNode->radius = temParentNode->maxRadius);
		}
	}
}

void mTree::leafPromotion(TStream& tstream, Test& test, list<int> dataSet, vector<vector<double>>& resultSet) {
	resultSet.clear();
	vector<vector<double>> temDataVec;
	int dimension = test.GetDimension();
	for (int i : dataSet) {
		temDataVec.push_back(tstream.GetData(i, dimension));
	}
	vector<double> minnum(dimension, DBL_MAX);
	vector<double> maxnum(dimension, 0.0);
	vector<pair<double, vector<double>>> minDimension(dimension);
	vector<pair<double, vector<double>>> maxDimension(dimension);
	for (vector<double> d : temDataVec) {
		for (int j = 0; j < dimension; ++j) {
			if (d[j] < minnum[j]) {
				minnum[j] = d[j];
				minDimension[j] = make_pair(d[j], d);
			}
			if (d[j] > maxnum[j]) {
				maxnum[j] = d[j];
				maxDimension[j] = make_pair(d[j], d);
			}
		}
	}
	double differenceValue = 0;
	int key = 0;
	for (int j = 0; j < dimension; ++j) {
		if (maxDimension[j].first - minDimension[j].first > differenceValue) {
			key = j;
			differenceValue = maxDimension[j].first - minDimension[j].first;
		}
	}
	chooseCoordinateInPromotion(tstream, test, resultSet, maxDimension[key].second, minDimension[key].second);
}

void mTree::leafPartition(TStream& tstream, Test& test, vector<vector<double>>& promotionNode, Node* node, Node* &targetNode, int targetId) {
	Node* node1 = new Node();
	Node* node2 = new Node();
	node1->coordinate = promotionNode[0];
	node2->coordinate = promotionNode[1];
	Node* temParentNode;
	double maxR;
	if (node->parentNode != nullptr) {
		temParentNode = node->parentNode;
	}
	else {
		temParentNode = node;
	}
	node1->disToParent = calculateDistanceBetweenTwoData(tstream, test, temParentNode->coordinate, node1->coordinate);
	node2->disToParent = calculateDistanceBetweenTwoData(tstream, test, temParentNode->coordinate, node2->coordinate);
	node1->parentNode = temParentNode;
	node2->parentNode = temParentNode;
	node1->maxRadius = temParentNode->maxRadius * 0.5;
	node2->maxRadius = temParentNode->maxRadius * 0.5;
	node1->depth = temParentNode->depth + 1;
	node2->depth = temParentNode->depth + 1;
	for (int x : node->entryId) {
		double dis1 = calculateDistanceBycoordinate(tstream, test, x, node1->coordinate);
		double dis2 = calculateDistanceBycoordinate(tstream, test, x, node2->coordinate);
		dis1 <= dis2 ? addEntryToNode(tstream, test, x, node1, dis1) : addEntryToNode(tstream, test, x, node2, dis2);
		if (x == targetId) {
			dis1 <= dis2 ? (targetNode = node1) : (targetNode = node2);
		}
	}
	if (node->parentNode == nullptr) {
		temParentNode->entryId.clear();
	}
	temParentNode->childrenNode.push_back(node1);
	temParentNode->childrenNode.push_back(node2);
	if (!(temParentNode == root)) {
		maxR = maxNumInThreeDouble(temParentNode->radius, node1->disToParent + node1->radius, node2->disToParent + node2->radius);
		if (temParentNode->radius < maxR) {
			maxR < temParentNode->maxRadius ? (temParentNode->radius = maxR) : (temParentNode->radius = temParentNode->maxRadius);
		}
	}
}

void mTree::insertNodeFunc(TStream& tstream, Test& test, double dis, Node* node, Node* child) {
	node->childrenNode.push_back(child);
	child->parentNode = node;
	child->disToParent = dis;
	child->depth = node->depth + 1;
	node->radius = max(node->radius, dis + child->radius);
	node->maxRadius = node->radius;

}

void mTree::addEntryToNode(TStream& tstream, Test& test, int entryId, Node* node, double dis) {
	node->entryId.push_back(entryId);
	node->radius = max(node->radius, dis);
	node->maxRadius = node->radius;
}

void mTree::chooseCoordinateInPromotion(TStream& tstream, Test& test, vector<vector<double>>& resultSet, vector<double>& vec1, vector<double>& vec2) {
	int dimension = test.GetDimension();
	vector<double> temvec;
	for (int i = 0; i < dimension; ++i) {
		temvec.push_back((3 * vec1[i] + vec2[i]) / 4);
	}
	resultSet.push_back(temvec);
	temvec.clear();
	for (int i = 0; i < dimension; ++i) {
		temvec.push_back((vec1[i] + 3 * vec2[i]) / 4);
	}
	resultSet.push_back(temvec);
}




void mTree::updateNNPairSet(int tstreamBegin) {
	for (auto nnpair = nnPairSet.begin(); nnpair != nnPairSet.end();) {
		if (nnpair->second.first < tstreamBegin || nnpair->second.second < tstreamBegin) {
			nnPairSet.erase(nnpair++);
		}
		else {
			nnpair++;
		}
	}
}

void mTree::dealExpiredEntry(TStream& tstream, Test& test, Node* node) {
	int dimension = test.GetDimension();
	queue<Node*> treeNodequeue;
	treeNodequeue.push(node);
	Node* temTreeNode;
	while (!treeNodequeue.empty()) {
		temTreeNode = treeNodequeue.front();
		if (temTreeNode->childrenNode.size() == 0 && temTreeNode->entryId.size() != 0) {
			for (auto dataId = temTreeNode->entryId.begin(); dataId != temTreeNode->entryId.end();) {
				if (*dataId < tstream.GetDataStreamBegin()) {
					temTreeNode->entryId.erase(dataId++);
					continue;
				}
				else {
					break;
				}
			}
		}
		if (temTreeNode->childrenNode.size() != 0 && temTreeNode->entryId.size() == 0) {
			for (auto child : temTreeNode->childrenNode) {
				treeNodequeue.push(child);
			}
		}
		if (temTreeNode->childrenNode.size() == 0 && temTreeNode->entryId.size() == 0) {
			temTreeNode->parentNode->childrenNode.remove(temTreeNode);
			delete temTreeNode;
			temTreeNode = nullptr;
		}
		treeNodequeue.pop();
	}
}

void mTree::checkMiddleNode(TStream& tstream, Test& test, Node* node) {

	set<Node*> checkSet;
	stack<Node*> checkStack;
	checkStack.push(node);
	Node* temNode = nullptr;
	Node* temParentNode = nullptr;
	double dis = 0;
	while (!checkStack.empty()) {
		temNode = checkStack.top();
		if (!checkSet.count(temNode)) {
			if (temNode->childrenNode.size() != 0) {
				for (auto child : temNode->childrenNode) {
					checkStack.push(child);
				}	
			}
			else if (temNode->entryId.size() == 0) {
				temParentNode = temNode->parentNode;
				temParentNode->childrenNode.remove(temNode);
				delete temNode;
				temNode = nullptr;
				temParentNode = nullptr;
				checkStack.pop();
				continue;
			}
			checkSet.insert(temNode);
		}
		else {
			if (temNode->childrenNode.size() == 0 && temNode->entryId.size() == 0) {
				temParentNode = temNode->parentNode;
				temParentNode->childrenNode.remove(temNode);
				delete temNode;
				temNode = nullptr;
				temParentNode = nullptr;
			}
			checkStack.pop();
		}
	}
}

void mTree::updateRadiusInTree(TStream& tstream, Test& test, Node* node) {
	set<Node*> updateSet;
	stack<Node*> updateStack;
	updateStack.push(node);
	Node* temNode = nullptr;
	double dis = 0;
	double maxIncrease = 0;
	while (!updateStack.empty()) {
		temNode = updateStack.top();
		if (!updateSet.count(temNode)) {
			if (temNode->entryId.size() != 0) {
				temNode->radius = 0;
				for (auto id : temNode->entryId) {
					dis = calculateDistanceBycoordinate(tstream, test, id, temNode->coordinate);
					temNode->radius = max(temNode->radius, dis);
				}
				if (temNode->maxRadius < temNode->radius) {
					temNode->maxRadius = temNode->radius;
				}
				updateStack.pop();
			}
			if (temNode->childrenNode.size() != 0) {
				for (auto child : temNode->childrenNode) {
					updateStack.push(child);
				}
			}
			updateSet.insert(temNode);
		}
		else {
			if (temNode == root) {
				updateStack.pop();
				continue;
			}
			for (auto child : temNode->childrenNode) {
				(child->disToParent + child->radius) < temNode->maxRadius ? (temNode->radius = (child->disToParent + child->radius)) : (temNode->radius = temNode->maxRadius);
			}
			updateStack.pop();
		} 
	}
}

void mTree::test(TStream& tstream, Test& test, Node* node) {
	queue<Node*> q;
	q.push(node);
	Node* tem;
	while (!q.empty()) {
		tem = q.front();
		if (tem->childrenNode.size() == 0) {
			leafNodeNum++;
		}
		else {
			notleafNodeNum++;
		}
		for (auto child : tem->childrenNode) {
			q.push(child);
		}
		q.pop();
	}
	cout << "leafnodenum= " << leafNodeNum << endl;
	cout << "routenodenum= " << notleafNodeNum << endl;
}

void mTree::printlogmain(TStream& tstream, Test& test, int id, int num) {
	ofstream data;
	data.open("log_main01.txt", ofstream::app);
	data << "id��" << id << "  leafNodeNum = " << num << endl;
	data.close();
}

void mTree::PrintMapSet(Test& test, int datasBegin)
{
	int k = 0;
	for (auto iter = nnPairSet.begin(); iter != nnPairSet.end(); iter++)
	{
		if (k == test.GetR())
			break;
		if (iter->second.first < datasBegin || iter->second.second < datasBegin)
		{
			continue;
		}
		k++;
		cout << "The nearest neighbor of " << iter->second.first << " is " << iter->second.second << "distance:" << iter->first << endl;
	}
}
