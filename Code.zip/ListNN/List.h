#pragma once
#include <vector>
#include <list>
#include <queue>
#include <map>
#include <cassert>
#include <math.h>
#include <algorithm>
#include "TStream.h"
#include "Test.h"
#include<stack>
#include <unordered_map>
#include<set>
typedef vector<double> Data;
class List {
public:
	struct dimensionMap {
		multimap<double,int> dMap;
		int dim;
		bool upFlag = true;
		bool downFlag = true;
		multimap<double, int>::iterator upP;
		multimap<double, int>::iterator downP;
		bool insertFlag = true;
		double maxdif;
	};
	List();
	~List();
	void newInitList(TStream& tstream, Test& test);
	void newupdateDataFlow(TStream& tstream, Test& test);
	void newupdate(TStream& tstream, Test& test, int dataId);
	void InitDimensionMap(TStream& tstream, Test& test, int dimension);
	int chooseDimension(TStream& tstream, Test& test);
	void updatedMapVec(TStream& tstream, Test& test, int tstreamBegin);
	void updatennPairSet(TStream& tstream, Test& test, int tstreamBegin);
	bool checkUpdateMap(TStream& tstream, Test& test);
	double calculateDistanceById(TStream& tstream, Test& test, int id1, int id2);
	void insertNNPairSet(TStream& tstream, Test& test, int i1, int neighborId, double distance);
	void PrintMapSet(Test& test, int datasBegin);

private:
	unordered_map<double, pair<int, int>> nnPairSet;
	vector<dimensionMap*> dMapVec;
};