#pragma once
#include <vector>
#include <stdlib.h>
#include <iostream>
#pragma warning(disable:4996)
using namespace std;
class Test
{
public:
	Test();
	~Test();
	int GetDimension();
	int GetR();
	int GetWindowSize();
	int GetInFlow();
	int GetOutFlow();
	int GetQueryCycle();

	void SetDimension(int d);
	void SetR(double r);
	void SetWindowSize(int w);
	void SetInFlow(int in);
	void SetOutFlow(int out);
	void SetQueryCycle(int c);
	void Init(vector<Test>& vecTestFile,int j);

private:
	int dimension = 0;
	double R = 0;
	int windowSize = 0;
	int inFlow = 0;
	int outFlow = 0;
	int queryCycle = 0;
};

