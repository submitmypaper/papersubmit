#include"List.h"
using namespace std;

List::List() {

}

List::~List() {

}

void List::newInitList(TStream& tstream, Test& test) {
	int dimension = test.GetDimension();
	dMapVec.resize(dimension);
	double threshold = DBL_MAX;
	double dis;
	dMapVec.clear();
	for (int i = 0; i < dimension; ++i) {
		InitDimensionMap(tstream, test, i);
	}
	int maxdimension = chooseDimension(tstream, test);
	for (auto subscript = dMapVec[maxdimension]->dMap.begin(); subscript != dMapVec[maxdimension]->dMap.end(); ++subscript) {
		threshold = DBL_MAX;
		int id = subscript->second;
		int neighborId = -1;
		dMapVec[maxdimension]->upFlag = true;
		dMapVec[maxdimension]->downFlag = true;
		auto upSubscript = subscript;
		auto downSubscript = subscript;
		while (dMapVec[maxdimension]->upFlag || dMapVec[maxdimension]->downFlag) {
			if (upSubscript != dMapVec[maxdimension]->dMap.begin() && dMapVec[maxdimension]->upFlag == true) {
				upSubscript--;
				if ((subscript->first - upSubscript->first) <= threshold) {
					dis = calculateDistanceById(tstream, test, id, upSubscript->second);
					if (dis < threshold) {
						threshold = dis;
						neighborId = upSubscript->second;
					}
				}
				else {
					dMapVec[maxdimension]->upFlag = false;
				}
			}
			else {
				dMapVec[maxdimension]->upFlag = false;
			}
			if (downSubscript != (--dMapVec[maxdimension]->dMap.end()) && dMapVec[maxdimension]->downFlag == true) {
				downSubscript++;
				if ((downSubscript->first - subscript->first) <= threshold) {
					dis = calculateDistanceById(tstream, test, id, downSubscript->second);
					if (dis < threshold) {
						threshold = dis;
						neighborId = downSubscript->second;
					}
				}
				else {
					dMapVec[maxdimension]->downFlag = false;
				}
			}
			else {
				dMapVec[maxdimension]->downFlag = false;
			}
		}
		if (neighborId != -1) {
			insertNNPairSet(tstream, test, id, neighborId, threshold);
		}
	}
}

int List::chooseDimension(TStream& tstream, Test& test) {
	int dimension = test.GetDimension();
	int maxdimension = 0;
	double max = -1;
	for (int i = 0; i < dimension; ++i) {
		if (dMapVec[i]->maxdif > max) {
			max = dMapVec[i]->maxdif;
			maxdimension = i;
		}
	}
	return maxdimension;
}

void List::InitDimensionMap(TStream& tstream, Test& test, int dimension) {
	int dataNum = test.GetWindowSize() / test.GetDimension();
	dimensionMap* dmsMap = new dimensionMap();
	dmsMap->dim = dimension;
	for (int i = 0; i < dataNum; ++i) {
		dmsMap->dMap.emplace(tstream.GetDataStream(i * test.GetDimension() + dimension), i);
	}
	dmsMap->maxdif = dmsMap->dMap.rbegin()->first - dmsMap->dMap.begin()->first;
	dMapVec.push_back(dmsMap);
}

void List::newupdateDataFlow(TStream& tstream, Test& test) {
	int dimension = test.GetDimension();
	int windowSize = test.GetWindowSize() / dimension;
	tstream.SetDataStreamTag(windowSize);
	tstream.SetDataStreamBegin(0);
	int newEntryId = tstream.GetDataStreamTag();
	clock_t startTime1, endTime1;
	int num = 0;
	for (; tstream.GetDataStreamTag() < 52428800 + windowSize;) {
		tstream.AddDataStreamBegin(1);
		tstream.AddDataStreamTag(1);
		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 1)
		{
			startTime1 = clock();
		}
		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 0&&tstream.GetDataStreamTag()>= 1048576)
		{
			endTime1 = clock();
			cout << "Current cursor:" << tstream.GetDataStreamTag() << "     Time = " << (double)(endTime1 - startTime1) / CLOCKS_PER_SEC << "s" << endl;
		}

		if ((tstream.GetDataStreamTag() - tstream.GetDataStreamBegin()) >= 10 * (test.GetWindowSize() / test.GetDimension()))
		{
			tstream.SetDataStreamBegin(tstream.GetDataStreamTag() - (test.GetWindowSize() / test.GetDimension()));
		}

		if ((tstream.GetDataStreamTag() - tstream.GetDataStreamBegin()) <= 0.1 * (test.GetWindowSize() / test.GetDimension()))
		{
			tstream.SetDataStreamTag(tstream.GetDataStreamBegin() + (test.GetWindowSize() / test.GetDimension()));
			if (tstream.GetDataStreamTag() > tstream.GetDataStreamLength() / test.GetDimension())
			{
				tstream.SetDataStreamTag(tstream.GetDataStreamLength() / test.GetDimension());
			}
		}

		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 0) {
			
			updatennPairSet(tstream, test, tstream.GetDataStreamBegin());
		}
		if (num > 0.2 * windowSize) {
			if (checkUpdateMap(tstream, test)) {
				updatedMapVec(tstream, test, tstream.GetDataStreamBegin());
			}
			num = 0;
		}
		for (int i = newEntryId; i < tstream.GetDataStreamTag(); i++)
		{
			newupdate(tstream, test, i);
		}
		newEntryId = tstream.GetDataStreamTag();
	}
}

void List::updatedMapVec(TStream& tstream, Test& test, int tstreamBegin) {
	int dimension = test.GetDimension();
	for (int i = 0; i < dimension; ++i) {
		for (auto j = dMapVec[i]->dMap.begin(); j != dMapVec[i]->dMap.end();) {
			if (j->second < tstreamBegin) {
				dMapVec[i]->dMap.erase(j++);
				continue;
			}
			j++;
		}
	}
}

void List::newupdate(TStream& tstream, Test& test, int dataId) {
	int dimension = test.GetDimension();
	int maxdimension = chooseDimension(tstream, test);
	double dataInDimension;
	multimap<double, int>::iterator it;
	multimap<double, int>::iterator temit;
	for (int i = 0; i < dimension; ++i) {
		dataInDimension = tstream.GetDataStream(dataId * test.GetDimension() + i);
		if (i == maxdimension) {
			it = dMapVec[i]->dMap.emplace(dataInDimension, dataId);
		}
		else {
			temit = dMapVec[i]->dMap.emplace(dataInDimension, dataId);
		}
		
	}
	double threshold = DBL_MAX;
	int neighborId = -1;
	dMapVec[maxdimension]->upFlag = true;
	dMapVec[maxdimension]->downFlag = true;
	auto upSubscript = it;
	auto downSubscript = it;
	auto temdownSubscript = downSubscript;
	double dis = 0;
	while (dMapVec[maxdimension]->upFlag || dMapVec[maxdimension]->downFlag) {
		if (upSubscript != dMapVec[maxdimension]->dMap.begin() && dMapVec[maxdimension]->upFlag == true) {
			upSubscript--;
			if (upSubscript->second >= tstream.GetDataStreamBegin()) {
				if ((it->first - upSubscript->first) <= threshold) {
					dis = calculateDistanceById(tstream, test, dataId, upSubscript->second);
					if (dis < threshold) {
						threshold = dis;
						neighborId = upSubscript->second;
					}
				}
				else {
					dMapVec[maxdimension]->upFlag = false;
				}
			}
			else {
				dMapVec[maxdimension]->dMap.erase(upSubscript++);
			}
		}
		else {
			dMapVec[maxdimension]->upFlag = false;
		}
		if (downSubscript != (--dMapVec[maxdimension]->dMap.end()) && dMapVec[maxdimension]->downFlag == true) {
			temdownSubscript = downSubscript;
			downSubscript++;
			if (downSubscript->second >= tstream.GetDataStreamBegin()) {
				if ((downSubscript->first - it->first) <= threshold) {
					dis = calculateDistanceById(tstream, test, dataId, downSubscript->second);
					if (dis < threshold) {
						threshold = dis;
						neighborId = downSubscript->second;
					}
				}
				else {
					dMapVec[maxdimension]->downFlag = false;
				}
			}
			else {
				dMapVec[maxdimension]->dMap.erase(downSubscript);
				downSubscript = temdownSubscript;
			}
		}
		else {
			dMapVec[maxdimension]->downFlag = false;
		}
	}
	if (neighborId != -1) {
		insertNNPairSet(tstream, test, dataId, neighborId, threshold);
	}
}

bool List::checkUpdateMap(TStream& tstream, Test& test) {
	int dimension = test.GetDimension();
	int windowSize = test.GetWindowSize() / dimension;
	for (int i = 0; i < dimension; ++i) {
		if (dMapVec[i]->dMap.size() > 1.2*windowSize) {
			return true;
		}
	}
	return false;
}

double List::calculateDistanceById(TStream& tstream, Test& test, int id1, int id2) {
	int dimension = test.GetDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(tstream.GetDataStream(id1 * dimension + i) - tstream.GetDataStream(id2 * dimension + i), 2);
	}
	return sqrt(dis);
}

void List::insertNNPairSet(TStream& tstream, Test& test, int id, int neighborId, double distance) {
	while (nnPairSet.count(distance)) {
		return;
	}
	nnPairSet.emplace(distance, make_pair(id, neighborId));
}

void List::PrintMapSet(Test& test, int datasBegin)
{
	int k = 0;
	for (auto iter = nnPairSet.begin(); iter != nnPairSet.end(); iter++)
	{

		if (k == test.GetR())
			break;
		if (iter->second.second < datasBegin || iter->second.first < datasBegin)
		{
			continue;
		}
		k++;
		cout << "The nearest neighbor of " << iter->second.first << " is " << iter->second.second << "distance:" << iter->first << endl;
	}
}

void List::updatennPairSet(TStream& tstream, Test& test, int tstreamBegin) {
	for (auto x = nnPairSet.begin(); x != nnPairSet.end();) {
		if (x->second.first < tstreamBegin || x->second.second < tstreamBegin) {
			nnPairSet.erase(x++);
			continue;
		}
		x++;
	}
}

