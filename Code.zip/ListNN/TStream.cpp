#include "TStream.h"
#include <vector>
#include <list>
#include <queue>
#include <map>
#include <set>
#include <cassert>
#include <math.h>
#include <algorithm>
#include<stack>
#include<unordered_map>
#include <numeric> 
#include <string>
#pragma warning(disable:4996)
TStream::TStream()
{
}

TStream::~TStream()
{
}
void TStream::ReadDataFile(Test& test,int j)
{
	FILE* fp1;
	double dlNumber;
	int dimension = test.GetDimension();
	string a = to_string(j);
	string s = "SourceFile" + a + ".txt";
	if ((fp1 = fopen(s.data(), "r")) != NULL)
	{
		while (fscanf(fp1, "%lf", &dlNumber) != EOF)
		{
			vecDataStream.push_back(dlNumber);
		}
	}
}


double TStream::GetDataStream(int intObjectNumber)
{
	return vecDataStream[intObjectNumber];
}

vector<double> TStream::GetData(int dataId, int dimension) {
	vector<double> ans;
	for (int i = 0; i < dimension; ++i) {
		ans.push_back(vecDataStream[dimension * dataId + i]);
	}
	return ans;
}

int TStream::GetDataStreamLength()
{
	return vecDataStream.size();
}


int TStream::GetDataStreamBegin()
{
	return dataStreamBegin;
}

int TStream::GetDataStreamTag()
{
	return dataStreamTag;
}

void TStream::SetDataStreamBegin(int begin)
{
	dataStreamBegin = begin;
}

void TStream::SetDataStreamTag(int tag)
{
	dataStreamTag = tag;
}

void TStream::Init(Test& test,int j)
{
	ReadDataFile(test,j);
	SetDataStreamTag(test.GetWindowSize() / test.GetDimension());
	SetDataStreamBegin(0);
}

void TStream::AddDataStreamBegin(int outFlow)
{
	dataStreamBegin += outFlow;
}

void TStream::AddDataStreamTag(int inFlow)
{
	dataStreamTag += inFlow;
}
