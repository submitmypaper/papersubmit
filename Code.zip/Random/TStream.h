#pragma once
#include <vector>
#include "Test.h"
using namespace std;
class TStream
{
public:
	TStream();
	~TStream();

	void setFilData(int j);

	void setPointNeighbor(Test test);

	double getData(int ID);

	long GetvecDataLen();

	void setRange(Test test);

	vector<double> getLeftCoordinate();

	void InitPoint(Test test);
	double getLength();
	struct PointNeighbor
	{
		int order;
		int neighbor;
		double distance;

		bool operator < (const PointNeighbor& P)const
		{
			return distance < P.distance;
		}
	};
	vector<PointNeighbor> pointNeighbor;
	long vecData_begin = 0;
	long vecData_tag = 0;
	void SetvecData_tag(Test test);
private:
	vector<double> vecData;
	vector<double> leftCoordinate;
	vector<double> dimensionMax;
	vector<double> dimensionMin;
	double length;
	double max = 0;
};

