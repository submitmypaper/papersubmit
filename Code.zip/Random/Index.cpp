#include "Index.h"
#include <iostream>
using namespace std;
#define MAXSIZE 10
#include <random>

void Index::deleteOutDateObject(Hash& h, int tagBegin, TStream& tstream, Test& test)
{
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	for (auto iterVecHash = h.HashBucket.begin(); iterVecHash != h.HashBucket.end(); iterVecHash++)
	{
		for (auto iterLstHash = iterVecHash->begin(); iterLstHash != iterVecHash->end();)
		{
			for (auto iterLstObject = iterLstHash->order.begin(); iterLstObject != iterLstHash->order.end();)
			{
				if (*iterLstObject < tagBegin)
				{

					if (*iterLstObject != -1)
					{
						h.objectNumber--;
					}

					iterLstHash->order.erase(iterLstObject++);
				}
				else
				{
					iterLstObject++;
				}
			}
			if (iterLstHash->order.size() == 0)
			{
				iterVecHash->erase(iterLstHash++);
			}
			else
			{
				iterLstHash++;
			}
		}
	}
	for (auto iterVecHash = h.HashBucket_two.begin(); iterVecHash != h.HashBucket_two.end(); iterVecHash++)
	{
		for (auto iterLstHash = iterVecHash->begin(); iterLstHash != iterVecHash->end();)
		{
			for (auto iterLstObject = iterLstHash->order.begin(); iterLstObject != iterLstHash->order.end();)
			{
				if (*iterLstObject < tagBegin )
				{
					if (*iterLstObject != -1)
					{
						h.objectNumber--;
					}

					iterLstHash->order.erase(iterLstObject++);
				}
				else
				{
					iterLstObject++;
				}
			}
			if (iterLstHash->order.size() == 0)
			{
				iterVecHash->erase(iterLstHash++);
			}
			else
			{
				iterLstHash++;
			}
		}
	}
}

int Index::getHashKey(long long addr, int hashBucketSize)
{
	long long addr1 = addr;
	addr1 = addr1 / 3;
	addr1 = addr1 % hashBucketSize;
	return addr1;
}

int Index::getHashKey_two(long long addr, int hashBucketSize)
{
	long long addr1 = addr;
	addr1 = addr1 / 5;
	addr1 = addr1 % hashBucketSize;
	return addr1;
}

void Index::SetHashbucket_two(long long addr, vector<list<HashTable>>& Hashbucket, int order)
{
	int flag;
	long long t = getHashKey_two(addr, Hashbucket.size());
	if (Hashbucket[t].size() == 0)
	{
		HashTable x;
		Hashbucket[t].push_back(x);
		Hashbucket[t].front().addr = addr;
		Hashbucket[t].front().order.push_back(order);
	}
	else
	{
		flag = 0;

		for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
		{
			if (addr == iter->addr)
			{
				iter->order.push_back(order);
				flag = 1;
				break;
			}
		}
		if (flag == 0)
		{
			HashTable x;
			x.addr = addr;
			x.order.push_back(order);
			Hashbucket[t].push_back(x);
		}
	}
}


void Index::SetTIME(int time)
{
	TIME = time;
}

void Index::PrintMapSet(Test& test, int datasBegin)
{
	int k = 0;
	for (auto iter = myMap_dis.begin(); iter != myMap_dis.end(); iter++)
	{

		if (k == test.GetK())
			break;
		if (iter->second.order < datasBegin || iter->second.neighbor < datasBegin)
		{
			continue;
		}
		k++;
		cout << "The nearest neighbor of " << iter->second.order << " is " << iter->second.neighbor << "distance:" << iter->first << endl;
	}
}

long long Index::Findaddr(TStream& tstream, int order, int d, vector<double>& vecLeftCoordinate, double len, int n)
{
	int time = 2;
	if (d == 3)
	{
		time = 2;
	}
	if (d == 4)
	{
		time = 3;
	}
	if (d == 5)
	{
		time = 4;
	}
	bool flag = 0;
	if (n > 20 && d > 2)
	{
		flag = 1;
	}
	long long addr = 0;
	for (int k1 = 0; k1 < d; k1++)
	{
		if (flag == 1 && k1 == 1)
		{
			n = n / time;
		}
		long long temp = (tstream.getData(order * d + k1) - vecLeftCoordinate[k1]) / (len);
		addr = (addr << n) | temp;
	}
	return addr;
}

long long Index::Findaddr(TStream& tstream, int order, int d, vector<double>& vecLeftCoordinate, vector<double>& min, double len, int n)
{
	int time = 2;
	if (d == 3)
	{
		time = 2;
	}
	if (d == 4)
	{
		time = 3;
	}
	if (d == 5)
	{
		time = 4;
	}
	bool flag = 0;
	if (n > 20 && d > 2)
	{
		flag = 1;
	}
	long long addr = 0;
	for (int w = 0; w < d; w++)
	{
		if (flag == 1 && w == 1)
		{
			n = n / time;
		}
		long long temp = ((tstream.getData(order * d + w) - min[w]) / len);
		vecLeftCoordinate[w] = temp * len;
		addr = (addr << n) | temp;
	}
	return addr;
}

void Index::FindPointIndex(int d, int n, vector<long long>& pointIndex, long long addr)
{
	pointIndex.clear();
	for (int z1 = 0; z1 < pow(3, d); z1++)
	{
		long long t = addr;
		for (int z2 = 0; z2 < d; z2++)
		{
			long long temp = 0;
			if (d == 2)
			{
				temp = vecV2[z1 * d + z2];
			}
			if (d == 3)
			{
				temp = vecV3[z1 * d + z2];
			}
			if (d == 4)
			{
				temp = vecV4[z1 * d + z2];
			}
			if (d == 5)
			{
				temp = vecV5[z1 * d + z2];
			}
			if (d == 6)
			{
				temp = vecV6[z1 * d + z2];
			}
			temp = (temp << n * (d - z2 - 1));
			t = t + temp;
		}
		if (t >= 0)
		{
			pointIndex.push_back(t);
		}
	}
}

void Index::SetHashbucket(long long addr, vector<list<HashTable>>& Hashbucket, vector<list<HashTable>>& HashBucket_two, int order)
{
	int flag;
	long long t = getHashKey(addr, Hashbucket.size());
	if (Hashbucket[t].size() == 0)
	{
		HashTable x;
		Hashbucket[t].push_back(x);
		Hashbucket[t].front().addr = addr;
		Hashbucket[t].front().order.push_back(order);
	}
	else
	{
		flag = 0;

		for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
		{
			if (addr == iter->addr)
			{
				iter->order.push_back(order);
				flag = 1;
				break;
			}
		}
		if (flag == 0 && Hashbucket[t].size() < MAXSIZE)
		{
			HashTable x;
			x.addr = addr;
			x.order.push_back(order);
			Hashbucket[t].push_back(x);
		}
		else if (flag == 0)
		{
		
			SetHashbucket_two(addr, HashBucket_two, order);
		}
	}
}

void Index::SetHashbucket(Test test, long long addr, vector<list<HashTable>>& Hashbucket, vector<list<HashTable>>& Hashbucket_two)
{
	int flag;
	long long t = getHashKey(addr, Hashbucket.size());
	if (Hashbucket[t].size() == 0)
	{
		HashTable x;
		Hashbucket[t].push_back(x);
		Hashbucket[t].front().addr = addr;
		Hashbucket[t].front().order.push_back(-1);
		Hashbucket[t].front().pointNum++;
	}
	else
	{
		flag = 0;

		for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
		{
			if (addr == iter->addr)
			{
				iter->pointNum++;
				flag = 1;
				break;
			}
		}
		if (flag == 0 && Hashbucket.size() < MAXSIZE)
		{
			HashTable x;
			x.addr = addr;
			x.order.push_back(-1);
			x.pointNum++;
			Hashbucket[t].push_back(x);
		}
		else if (flag == 0)
		{
			SetHashbucket_two(test, addr, Hashbucket_two);
		}
	}
}

void Index::SetHashbucket_two(Test test, long long addr, vector<list<HashTable>>& Hashbucket)
{
	int flag;
	long long t = getHashKey_two(addr, Hashbucket.size());
	if (Hashbucket[t].size() == 0)
	{
		HashTable x;
		Hashbucket[t].push_back(x);
		Hashbucket[t].front().addr = addr;
		Hashbucket[t].front().order.push_back(-1);
		Hashbucket[t].front().pointNum++;
	}
	else
	{
		flag = 0;

		for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
		{
			if (addr == iter->addr)
			{
				iter->pointNum++;
				flag = 1;
				break;
			}
		}
		if (flag == 0)
		{
			HashTable x;
			x.addr = addr;
			x.order.push_back(-1);
			x.pointNum++;
			Hashbucket[t].push_back(x);
		}
	}
}


void Index::SetHashbucket_Reduce(Test test, long long addr, vector<list<HashTable>>& Hashbucket, vector<list<HashTable>>& Hashbucket_two)
{
	long long t = getHashKey(addr, Hashbucket.size());
	for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
	{
		if (addr == iter->addr)
		{
			if (iter->pointNum == 0)
				return;
			iter->pointNum--;
			if (iter->pointNum == 0 && iter->order.front() == -1 && iter->order.size() == 1)
			{
				Hashbucket[t].erase(iter);
			}
			break;
		}
	}

	t = getHashKey_two(addr, Hashbucket_two.size());
	for (auto iter = Hashbucket_two[t].begin(); iter != Hashbucket_two[t].end(); iter++)
	{
		if (addr == iter->addr)
		{
			if (iter->pointNum == 0)
				return;
			iter->pointNum--;
			if (iter->pointNum == 0 && iter->order.front() == -1 && iter->order.size() == 1)
			{
				Hashbucket_two[t].erase(iter);
			}
			break;
		}
	}
}

void Index::GetPoint(Hash& vecHash, vector<int>& point, int tagBegin)
{
	point.clear();
	for (auto iter2 = vecHash.HashBucket.begin(); iter2 != vecHash.HashBucket.end(); iter2++)
	{
		if (iter2->size() == 0)
		{
			continue;
		}
		for (auto iter1 = iter2->begin(); iter1 != iter2->end(); iter1++)
		{
			for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
			{
				if (*iter >= 0)
					point.push_back(*iter);
			}
		}
	}
}

void Index::GetPoint(Hash& hash, vector<int>& point, TStream& tstream, Test& test)
{
	point.reserve(hash.HashBucket.size() / 2);
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	for (auto iter2 = hash.HashBucket.begin(); iter2 != hash.HashBucket.end(); iter2++)
	{
		if (iter2->size() == 0)
		{
			continue;
		}
		for (auto iter1 = iter2->begin(); iter1 != iter2->end(); iter1++)
		{
			for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
			{
				if (*iter < 0 || *iter < tstream.vecData_begin)
				{
					if (*iter < tstream.vecData_begin)
					{
						if (hash.side != vecHash.begin()->side)
						{
							for (auto it = vecHash.begin(); it != vecHash.end(); it++)
							{
								if (it->side == vecHash.rbegin()->side || it->side == hash.side)
									break;
								int n = ceil(log2(tstream.getLength() / (it->side)));
								if (n < 0 || n >= 30)
								{
									break;
								}
								long long addr1 = Findaddr(tstream, *iter, test.GetD(), dimensionMin, it->side, n);
								if (addr1 < 0)
									continue;
								SetHashbucket_Reduce(test, addr1, it->HashBucket, it->HashBucket_two);
							}
						}
					}
					continue;
				}
				point.push_back(*iter);
			}
		}
	}
	for (auto iter2 = hash.HashBucket_two.begin(); iter2 != hash.HashBucket_two.end(); iter2++)
	{
		if (iter2->size() == 0)
		{
			continue;
		}
		for (auto iter1 = iter2->begin(); iter1 != iter2->end(); iter1++)
		{
			for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
			{
				if (*iter < 0 || *iter < tstream.vecData_begin)
				{
					if (*iter < tstream.vecData_begin)
					{
						if (hash.side != vecHash.begin()->side)
						{
							for (auto it = vecHash.begin(); it != vecHash.end(); it++)
							{
								if (it->side == vecHash.rbegin()->side || it->side == hash.side)
									break;
								int n = ceil(log2(tstream.getLength() / (it->side)));
								if (n < 0 || n >= 30)
								{
									break;
								}
								long long addr1 = Findaddr(tstream, *iter, test.GetD(), dimensionMin, it->side, n);
								if (addr1 < 0)
									continue;
								SetHashbucket_Reduce(test, addr1, it->HashBucket, it->HashBucket_two);
							}
						}
					}
					continue;
				}
				point.push_back(*iter);
			}
		}
	}
}



void Index::HandelPointIndex(TStream& tstream, Test test, vector<long long>& pointIndex, long long addr, vector<list<HashTable>>& Hashbucket, int order, double side, vector<int>& vecPoint, int vecPoint_begin, int vecPoint_end)
{
	int R = -1;
	bool flag = 0;
	long long addr1 = 0;
	for (int h1 = 0; h1 < pointIndex.size(); h1++)
	{
		addr = getHashKey(pointIndex[h1], Hashbucket.size());
		if (Hashbucket[addr].size() == 0)
		{
			continue;
		}
		for (auto iter1 = Hashbucket[addr].begin(); iter1 != Hashbucket[addr].end(); iter1++)
		{
			if (pointIndex[h1] == iter1->addr)
			{
				for (auto iter = iter1->order.begin(); iter != iter1->order.end();)
				{
					if (*iter == order)
					{
						addr1 = pointIndex[h1];
						iter++;
						continue;
					}
					double distance = 0;
					for (int w = 0; w < test.GetD(); w++)
					{
						distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
					}
					distance = sqrt(distance);
					if (distance == 0)
					{
						iter++;
						continue;
					}

					if (distance < side)
					{
						if (vecPoint_end != vecPoint.size())
						{
							vector<int>::iterator itFind = find(vecPoint.begin() + vecPoint_end, vecPoint.end(), *iter);
							if (itFind != vecPoint.end())
							{
								iter++;
								continue;
							}
						}

						vecPoint.push_back(*iter);
						R = *iter;
						if (iter1->order.size() == 1)
						{
							Hashbucket[addr].erase(iter1);
							iter1 = Hashbucket[addr].begin();
							break;
						}
						else
						{
							iter1->order.erase(iter++);
							if (iter1->order.size() == 0)
							{
								break;
							}
							continue;
						}
					}
					iter++;
				}

				if (Hashbucket[addr].size() == 0)
				{
					break;
				}
			}
		}
	}

	if (R != -1)
	{
		for (int i = vecPoint_end - 1; i < vecPoint.size(); i++)
		{
			if (vecPoint[i] == order)
			{
				flag = 1;
				break;
			}
		}
		if (flag == 0)
		{
			vecPoint.push_back(order);
		}
		addr1 = getHashKey(addr1, Hashbucket.size());
		for (auto iter1 = Hashbucket[addr1].begin(); iter1 != Hashbucket[addr1].end(); iter1++)
		{
			for (auto iter = iter1->order.begin(); iter != iter1->order.end(); )
			{
				if (*iter == order)
				{
					if (iter1->order.size() == 1)
					{
						Hashbucket[addr1].erase(iter1);
						return;
					}
					else
					{
						iter1->order.erase(iter++);
						return;
					}
				}
				iter++;
			}
		}
	}
}

void Index::FindNeighbor(TStream& tstream, Test& test, double side, vector<int>& vecPoint, int& vecPoint_begin, int& vecPoint_end)
{
	vector<double> vecLeftCoordinate(test.GetD());
	vector<double> dimensionMin = tstream.getLeftCoordinate();;
	vector<long long> pointIndex;
	int order;
	vector<int> point;
	long long index = 0;
	long long addr = 0;
	int n = ceil(log2(tstream.getLength() / (side)));
	for (int i = vecPoint_begin; i < vecPoint_end; i++)
	{
		order = vecPoint[i];

		addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, dimensionMin, side, n);

		if (addr < 0)
			continue;

		FindPointIndex(test.GetD(), n, pointIndex, addr);


		HandelPointIndex(tstream, test, pointIndex, addr, Hashbucket, order, side, vecPoint, vecPoint_begin, vecPoint_end);
	}
}


void Index::HandelPointIndex_Updata(TStream& tstream, Test test, vector<long long>& pointIndex, long long addr, Hash& h, int order, double& distance, int& flag)
{
	long long R = -1;
	long long addr1 = 0;
	double min = 0x3f3f3f3f;

	vector<double> dimensionMin = tstream.getLeftCoordinate();
	vector<double> vecLeftCoordinate(test.GetD());

	for (int h1 = 0; h1 < pointIndex.size(); h1++)
	{
		bool flagIn = 0;
		distance = 0;
		addr = getHashKey(addr, h.HashBucket.size());
		if (h.HashBucket[addr].size() != 0)
		{
			for (auto iter1 = h.HashBucket[addr].begin(); iter1 != h.HashBucket[addr].end(); iter1++)
			{
				if (pointIndex[h1] == iter1->addr)
				{
					flagIn = 1;
					if (iter1->pointNum > 0)
					{
						flag = 1;
					}
					for (auto iter = iter1->order.begin(); iter != iter1->order.end(); )
					{
						if (*iter == -1)
						{
							iter++;
							continue;
						}
						if (*iter < tstream.vecData_begin)
						{
							if (iter1->order.size() == 1)
							{
								h.objectNumber--;
								h.HashBucket[addr].erase(iter1);
								iter1 = h.HashBucket[addr].begin();
								break;
							}
							else
							{
								h.objectNumber--;
								iter1->order.erase(iter++);
								continue;
							}
						}
						else
						{
							for (int w = 0; w < test.GetD(); w++)
							{
								distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
							}
							distance = sqrt(distance);
							if (distance < min)
							{
								R = *iter;
								min = distance;
							}
						}
						iter++;
					}
					if (h.HashBucket[addr].size() == 0)
					{
						break;
					}
					break;
				}
			}
		}

		if (flagIn == 1)
		{
			continue;
		}
		distance = 0;
		addr1 = getHashKey_two(pointIndex[h1], h.HashBucket_two.size());
		if (h.HashBucket_two[addr1].size() == 0)
		{
			continue;
		}
		for (auto iter1 = h.HashBucket_two[addr1].begin(); iter1 != h.HashBucket_two[addr1].end(); iter1++)
		{
			if (pointIndex[h1] == iter1->addr)
			{
				if (iter1->pointNum > 0)
				{
					flag = 1;
				}
				for (auto iter = iter1->order.begin(); iter != iter1->order.end(); )
				{
					distance = 0;
					if (*iter == -1)
					{
						iter++;
						continue;
					}
					if (*iter < tstream.vecData_begin)
					{
						iter1->order.erase(iter++);
						h.objectNumber--;
						continue;
					}
					else
					{
						for (int w = 0; w < test.GetD(); w++)
						{
							distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
						}
						distance = sqrt(distance);
						if (distance < min)
						{
							R = *iter;
							min = distance;
						}
					}
					iter++;
				}

			}
		}

	}

	if (R == -1)
	{
		min = h.side;
	}
	distance = min;
}

void Index::Init(TStream& tstream, Test test)
{

	default_random_engine int_engine; 
	vector<int> vecPoint;
	int vecPoint_begin = 0;
	int vecPoint_end;
	vector<double> leftCoordinate = tstream.getLeftCoordinate();
	for (int i = 0; i < test.GetWindows() / test.GetD(); i++)
	{
		vecPoint.push_back(i);
	}
	vecPoint_end = vecPoint.size();


	while (vecPoint_end - vecPoint_begin >= test.GetK())
	{
		long long R = -1;
		int order = 0;
		double min = 0x3f3f3f3f;

		uniform_int_distribution<unsigned int> udistribution(vecPoint_begin, vecPoint_end);
		unsigned int uRandom = udistribution(int_engine);
		order = vecPoint[uRandom];

		for (int i = vecPoint_begin; i < vecPoint.size(); i++)
		{
			double distance = 0;
			if (vecPoint[i] == -1 || order == vecPoint[i])
				continue;
			for (int w = 0; w < test.GetD(); w++)
			{
				distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(vecPoint[i] * test.GetD() + w), 2);
			}
			distance = sqrt(distance);
			if (distance == 0 && order != vecPoint[i])
			{
				vecPoint[i] = -1;
				continue;
			}
			if (distance < min)
			{
				R = vecPoint[i];
				min = distance;
			}
		}

		double side = pow(2, floor(log2(min)));
		int n = ceil(log2(tstream.getLength() / side));
		if (n < 0 || n >= 30)
		{
			continue;
		}
		Hashbucket.clear();
		Hashbucket.resize((vecPoint_end - vecPoint_begin) * 4);
		HashBucket_two.clear();
		HashBucket_two.resize((vecPoint_end - vecPoint_begin) * 4 / 3);
		for (int i = vecPoint_begin; i < vecPoint.size(); i++)
		{
			long long addr = Findaddr(tstream, vecPoint[i], test.GetD(), leftCoordinate, side, n);
			if (addr < 0)
				continue;
			SetHashbucket(addr, Hashbucket, HashBucket_two, vecPoint[i]);
		}

		FindNeighbor(tstream, test, side, vecPoint, vecPoint_begin, vecPoint_end);
		Hash hash;
		hash.HashBucket = Hashbucket;
		hash.HashBucket_two = HashBucket_two;
		hash.side = side;
		vecHash.push_back(hash);

		vecPoint_begin = vecPoint_end;
		vecPoint_end = vecPoint.size();
	}

	if (vecPoint_end - vecPoint_begin != 0)
	{
		long long R = -1;
		uniform_int_distribution<unsigned int> udistribution(vecPoint_begin, vecPoint_end);
		unsigned int uRandom = udistribution(int_engine);
		int order = vecPoint[uRandom];
		double min = 0x3f3f3f3f;
		for (int i = vecPoint_begin; i < vecPoint.size(); i++)
		{
			double distance = 0;
			if (vecPoint[i] == order)
			{
				continue;
			}
			for (int w = 0; w < test.GetD(); w++)
			{
				distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(vecPoint[i] * test.GetD() + w), 2);
			}
			distance = sqrt(distance);
			if (distance < min && distance != 0)
			{
				R = vecPoint[i];
				min = distance;
			}
		}

		double side = pow(2, floor(log2(min)));
		int n = ceil(log2(tstream.getLength() / side));
		Hashbucket.clear();
		Hashbucket.resize((vecPoint_end - vecPoint_begin) * 4);
		HashBucket_two.clear();
		HashBucket_two.resize((vecPoint_end - vecPoint_begin) * 4 / 3);

		for (int i = vecPoint_begin; i < vecPoint.size(); i++)
		{
			long long addr = Findaddr(tstream, vecPoint[i], test.GetD(), leftCoordinate, side, n);
			if (addr < 0)
				continue;
			SetHashbucket(addr, Hashbucket, HashBucket_two, vecPoint[i]);
		}
		Hash hash;
		hash.HashBucket = Hashbucket;
		hash.HashBucket_two = HashBucket_two;
		hash.side = side;
		vecHash.push_back(hash);

	}

	tstream.vecData_tag = test.GetWindows() / test.GetD();

}


void Index::FindIndex(TStream& tstream, Test test)
{
	int order = 0;
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	long long addr = 0;
	vector<int> point;
	for (auto iter3 = vecHash.rbegin(); iter3 != vecHash.rend(); iter3++)
	{
		GetPoint(*iter3, point, tstream.vecData_begin);
		iter3->objectNumber = (int)point.size();
		for (int i = 0; i < point.size(); i++)
		{
			if (point[i] >= 0)
			{
				order = point[i];
				auto t = iter3;
				for (auto iter0 = ++t; iter0 != vecHash.rend(); iter0++)
				{
					int n = ceil(log2(tstream.getLength() / (iter0->side)));
					addr = Findaddr(tstream, order, test.GetD(), dimensionMin, iter0->side, n);
					if (addr < 0)
						continue;
					SetHashbucket(test, addr, iter0->HashBucket, iter0->HashBucket_two);
				}
			}
		}
	}
}


void Index::UpdataTStream(TStream& tstream, Test test)
{

	tstream.SetvecData_tag(test);
	int order;
	long long addr = 0;
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	vector<double> vecLeftCoordinate(test.GetD());
	vector<long long> pointIndex;
	long long index = 0;
	double distance = 0;
	int flag;
	int winsize = test.GetWindows() / test.GetD();
	vector<int> point;

	GetPoint(*vecHash.rbegin(), point, tstream.vecData_begin);
	double test_in = 1;
	clock_t startTime1, endTime1;
	for (int i = test.GetWindows() / test.GetD(); i < 52428800 +winsize; i++)
	{
		tstream.vecData_begin += 1;
		order = tstream.vecData_tag++;
		int overDueOrder = tstream.vecData_begin - test.GetIn();


		if ((tstream.vecData_tag - test.GetWindows() / test.GetD()) % 1048576 == 1)
		{
			startTime1 = clock();
		}
		if ((tstream.vecData_tag - test.GetWindows() / test.GetD()) % 1048576 == 0&&tstream.vecData_tag>= 1048576)
		{
			endTime1 = clock();
			cout << "Current cursor:" << tstream.vecData_tag << "     Time = " << (double)(endTime1 - startTime1) / CLOCKS_PER_SEC << "s" << endl;
		}

		for (auto iterVecHash = vecHash.begin(); iterVecHash != vecHash.end(); iterVecHash++)
		{
			if (iterVecHash->objectNumber > (int)iterVecHash->HashBucket.size())
			{
				point.clear();

				GetPoint(*iterVecHash, point, tstream, test);

				iterVecHash->HashBucket.resize(point.size() * 4);
				iterVecHash->HashBucket_two.resize(point.size() * 4 / 3);
				iterVecHash->objectNumber = (int)point.size();
				int n = ceil(log2(tstream.getLength() / (iterVecHash->side)));
				for (int i = 0; i < point.size(); i++)
				{
					addr = Findaddr(tstream, point[i], test.GetD(), dimensionMin, iterVecHash->side, n);
					if (addr < 0)
					{
						continue;
					}
					SetHashbucket(addr, iterVecHash->HashBucket, iterVecHash->HashBucket_two, point[i]);
				}
			}
		}


		if (tstream.vecData_tag % (test.GetWindows() / test.GetD()) == 0)
		{
			int sum = 0;
			for (auto iterVecHash = vecHash.begin(); iterVecHash != vecHash.end(); iterVecHash++)
			{
				sum += iterVecHash->objectNumber;
			}
			if (sum > 2 * test.GetWindows() / test.GetD())
			{
				for (auto iterVecHash = vecHash.rbegin(); iterVecHash != vecHash.rend(); iterVecHash++)
				{
					deleteOutDateObject(*iterVecHash, tstream.vecData_begin, tstream, test);
				}
			}
		}

		if (test_in > 1)
		{
			if (tstream.vecData_tag - tstream.vecData_begin <= (test.GetWindows() / test.GetD()) / 2)
			{
				test.SetIn(0);
			}
			if (tstream.vecData_tag - tstream.vecData_begin == (test.GetWindows() / test.GetD()))
			{
				test.SetIn(test_in);
			}
		}
		else if (test_in < 1)
		{
			if (tstream.vecData_tag - tstream.vecData_begin >= (int)((test.GetWindows() / test.GetD()) * 1.5))
			{
				test.SetIn(test_in * 100);
			}
			if (tstream.vecData_tag - tstream.vecData_begin - (test.GetWindows() / test.GetD()) <= test_in * 100)
			{
				test.SetIn(test_in);
			}
		}


		for (auto iter = vecHash.begin(); iter != vecHash.end(); iter++)
		{
			distance = 0;
			flag = 0;
			int n = ceil(log2(tstream.getLength() / (iter->side)));
			addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, dimensionMin, iter->side, n);

			if (addr < 0)
			{
				continue;
			}

			FindPointIndex(test.GetD(), n, pointIndex, addr);

			HandelPointIndex_Updata(tstream, test, pointIndex, index, *iter, order, distance, flag);

			if (flag == 0)
			{
				break;
			}
		}


		for (auto iter = vecHash.begin(); iter != vecHash.end(); iter++)
		{
			if (iter->side <= distance || iter->side == vecHash.rbegin()->side)
			{
				int n = ceil(log2(tstream.getLength() / (iter->side)));
				if (n >= 30)
				{
					break;
				}
				addr = Findaddr(tstream, order, test.GetD(), dimensionMin, iter->side, n);
				if (addr < 0)
					continue;
				SetHashbucket(addr, iter->HashBucket, iter->HashBucket_two, order);
				iter->objectNumber++;
				break;
			}

			int n = ceil(log2(tstream.getLength() / (iter->side)));
			if (n >= 30)
			{
				break;
			}
			addr = Findaddr(tstream, order, test.GetD(), dimensionMin, iter->side, n);
			if (addr < 0)
				break;
			SetHashbucket(test, index, iter->HashBucket, iter->HashBucket_two);
		}
	}
}

