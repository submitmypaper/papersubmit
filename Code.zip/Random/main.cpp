#include <iostream>
using namespace std;
#include "TStream.h"
#include "Test.h"
#include "Index.h"
#include <ctime>
#include <fstream>
#pragma warning(disable:4996)
int main()
{
	clock_t startTime, endTime;
	for (int j = 0; j < 5; j++) {
		Test test;
		TStream tstream;
		vector<Test> vecTestFile;
		tstream.setFilData(j);
		test.Init(vecTestFile, j);
		tstream.setRange(vecTestFile[0]);
		for (int i = 0; i < vecTestFile.size(); i++) {
			tstream.vecData_begin = 0;
			startTime = clock();
			Index index;
			index.Init(tstream, vecTestFile[i]);
			index.FindIndex(tstream, vecTestFile[i]);
			endTime = clock();
			cout << "Init Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
			index.SetTIME(test.GetTime());

			clock_t s1, s2;

			s1 = clock();
			index.UpdataTStream(tstream, vecTestFile[i]);
			s2 = clock();
			cout << "Updata Time = " << (double)(s2 - s1) / CLOCKS_PER_SEC << "s" << endl;
			cout << "Process " << 52428800 / ((double)(s2 - s1) / CLOCKS_PER_SEC) << " data per second " << endl;
		}
	}
	system("pause");
}