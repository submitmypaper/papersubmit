#include "Test.h"
#include <fstream>
#include <vector>
#include <string>
using namespace std;
#pragma warning(disable:4996)

Test::Test()
{
}


Test::~Test()
{
}


void Test::SetD(int d)
{
	t_D = d;
}


void Test::SetK(int k)
{
	t_K = k;
}

void Test::SetWindows(long w)
{
	t_Windows = w;
}


void Test::SetIn(float in)
{
	t_In = in;
}


void Test::SetTime(int time)
{
	t_Time = time;
}



int Test::GetD()
{
	return t_D;
}


int Test::GetK()
{
	return t_K;
}


long Test::GetWindows()
{
	return t_Windows;
}


float Test::GetIn()
{
	return t_In;
}


int Test::GetTime()
{
	return t_Time;
}

void Test::setTestData()
{
	FILE* fp1;
	int n;
	if ((fp1 = fopen("test.txt", "r")) != NULL)
	{
		for (int i = 0; fscanf(fp1, "%d", &n) != EOF; i++)
		{
			if (i % 5 == 0)
			{
				t_D = n;
			}
			else if (i % 5 == 1)
			{
				t_K = n;
			}
			else if (i % 5 == 2)
			{
				t_Windows = n;
			}
			else if (i % 5 == 3)
			{
				t_In = n;;
			}
			else if (i % 5 == 4)
			{
				t_Time = n;
			}
		}
	}
}

void Test::Init(vector<Test>& vecTestFile, int j)
{
	FILE* fp;
	string a = to_string(j);
	string s = "test" + a + ".txt";
	fp = fopen(s.data(), "r");
	int n;
	int i = 0;
	Test test;
	while (fscanf(fp, "%d", &n) != EOF)
	{
		if (i % 5 == 0)
		{
			test.SetD(n);
		}
		if (i % 5 == 1)
		{
			test.SetK(n);
		}
		if (i % 5 == 2)
		{
			test.SetWindows(n);
		}
		if (i % 5 == 3)
		{
			test.SetIn(n);
		}
		if (i % 5 == 4)
		{
			test.SetTime(n);
		}
		i++;
		if (i % 5 == 0 && i != 0)
		{
			vecTestFile.push_back(test);
		}
	}
}

