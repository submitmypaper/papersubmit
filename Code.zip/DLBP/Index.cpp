#include "Index.h"
#include <cmath>
#include <iostream>
#include <map>
#include <unordered_map>
#include <vector>
#include "Grid.h"
#include "TStream.h"
#define MAXSIZE 10

using namespace std;
Index::Index()
{
}


Index::~Index()
{
}

void Index::SetNF(int f)
{
	NF = f;
}

void Index::SetTIME(int time)
{
	TIME = time;
}

void Index::GetPoint(Hash& vecHash, vector<int>& point, TStream& tstream, int topkMax)
{
	for (auto iter2 = vecHash.HashBucket.begin(); iter2 != vecHash.HashBucket.end(); iter2++)
	{
		if (iter2->size() == 0)
		{
			continue;
		}
		for (auto iter1 = iter2->begin(); iter1 != iter2->end(); iter1++)
		{
			for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
			{
				if (*iter < 0 || *iter < tstream.vecData_begin)
				{
					continue;
				}
				point.push_back(*iter);
				if (point.size() >= topkMax)
				{
					return;
				}
			}
		}
	}
	for (auto iter2 = vecHash.HashBucket_two.begin(); iter2 != vecHash.HashBucket_two.end(); iter2++)
	{
		if (iter2->size() == 0)
		{
			continue;
		}
		for (auto iter1 = iter2->begin(); iter1 != iter2->end(); iter1++)
		{
			for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
			{
				if (*iter < 0 || *iter < tstream.vecData_begin)
					continue;
				point.push_back(*iter);
				if (point.size() >= topkMax)
				{
					return;
				}
			}
		}
	}
}

void Index::TopkPariQuery(TStream& tstream, Test& test, vector<int>& vecTopkQuery)
{
	vector<int> vecPoint;
	for (auto iterVecHash = vecHashIndex.rbegin(); iterVecHash != vecHashIndex.rend(); iterVecHash++)
	{
		GetPoint(*iterVecHash, vecPoint, tstream, 400);
		if (vecPoint.size() >= 400)
		{
			break;
		}
	}
	GetTopkPair(tstream, test, vecPoint);
}

void Index::GetTopkPair(TStream& tstream, Test& test, vector<int>& vecPoint)
{
	double distance;
	double minDistance;
	for (int i = 0; i < vecPoint.size(); i++)
	{
		minDistance = 0xfffffff;
		for (int j = 0; j < vecPoint.size(); j++)
		{
			distance = 0;
			if (i == j)
			{
				continue;
			}
			for (int w = 0; w < test.GetD(); w++)
			{
				distance += pow(tstream.getData(i * test.GetD() + w) - tstream.getData(j * test.GetD() + w), 2);
			}
			distance = sqrt(distance);
			if (distance < minDistance)
			{
				minDistance = distance;
			}
		}
	}
}

void Index::deleteOutDateObject(Hash& h, int tagBegin, TStream& tstream, Test& test)
{
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	for (auto iterVecHash = h.HashBucket.begin(); iterVecHash != h.HashBucket.end(); iterVecHash++)
	{
		for (auto iterLstHash = iterVecHash->begin(); iterLstHash != iterVecHash->end();)
		{
			for (auto iterLstObject = iterLstHash->order.begin(); iterLstObject != iterLstHash->order.end();)
			{
				if (*iterLstObject < tagBegin)
				{
					if (*iterLstObject != -1)
					{
						h.objectNumber--;
					}

					iterLstHash->order.erase(iterLstObject++);

				}
				else
				{
					iterLstObject++;
				}
			}
			if (iterLstHash->order.size() == 0)
			{
				iterVecHash->erase(iterLstHash++);
			}
			else
			{
				iterLstHash++;
			}
		}
	}
	for (auto iterVecHash = h.HashBucket_two.begin(); iterVecHash != h.HashBucket_two.end(); iterVecHash++)
	{
		for (auto iterLstHash = iterVecHash->begin(); iterLstHash != iterVecHash->end();)
		{
			for (auto iterLstObject = iterLstHash->order.begin(); iterLstObject != iterLstHash->order.end();)
			{
				if (*iterLstObject < tagBegin)
				{
					if (*iterLstObject != -1)
					{
						h.objectNumber--;
					}
					iterLstHash->order.erase(iterLstObject++);
				}
				else
				{
					iterLstObject++;
				}
			}
			if (iterLstHash->order.size() == 0)
			{
				iterVecHash->erase(iterLstHash++);
			}
			else
			{
				iterLstHash++;
			}
		}
	}

}

int Index::getHashKey(unsigned long long addr, int hashBucketSize)
{
	unsigned long long addr1 = addr;
	addr1 = addr1 / 3;
	addr1 = addr1 % hashBucketSize;
	return addr1;
}

int Index::getHashKey_two(unsigned long long addr, int hashBucketSize)
{
	unsigned long long addr1 = addr;
	addr1 = addr1 / 5;
	addr1 = addr1 % hashBucketSize;
	return addr1;
}

unsigned long long  Index::Findaddr(TStream& tstream, int order, int d, vector<double>& vecLeftCoordinate, vector<double>& min, double len, int n)
{
	int time = 2;
	if (d == 3)
	{
		time = 2;
	}
	if (d == 4)
	{
		time = 3;
	}
	if (d == 5)
	{
		time = 4;
	}
	bool flag = 0;
	if (n > 20 && d > 2)
	{
		flag = 1;
	}
	unsigned long long addr = 0;
	for (int w = 0; w < d; w++)
	{
		if (flag == 1 && w == 1)
		{
			n = n / time;
		}
		unsigned long long temp = ((tstream.getData(order * d + w) - min[w]) / len);
		vecLeftCoordinate[w] = temp * len;
		addr = (addr << n) | temp;
	}
	return addr;
}

unsigned long long Index::Findaddr(TStream& tstream, int order, int d, vector<double>& vecLeftCoordinate, double len, int n)
{
	int time = 2;
	if (d == 3)
	{
		time = 2;
	}
	if (d == 4)
	{
		time = 3;
	}
	if (d == 5)
	{
		time = 4;
	}
	bool flag = 0;
	if (n > 20 && d > 2)
	{
		flag = 1;
	}
	unsigned long long addr = 0;
	for (int k1 = 0; k1 < d; k1++)
	{
		if (flag == 1 && k1 == 1)
		{
			n = n / time;
		}
		unsigned long long temp = (tstream.getData(order * d + k1) - vecLeftCoordinate[k1]) / (len);
		addr = (addr << n) | temp;
	}
	return addr;
}

void Index::FindPointIndex(int d, int n, vector<long long>& pointIndex, unsigned long long index, unsigned long long addr)
{

	pointIndex.clear();
	if (d == 2)
	{
		for (int z1 = 0; z1 < 9; z1++)
		{
			bool flag = 1;
			unsigned long long t = index;
			for (int z2 = 0; z2 < d; z2++)
			{
				unsigned long long temp = 0;
				if (vecV2[addr][z1 * d + z2] < 0)
				{
					temp = vecV2[addr][z1 * d + z2] * -1;
					temp = (temp << n * (d - z2 - 1));
					if (t > temp)
					{
						t = t - temp;
						continue;
					}
					else
					{
						flag = 0;
						break;
					}
				}
				temp = vecV2[addr][z1 * d + z2];
				temp = (temp << n * (d - z2 - 1));
				t = t + temp;
			}
			if (flag == 1)
			{
				pointIndex.push_back(t);
			}
		}
	}
	else
	{
		for (int z1 = 0; z1 < pow(2, d); z1++)
		{
			bool flag = 1;
			unsigned long long t = index;
			for (int z2 = 0; z2 < d; z2++)
			{
				unsigned long long temp = 0;
				if (d == 3)
				{
					if (vecV3[addr][z1 * d + z2] < 0)
					{
						temp = vecV3[addr][z1 * d + z2] * -1;
						temp = (temp << n * (d - z2 - 1));
						if (t > temp)
						{
							t = t - temp;
							continue;
						}
						else
						{
							flag = 0;
							break;
						}
					}
					temp = vecV3[addr][z1 * d + z2];
				}
				if (d == 4)
				{
					if (vecV4[addr][z1 * d + z2] < 0)
					{
						temp = vecV4[addr][z1 * d + z2] * -1;
						temp = (temp << n * (d - z2 - 1));
						if (t > temp)
						{
							t = t - temp;
							continue;
						}
						else
						{
							flag = 0;
							break;
						}
					}
					temp = vecV4[addr][z1 * d + z2];
				}
				if (d == 5)
				{
					if (vecV5[addr][z1 * d + z2] < 0)
					{
						temp = vecV5[addr][z1 * d + z2] * -1;
						temp = (temp << n * (d - z2 - 1));
						if (t > temp)
						{
							t = t - temp;
							continue;
						}
						else
						{
							flag = 0;
							break;
						}
					}
					temp = vecV5[addr][z1 * d + z2];
				}
				if (d == 6)
				{
					if (vecV6[addr][z1 * d + z2] < 0)
					{
						temp = vecV6[addr][z1 * d + z2] * -1;
						temp = (temp << n * (d - z2 - 1));
						if (t > temp)
						{
							t = t - temp;
							continue;
						}
						else
						{
							flag = 0;
							break;
						}
					}
					temp = vecV6[addr][z1 * d + z2];
				}
				temp = (temp << n * (d - z2 - 1));
				t = t + temp;
			}
			if (flag == 1)
			{
				pointIndex.push_back(t);
			}
		}
	}

}

void Index::SetHashbucket(Test test, unsigned long long addr, vector<list<HashTable>>& Hashbucket, vector<list<HashTable>>& Hashbucket_two, int order)
{
	int flag;
	unsigned long long t = getHashKey(addr, Hashbucket.size());
	if (Hashbucket[t].size() == 0)
	{
		HashTable x;
		Hashbucket[t].push_back(x);
		Hashbucket[t].front().addr = addr;
		Hashbucket[t].front().order.push_back(order);
	}
	else
	{
		flag = 0;

		for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
		{
			if (addr == iter->addr)
			{
				iter->order.push_back(order);
				flag = 1;
				break;
			}
		}
		if (flag == 0 && Hashbucket[t].size() < MAXSIZE)
		{
			HashTable x;
			x.addr = addr;
			x.order.push_back(order);
			Hashbucket[t].push_back(x);
		}
		else if (flag == 0)
		{
			SetHashbucket_two(test, addr, Hashbucket_two, order);
		}
	}
}

void Index::SetHashbucket_two(Test test, unsigned long long addr, vector<list<HashTable>>& Hashbucket, int order)
{
	int flag;
	unsigned long long t = getHashKey_two(addr, Hashbucket.size());
	if (Hashbucket[t].size() == 0)
	{
		HashTable x;
		Hashbucket[t].push_back(x);
		Hashbucket[t].front().addr = addr;
		Hashbucket[t].front().order.push_back(order);
	}
	else
	{
		flag = 0;

		for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
		{
			if (addr == iter->addr)
			{
				iter->order.push_back(order);
				flag = 1;
				break;
			}
		}
		if (flag == 0)
		{
			HashTable x;
			x.addr = addr;
			x.order.push_back(order);
			Hashbucket[t].push_back(x);
		}
	}
}

void Index::SetHashbucket(Test test, unsigned long long addr, vector<list<HashTable>>& Hashbucket, vector<list<HashTable>>& Hashbucket_two)
{
	int flag;
	unsigned long long t = getHashKey(addr, Hashbucket.size());
	if (Hashbucket[t].size() == 0)
	{
		HashTable x;
		Hashbucket[t].push_back(x);
		Hashbucket[t].front().addr = addr;
		Hashbucket[t].front().order.push_back(-1);
		Hashbucket[t].front().pointNum++;
	}
	else
	{
		flag = 0;

		for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
		{
			if (addr == iter->addr)
			{
				iter->pointNum++;
				flag = 1;
				break;
			}
		}
		if (flag == 0 && Hashbucket.size() < MAXSIZE)
		{
			HashTable x;
			x.addr = addr;
			x.order.push_back(-1);
			x.pointNum++;
			Hashbucket[t].push_back(x);
		}
		else if (flag == 0)
		{
			SetHashbucket_two(test, addr, Hashbucket_two);
		}
	}
}

void Index::SetHashbucket_two(Test test, unsigned long long addr, vector<list<HashTable>>& Hashbucket)
{
	int flag;
	unsigned long long t = getHashKey_two(addr, Hashbucket.size());
	if (Hashbucket[t].size() == 0)
	{
		HashTable x;
		Hashbucket[t].push_back(x);
		Hashbucket[t].front().addr = addr;
		Hashbucket[t].front().order.push_back(-1);
		Hashbucket[t].front().pointNum++;
	}
	else
	{
		flag = 0;

		for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
		{
			if (addr == iter->addr)
			{
				iter->pointNum++;
				flag = 1;
				break;
			}
		}
		if (flag == 0)
		{
			HashTable x;
			x.addr = addr;
			x.order.push_back(-1);
			x.pointNum++;
			Hashbucket[t].push_back(x);
		}
	}
}

void Index::SetHashbucket_Reduce(Test test, unsigned long long addr, vector<list<HashTable>>& Hashbucket, vector<list<HashTable>>& Hashbucket_two)
{
	unsigned long long t = getHashKey(addr, Hashbucket.size());
	for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
	{
		if (addr == iter->addr)
		{
			if (iter->pointNum == 0)
				return;
			iter->pointNum--;
			if (iter->pointNum == 0 && iter->order.front() == -1 && iter->order.size() == 1)
			{
				Hashbucket[t].erase(iter);
			}
			break;
		}
	}

	t = getHashKey_two(addr, Hashbucket_two.size());
	for (auto iter = Hashbucket_two[t].begin(); iter != Hashbucket_two[t].end(); iter++)
	{
		if (addr == iter->addr)
		{
			if (iter->pointNum == 0)
				return;
			iter->pointNum--;
			if (iter->pointNum == 0 && iter->order.front() == -1 && iter->order.size() == 1)
			{
				Hashbucket_two[t].erase(iter);
			}
			break;
		}
	}
}

void Index::GetPoint(Hash& vecHash, vector<int>& point, TStream& tstream)
{
	point.reserve(vecHash.HashBucket.size() / 2);
	for (auto iter2 = vecHash.HashBucket.begin(); iter2 != vecHash.HashBucket.end(); iter2++)
	{
		if (iter2->size() == 0)
		{
			continue;
		}
		for (auto iter1 = iter2->begin(); iter1 != iter2->end(); iter1++)
		{
			for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
			{
				if (*iter < 0 || *iter < tstream.vecData_begin)
				{
					continue;
				}
				point.push_back(*iter);
			}
		}
	}
	for (auto iter2 = vecHash.HashBucket_two.begin(); iter2 != vecHash.HashBucket_two.end(); iter2++)
	{
		if (iter2->size() == 0)
		{
			continue;
		}
		for (auto iter1 = iter2->begin(); iter1 != iter2->end(); iter1++)
		{
			for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
			{
				if (*iter < 0 || *iter < tstream.vecData_begin)
					continue;
				point.push_back(*iter);
			}
		}
	}
}

void Index::GetPoint(Hash& vecHash, vector<int>& point, TStream& tstream, Test& test)
{
	point.reserve(vecHash.HashBucket.size() / 2);
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	for (auto iter2 = vecHash.HashBucket.begin(); iter2 != vecHash.HashBucket.end(); iter2++)
	{
		if (iter2->size() == 0)
		{
			continue;
		}
		for (auto iter1 = iter2->begin(); iter1 != iter2->end(); iter1++)
		{
			for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
			{
				if (*iter < 0 || *iter < tstream.vecData_begin)
				{
					if (*iter < tstream.vecData_begin)
					{
						if (vecHash.side != vecHashIndex.begin()->side)
						{
							for (auto it = vecHashIndex.begin(); it != vecHashIndex.end(); it++)
							{
								if (it->side == vecHashIndex.rbegin()->side || it->side == vecHash.side)
									break;
								int n = ceil(log2(tstream.getLength() / (it->side)));
								if (n < 0 || n >= 30)
								{
									break;
								}
								unsigned long long addr1 = Findaddr(tstream, *iter, test.GetD(), dimensionMin, it->side, n);
								if (addr1 < 0)
									continue;
								SetHashbucket_Reduce(test, addr1, it->HashBucket, it->HashBucket_two);
							}
						}
					}
					continue;
				}
				point.push_back(*iter);
			}
		}
	}
	for (auto iter2 = vecHash.HashBucket_two.begin(); iter2 != vecHash.HashBucket_two.end(); iter2++)
	{
		if (iter2->size() == 0)
		{
			continue;
		}
		for (auto iter1 = iter2->begin(); iter1 != iter2->end(); iter1++)
		{
			for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
			{
				if (*iter < 0 || *iter < tstream.vecData_begin)
				{
					if (*iter < tstream.vecData_begin)
					{
						if (vecHash.side != vecHashIndex.begin()->side)
						{
							for (auto it = vecHashIndex.begin(); it != vecHashIndex.end(); it++)
							{
								if (it->side == vecHashIndex.rbegin()->side || it->side == vecHash.side)
									break;
								int n = ceil(log2(tstream.getLength() / (it->side)));
								if (n < 0 || n >= 30)
								{
									break;
								}
								unsigned long long addr1 = Findaddr(tstream, *iter, test.GetD(), dimensionMin, it->side, n);
								if (addr1 < 0)
									continue;
								SetHashbucket_Reduce(test, addr1, it->HashBucket, it->HashBucket_two);
							}
						}
					}
					continue;
				}
				point.push_back(*iter);
			}
		}
	}
}

void Index::HandelPointNeighbor(TStream& tstream, Test test, int& tag1, int& tag2)
{
	double mid = 0;
	Hash temp;
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	unsigned long long addr = 0;
	nth_element(tstream.pointNeighbor.begin(), tstream.pointNeighbor.begin() + tag1 / 2, tstream.pointNeighbor.begin() + tag1);
	mid = tstream.pointNeighbor[tag1 / 2].distance;

	mid = pow(2, floor(log2(mid)));


	int n = ceil(log2(tstream.getLength() / (mid)));
	Hashbucket.clear();
	Hashbucket.resize(tag1 * 4);
	Hashbucket_two.clear();
	Hashbucket_two.resize(tag1 * 4 / 3);


	if (tag1 <= test.GetK())
	{
		for (int i = 0; i < tag1; i++)
		{
			addr = Findaddr(tstream, tstream.pointNeighbor[i].order, test.GetD(), dimensionMin, mid, n);
			if (addr < 0)
			{
				continue;
			}
			SetHashbucket(test, addr, Hashbucket, Hashbucket_two, tstream.pointNeighbor[i].order);
		}
	}
	else
	{
		for (int i = 0; i < tag1; i++)
		{
			if (tstream.pointNeighbor[i].distance >= mid)
			{
				tag2++;
				addr = Findaddr(tstream, tstream.pointNeighbor[i].order, test.GetD(), dimensionMin, mid, n);
				if (addr < 0)
				{
					continue;
				}
				SetHashbucket(test, addr, Hashbucket, Hashbucket_two, tstream.pointNeighbor[i].order);
			}
		}
	}

	nth_element(tstream.pointNeighbor.begin(), tstream.pointNeighbor.begin() + tag1 - tag2, tstream.pointNeighbor.begin() + tag1);

	if (tag2 != 0)
	{
		temp.objectNumber = tag2;
	}
	else
	{
		temp.objectNumber = tag1;
	}
	temp.HashBucket = Hashbucket;
	temp.HashBucket_two = Hashbucket_two;
	temp.side = mid;
	vecHashIndex.push_back(temp);
	Hashbucket = {};
	Hashbucket_two = {};
	temp = {};
}

void Index::HandelPointIndex(TStream& tstream, Test test, vector<long long>& pointIndex, unsigned long long addr, Hash& h, int order)
{
	unsigned long long addr1 = 0;
	for (int h1 = 0; h1 < pointIndex.size(); h1++)
	{
		addr = getHashKey(pointIndex[h1], h.HashBucket.size());
		if (h.HashBucket[addr].size() == 0)
		{
			continue;
		}
		for (auto iter1 = h.HashBucket[addr].begin(); iter1 != h.HashBucket[addr].end(); iter1++)
		{
			if (pointIndex[h1] == iter1->addr)
			{
				for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
				{
					if (*iter == order)
					{
						continue;
					}

					double distance = 0;
					for (int w = 0; w < test.GetD(); w++)
					{
						distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
					}
					distance = sqrt(distance);
					if (distance <= h.side && order != *iter && distance != 0)
					{
						if (tstream.pointNeighbor[*iter].distance > distance)
						{
							tstream.pointNeighbor[*iter].neighbor = order;
							tstream.pointNeighbor[*iter].distance = distance;
						}

						if (tstream.pointNeighbor[order].distance > distance)
						{
							tstream.pointNeighbor[order].neighbor = *iter;
							tstream.pointNeighbor[order].distance = distance;
						}
					}
				}
			}
		}


		addr1 = getHashKey_two(pointIndex[h1], h.HashBucket_two.size());
		if (h.HashBucket_two[addr1].size() == 0)
		{
			continue;
		}
		for (auto iter1 = h.HashBucket_two[addr1].begin(); iter1 != h.HashBucket_two[addr1].end(); iter1++)
		{
			if (pointIndex[h1] == iter1->addr)
			{
				for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
				{
					if (*iter == order)
					{
						continue;
					}

					double distance = 0;
					for (int w = 0; w < test.GetD(); w++)
					{
						distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
					}
					distance = sqrt(distance);
					if (distance <= h.side && order != *iter && distance != 0)
					{
						if (tstream.pointNeighbor[*iter].distance > distance)
						{
							tstream.pointNeighbor[*iter].neighbor = order;
							tstream.pointNeighbor[*iter].distance = distance;
						}

						if (tstream.pointNeighbor[order].distance > distance)
						{
							tstream.pointNeighbor[order].neighbor = *iter;
							tstream.pointNeighbor[order].distance = distance;
						}
					}
				}
			}
		}
	}
}

void Index::HandelPointIndex_Updata(TStream& tstream, Test test, vector<long long>& pointIndex, unsigned long long addr, Hash& h, int order, double& distance, int& flag)
{
	unsigned long long R = -1;
	unsigned long long addr1 = addr;
	double min = 0x3f3f3f3f;

	vector<double> dimensionMin = tstream.getLeftCoordinate();

	for (int h1 = 0; h1 < pointIndex.size(); h1++)
	{
		bool flagIn = 0;
		distance = 0;
		addr = getHashKey(pointIndex[h1], h.HashBucket.size());
		if (h.HashBucket[addr].size() != 0)
		{
			for (auto iter1 = h.HashBucket[addr].begin(); iter1 != h.HashBucket[addr].end(); iter1++)
			{
				if (pointIndex[h1] == iter1->addr)
				{
					flagIn = 1;
					if (iter1->pointNum > 0)
					{
						flag = 1;
					}
					for (auto iter = iter1->order.begin(); iter != iter1->order.end();)
					{
						distance = 0;
						if (*iter == -1)
						{
							iter++;
							continue;
						}
						if (*iter < tstream.vecData_begin)
						{
							iter1->order.erase(iter++);
							h.objectNumber--;
							continue;
						}
						else
						{
							for (int w = 0; w < test.GetD(); w++)
							{
								distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
							}
							distance = sqrt(distance);
							if (distance < min)
							{
								R = *iter;
								min = distance;
							}
						}
						iter++;
					}
					break;
				}
			}
		}
		if (flagIn == 1)
		{
			continue;
		}
		distance = 0;
		addr1 = getHashKey_two(pointIndex[h1], h.HashBucket_two.size());
		if (h.HashBucket_two[addr1].size() == 0)
		{
			continue;
		}
		for (auto iter1 = h.HashBucket_two[addr1].begin(); iter1 != h.HashBucket_two[addr1].end(); iter1++)
		{
			if (pointIndex[h1] == iter1->addr)
			{
				if (iter1->pointNum > 0)
				{
					flag = 1;
				}
				for (auto iter = iter1->order.begin(); iter != iter1->order.end(); )
				{
					distance = 0;
					if (*iter == -1)
					{
						iter++;
						continue;
					}
					if (*iter < tstream.vecData_begin)
					{
						iter1->order.erase(iter++);
						h.objectNumber--;
						continue;
					}
					else
					{
						for (int w = 0; w < test.GetD(); w++)
						{
							distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
						}
						distance = sqrt(distance);
						if (distance < min)
						{
							R = *iter;
							min = distance;
						}
					}
					iter++;
				}

			}
		}
	}

	if (R == -1)
	{
		min = h.side;
	}
	distance = min;

}

void Index::HandelMap(TStream& tstream, Test test, vector<long long>& pointIndex, unsigned long long addr, Hash& h, int order)
{
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	unsigned long long index = 0;
	double distance = 0;
	double min = 0x3f3f3f3f;
	int R = -1;
	Point a;
	bool flag;
	for (int h1 = 0; h1 < pointIndex.size(); h1++)
	{
		addr = getHashKey(pointIndex[h1], vecHashIndex.rbegin()->HashBucket.size());
		if (vecHashIndex.rbegin()->HashBucket[addr].size() == 0)
		{
			continue;
		}
		for (auto iter1 = vecHashIndex.rbegin()->HashBucket[addr].begin(); iter1 != vecHashIndex.rbegin()->HashBucket[addr].end(); iter1++)
		{
			if (pointIndex[h1] == iter1->addr)
			{
				for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
				{
					distance = 0;
					if (*iter == order || *iter == -1)
					{
						continue;
					}
					for (int w = 0; w < test.GetD(); w++)
					{
						distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
					}
					distance = sqrt(distance);
					if (distance < min)
					{
						R = *iter;
						min = distance;
					}
				}
			}
		}


		addr = getHashKey_two(pointIndex[h1], vecHashIndex.rbegin()->HashBucket_two.size());
		if (vecHashIndex.rbegin()->HashBucket_two[addr].size() == 0)
		{
			continue;
		}
		for (auto iter1 = vecHashIndex.rbegin()->HashBucket_two[addr].begin(); iter1 != vecHashIndex.rbegin()->HashBucket_two[addr].end(); iter1++)
		{
			if (pointIndex[h1] == iter1->addr)
			{
				for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
				{
					distance = 0;
					if (*iter == order)
					{
						continue;
					}
					for (int w = 0; w < test.GetD(); w++)
					{
						distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
					}
					distance = sqrt(distance);
					if (distance < min)
					{
						R = *iter;
						min = distance;
					}
				}
			}
		}
	}
}



void Index::PushBackHashTable(TStream& tstream, Test test, double up4, int vecS1Length, vector<Cube>& vecS1, vector<double>& dimensionMin)
{
	Hash temp;
	unsigned long long addr = 0;
	int n = ceil(log2(tstream.getLength() / (up4)));
	Hashbucket.clear();
	Hashbucket.resize((vecS1.size() - vecS1Length) * 4);
	Hashbucket_two.clear();
	Hashbucket_two.resize((vecS1.size() - vecS1Length) * 4 / 3);

	for (int i = vecS1Length; i < vecS1.size(); i++)
	{
		addr = Findaddr(tstream, vecS1[i].order, test.GetD(), dimensionMin, up4, n);
		if (addr < 0)
		{
			continue;
		}
		SetHashbucket(test, addr, Hashbucket, Hashbucket_two, vecS1[i].order);

	}
	temp.HashBucket = Hashbucket;
	temp.HashBucket_two = Hashbucket_two;
	temp.side = up4;
	vecHash.push_back(temp);
	Hashbucket = {};
	Hashbucket_two = {};
}
void Index::UpdataPushBackHashTable(TStream& tstream, Test test, double up4, int vecS1Length, vector<Cube>& vecS1, vector<double>& dimensionMin)
{
	Hash temp;
	unsigned long long addr = 0;
	int n = ceil(log2(tstream.getLength() / (up4)));
	Hashbucket.clear();
	Hashbucket.resize((vecS1.size() - vecS1Length) * 4);
	Hashbucket_two.clear();
	Hashbucket_two.resize((vecS1.size() - vecS1Length) * 4 / 3);
	if (Hashbucket.size() == 0)
	{
		return;
	}
	for (int i = vecS1Length; i < vecS1.size(); i++)
	{
		addr = Findaddr(tstream, vecS1[i].order, test.GetD(), dimensionMin, up4, n);
		if (addr < 0)
		{
			continue;
		}
		SetHashbucket(test, addr, Hashbucket, Hashbucket_two, vecS1[i].order);

	}
	temp.HashBucket = Hashbucket;
	temp.HashBucket_two = Hashbucket_two;
	temp.side = up4;
	temp.objectNumber = vecS1.size() - vecS1Length;
	vecHashIndex.push_back(temp);
	Hashbucket = {};
	Hashbucket_two = {};

}

void Index::PushBackHashTable_1(TStream& tstream, Test test, double up4, vector<Cube>& cube, vector<double>& dimensionMin, int tag1)
{
	Hash temp;
	unsigned long long addr = 0;
	int n = ceil(log2(tstream.getLength() / (up4)));
	Hashbucket.clear();
	Hashbucket.resize(tag1 * 4);
	Hashbucket_two.clear();
	Hashbucket_two.resize(tag1 * 4 / 3);

	for (int i = 0; i < tag1; i++)
	{
		addr = Findaddr(tstream, cube[i].order, test.GetD(), dimensionMin, up4, n);
		if (addr < 0)
		{
			continue;
		}
		SetHashbucket(test, addr, Hashbucket, Hashbucket_two, cube[i].order);

	}
	temp.HashBucket = Hashbucket;
	temp.HashBucket_two = Hashbucket_two;
	temp.side = up4;
	vecHash.push_back(temp);
	Hashbucket = {};
	Hashbucket_two = {};
}

void Index::UpdataPushBackHashTable_1(TStream& tstream, Test test, double up4, vector<Cube>& cube, vector<double>& dimensionMin, int tag1)
{
	Hash temp;
	unsigned long long addr = 0;
	int n = ceil(log2(tstream.getLength() / (up4)));
	Hashbucket.clear();
	Hashbucket.resize(tag1 * 4);
	Hashbucket_two.clear();
	Hashbucket_two.resize(tag1 * 4 / 3);

	for (int i = 0; i < tag1; i++)
	{
		addr = Findaddr(tstream, cube[i].order, test.GetD(), dimensionMin, up4, n);
		if (addr < 0)
		{
			continue;
		}
		SetHashbucket(test, addr, Hashbucket, Hashbucket_two, cube[i].order);

	}
	temp.HashBucket = Hashbucket;
	temp.HashBucket_two = Hashbucket_two;
	temp.side = up4;
	temp.objectNumber = tag1;
	vecHashIndex.push_back(temp);
	Hashbucket = {};
	Hashbucket_two = {};
}


void Index::Init(TStream& tstream, Test test)
{
	int time = 2;
	if (test.GetD() == 3)
	{
		time = 2;
	}
	if (test.GetD() == 4)
	{
		time = 3;
	}
	if (test.GetD() == 5)
	{
		time = 4;
	}

	double scale;
	vector<double> leftCoordinate;
	Grid grid;
	bool flag = 0;
	int pointNum = test.GetWindows() / test.GetD();
	list<struct Cell> vecCellIndex;
	map<long long, Cell>myMap;
	Cell t;
	t.index.push_back(0);
	t.leftCoordinate = tstream.getLeftCoordinate();
	t.scale = tstream.getLength();
	myQue.push(t);
	for (int i = 0; i < pointNum; i++)
	{
		myQue.front().points.push_back(i);
	}
	myQue.front().addr = 0;
	while (!myQue.empty())
	{
		pointNum = myQue.front().points.size();
		if (myQue.front().index.size() > 1048576)
		{
			myQue.pop();
			continue;
		}
		scale = myQue.front().scale;
		leftCoordinate = myQue.front().leftCoordinate;
		grid.setGrid(pointNum, leftCoordinate, scale, test);
		int n = ceil(log2(tstream.getLength() / (grid.getLength())));
		if (n >= 30)
		{
			for (auto iter = myQue.front().points.begin(); iter != myQue.front().points.end(); iter++)
			{
				Cube t;
				t.index = myQue.front().index;
				t.order = *iter;
				t.side = myQue.front().scale;
				cube.push_back(t);
			}
			myQue.pop();
			continue;
		}

		for (auto iter = myQue.front().points.begin(); iter != myQue.front().points.end(); iter++)
		{
			int order = *iter;
			unsigned long long addr = 0;
			Cell_1 c;
			bool flag = 0;
			if (n > 20 && test.GetD() > 2)
			{
				flag = 1;
			}

			for (int j = 0; j < test.GetD(); j++)
			{
				if (flag == 1 && j == 1)
				{
					n = n / time;
				}
				unsigned long long temp = (tstream.getData((order * test.GetD()) + j) - grid.getLeftCoordinate(j)) / grid.getLength();
				c.leftCoordinate.push_back(temp * grid.getLength() + myQue.front().leftCoordinate[j]);
				addr = (addr << n) | temp;
			}
			if (addr < 0)
			{
				continue;
			}
			Cell a;
			a.addr = addr;
			a.leftCoordinate = c.leftCoordinate;
			a.index = myQue.front().index;
			a.points.push_back(order);
			a.scale = grid.getLength();
			std::pair<std::map<long long, Cell>::iterator, bool> ret1;
			ret1 = myMap.insert(make_pair(addr, a));
			if (!ret1.second)
			{
				myMap[addr].points.push_back(order);
			}

		}

		for (auto iter = myMap.begin(); iter != myMap.end(); iter++)
		{
			Cube t;
			if (iter->second.points.size() == 1)
			{
				iter->second.index = myQue.front().index;
				iter->second.index.push_back(iter->first);
				t.index = iter->second.index;
				t.order = iter->second.points.front();
				t.side = iter->second.scale;
				cube.push_back(t);
			}
			else if (iter->second.points.size() > 1)
			{
				iter->second.index = myQue.front().index;
				iter->second.index.push_back(iter->first);
				myQue.push(iter->second);
			}
		}
		myQue.pop();
		myMap.clear();
	}
}



void Index::CubeDivide(TStream& tstream, Test test)
{
	vector<Cube> vecS1;
	int tag1 = cube.size(), tag2 = 0;
	double up4 = 0;
	Hash temp;
	unsigned long long addr = 0;
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	while (1)
	{
		nth_element(cube.begin(), cube.begin() + tag1 / 4, cube.begin() + tag1);
		up4 = cube[tag1 / 4].side;
		int tagLength = tag1;
		int  vecS1Length = tag2;
		tag1 = 0;
		for (int i = 0; i < tagLength; i++)
		{
			if (cube[i].side >= up4)
			{
				vecS1.push_back(cube[i]);
				tag2++;
			}
			else if (cube[i].side < up4)
				cube[tag1++] = cube[i];
		}
		PushBackHashTable(tstream, test, up4 * 2, vecS1Length, vecS1, dimensionMin);
		if (tag1 == 0)
		{
			return;
		}
		if (tag1 <= 200)
		{
			PushBackHashTable_1(tstream, test, up4, cube, dimensionMin, tag1);
			break;

		}
	}
}
void Index::UpdataCubeDivide(TStream& tstream, Test test, int initPointNum)
{
	vector<Cube> vecS1;
	int tag1 = cube.size(), tag2 = 0;
	double up4 = 0;
	Hash temp;
	unsigned long long addr = 0;
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	if (tag1 == 0)
	{
		return;
	}
	if (tag1 <= initPointNum)
	{
		nth_element(cube.begin(), cube.begin() + tag1 / 4, cube.begin() + tag1);
		up4 = cube[tag1 / 4].side;
		up4 = pow(2, floor(log2(up4)));
		UpdataPushBackHashTable_1(tstream, test, up4, cube, dimensionMin, tag1);
		return;
	}
	while (1)
	{

		nth_element(cube.begin(), cube.begin() + tag1 / 4, cube.begin() + tag1);
		up4 = cube[tag1 / 4].side;
		up4 = pow(2, floor(log2(up4)));


		int tagLength = tag1;
		int  vecS1Length = tag2;
		tag1 = 0;
		for (int i = 0; i < tagLength; i++)
		{
			if (cube[i].side >= up4)
			{
				vecS1.push_back(cube[i]);
				tag2++;
			}
			else if (cube[i].side < up4)
			{
				cube[tag1++] = cube[i];
			}
		}
		if (tag1 == 0)
		{
			break;
		}

		if (vecS1Length != 0)
		{
			up4 = up4 * 2;
		}
		UpdataPushBackHashTable(tstream, test, up4, vecS1Length, vecS1, dimensionMin);

		if (tag1 <= initPointNum)
		{
			UpdataPushBackHashTable_1(tstream, test, up4, cube, dimensionMin, tag1);
			return;
		}

	}
}

void Index::UpdataInit(TStream& tstream, Test test, vector<int>& point, double side)
{

	int time = 2;
	if (test.GetD() == 3)
	{
		time = 2;
	}
	if (test.GetD() == 4)
	{
		time = 3;
	}
	if (test.GetD() == 5)
	{
		time = 4;
	}
	Grid grid;
	int flag;
	double scale = 0;
	vector<double> leftCoordinate;
	map<long long, Cell>myMap;
	cube.clear();
	int pointNum = nowPointNum;
	list<struct Cell> vecCellIndex;
	Cell t;
	t.index.push_back(0);
	t.leftCoordinate = tstream.getLeftCoordinate();
	t.scale = side;

	myQue.push(t);
	for (int i = 0; i < point.size(); i++)
	{
		myQue.front().points.push_back(point[i]);
	}


	while (!myQue.empty())
	{
		pointNum = myQue.front().points.size();
		if (myQue.front().index.size() > 1048576)
		{
			myQue.pop();
			continue;
		}
		scale = myQue.front().scale;
		leftCoordinate = myQue.front().leftCoordinate;
		grid.setGrid(pointNum, leftCoordinate, scale, test);
		int n = ceil(log2(tstream.getLength() / (grid.getLength())));
		if (n >= 30)
		{
			for (auto iter = myQue.front().points.begin(); iter != myQue.front().points.end(); iter++)
			{
				Cube t;
				t.index = myQue.front().index;
				t.order = *iter;
				t.side = myQue.front().scale;
				cube.push_back(t);
			}
			myQue.pop();
			continue;
		}

		for (auto iter = myQue.front().points.begin(); iter != myQue.front().points.end(); iter++)
		{
			int order = *iter;
			unsigned long long addr = 0;
			Cell_1 c;
			bool flag = 0;
			if (n > 20 && test.GetD() > 2)
			{
				flag = 1;
			}
			for (int j = 0; j < test.GetD(); j++)
			{
				if (flag == 1 && j == 1)
				{
					n = n / time;
				}
				int temp = (tstream.getData((order * test.GetD()) + j) - grid.getLeftCoordinate(j)) / grid.getLength();
				c.leftCoordinate.push_back(temp * grid.getLength() + myQue.front().leftCoordinate[j]);
				addr = (addr << n) | temp;
			}
			if (addr < 0)
			{
				continue;
			}
			Cell a;
			a.addr = addr;
			a.leftCoordinate = c.leftCoordinate;
			a.index = myQue.front().index;
			a.points.push_back(order);
			a.scale = grid.getLength();
			std::pair<std::map<long long, Cell>::iterator, bool> ret1;
			ret1 = myMap.insert(make_pair(addr, a));
			if (!ret1.second)
			{
				myMap[addr].points.push_back(order);
			}

		}

		for (auto iter = myMap.begin(); iter != myMap.end(); iter++)
		{
			Cube t;
			if (iter->second.points.size() == 1)
			{
				iter->second.index = myQue.front().index;
				iter->second.index.push_back(iter->first);
				t.index = iter->second.index;
				t.order = iter->second.points.front();
				t.side = iter->second.scale;
				cube.push_back(t);
			}
			else if (iter->second.points.size() > 1)
			{
				iter->second.index = myQue.front().index;
				iter->second.index.push_back(iter->first);
				myQue.push(iter->second);
			}
		}
		myQue.pop();
		myMap.clear();
	}
}






void Index::FindNearestNeighbor(TStream& tstream, Test test)
{
	vector<double> vecLeftCoordinate(test.GetD());
	vector<double> dimensionMin;
	vector<long long> pointIndex;
	tstream.setPointNeighbor(test);
	int order;
	vector<int> point;
	unsigned long long index = 0;
	unsigned long long addr = 0;
	int flag = 0;
	dimensionMin = tstream.getLeftCoordinate();

	for (auto iter3 = vecHash.rbegin(); iter3 != vecHash.rend(); iter3++)
	{
		GetPoint(*iter3, point, tstream);
		for (int i = 0; i < point.size(); i++)
		{
			order = point[i];
			for (auto iter0 = iter3; iter0 != vecHash.rend(); iter0++)
			{
				int n = ceil(log2(tstream.getLength() / (iter0->side)));

				if (n >= 30)
					break;


				addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, dimensionMin, iter0->side, n);

				if (addr < 0)
				{
					break;
				}

				index = addr;

				addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, iter0->side / 2, 1);

				FindPointIndex(test.GetD(), n, pointIndex, index, addr);

				HandelPointIndex(tstream, test, pointIndex, addr, *iter0, order);

			}

			if (tstream.pointNeighbor[order].neighbor == -1)
			{
				tstream.pointNeighbor[order].distance = iter3->side;
			}
		}
	}
}



void Index::DivideIndex(TStream& tstream, Test test)
{
	int tag1 = tstream.pointNeighbor.size(), tag2 = 0;
	double mid = 0;
	Hash temp;
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	while (1)
	{
		unsigned long long addr = 0;
		tag1 = tag1 - tag2;
		tag2 = 0;
		if (tag1 == 0)
		{
			break;
		}
		if (tag1 - tag2 <= test.GetK())
		{

			HandelPointNeighbor(tstream, test, tag1, tag2);
			break;
		}
		HandelPointNeighbor(tstream, test, tag1, tag2);

	}
}




void Index::FindIndex(TStream& tstream, Test test)
{
	int order = 0;
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	unsigned long long addr = 0;
	vector<int> point;
	for (auto iter3 = vecHashIndex.rbegin(); iter3 != vecHashIndex.rend(); iter3++)
	{
		GetPoint(*iter3, point, tstream);
		for (int i = 0; i < point.size(); i++)
		{
			if (point[i] >= 0)
			{
				order = point[i];
				auto t = iter3;
				for (auto iter0 = ++t; iter0 != vecHashIndex.rend(); iter0++)
				{
					int n = ceil(log2(tstream.getLength() / (iter0->side)));
					addr = Findaddr(tstream, order, test.GetD(), dimensionMin, iter0->side, n);
					if (addr < 0)
						continue;
					SetHashbucket(test, addr, iter0->HashBucket, iter0->HashBucket_two);
				}
			}
		}
		point.clear();
	}
}


void Index::UpdataTStream(TStream& tstream, Test test, vector<int>& vecTopkQuery)
{
	tstream.SetvecData_tag(test);
	int fenlie = 0, hebin = 0;
	unsigned long long order;
	unsigned long long addr = 0;
	int windowSize = test.GetWindows() / test.GetD();
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	vector<double> vecLeftCoordinate(test.GetD());
	vector<long long> pointIndex;
	unsigned long long index = 0;
	double distance = 0;
	int flag;
	vector<int> point;
	float test_in = 1;

	initPointNum = vecHashIndex.rbegin()->objectNumber;
	nowPointNum = vecHashIndex.rbegin()->objectNumber;

	int outObjId = tstream.vecData_tag;
	clock_t startTime1, endTime1;

	for (int tag = tstream.vecData_tag; tag < 52428800+ windowSize; tag++)
	{
		tstream.vecData_begin = tstream.vecData_begin + 1;

		if ((tstream.vecData_tag - test.GetWindows() / test.GetD()) % 1048576 == 1)
		{
			startTime1 = clock();
		}
		if ((tstream.vecData_tag - test.GetWindows() / test.GetD()) % 1048576 == 0&&tstream.vecData_tag>=1048576)
		{
			endTime1 = clock();
			cout << "Current cursor:" << tstream.vecData_tag << "     Time = " << (double)(endTime1 - startTime1) / CLOCKS_PER_SEC << "s" << endl;
		}


		order = tstream.vecData_tag++;

		for (auto iterVecHash = vecHashIndex.begin(); iterVecHash != vecHashIndex.end(); iterVecHash++)
		{
			if (iterVecHash->objectNumber > (int)iterVecHash->HashBucket.size())
			{
				point.clear();
				GetPoint(*iterVecHash, point, tstream, test);

				iterVecHash->HashBucket.resize(point.size() * 4);
				iterVecHash->HashBucket_two.resize(point.size() * 4 / 3);
				iterVecHash->objectNumber = (int)point.size();
				int n = ceil(log2(tstream.getLength() / (iterVecHash->side)));
				for (int i = 0; i < point.size(); i++)
				{
					addr = Findaddr(tstream, point[i], test.GetD(), dimensionMin, iterVecHash->side, n);
					if (addr < 0)
					{
						continue;
					}
					SetHashbucket(test, addr, iterVecHash->HashBucket, iterVecHash->HashBucket_two, point[i]);
				}
			}
		}




		if (test_in > 1)
		{
			if (tstream.vecData_tag - tstream.vecData_begin <= (test.GetWindows() / test.GetD()) / 2)
			{
				test.SetIn(0);
			}
			if (tstream.vecData_tag - tstream.vecData_begin == (test.GetWindows() / test.GetD()))
			{
				test.SetIn(test_in);
			}
		}
		else if (test_in < 1)
		{
			if (tstream.vecData_tag - tstream.vecData_begin >= (int)((test.GetWindows() / test.GetD()) * 1.5))
			{
				test.SetIn(test_in * 100);
			}
			if (tstream.vecData_tag - tstream.vecData_begin - (test.GetWindows() / test.GetD()) <= test_in * 100)
			{
				test.SetIn(test_in);
			}
		}

		if (tstream.vecData_tag < tstream.vecData_begin)
		{
			break;
		}
		bool flag_1 = 0;
		bool flag_2 = 0;

		if (tstream.vecData_tag % 10000 == 0)
		{
			TopkPariQuery(tstream, test, vecTopkQuery);
		}

		if (tstream.vecData_tag % (test.GetWindows() / test.GetD()) == 0)
		{
			int sum = 0;
			for (auto iterVecHash = vecHashIndex.begin(); iterVecHash != vecHashIndex.end(); iterVecHash++)
			{
				sum += iterVecHash->objectNumber;
			}
			if (sum > 2 * test.GetWindows() / test.GetD())
			{
				for (auto iterVecHash = vecHashIndex.rbegin(); iterVecHash != vecHashIndex.rend(); iterVecHash++)
				{
					deleteOutDateObject(*iterVecHash, tstream.vecData_begin, tstream, test);
				}
			}


			if (vecHashIndex.size() > 2)
			{
				if (vecHashIndex.rbegin()->objectNumber > 4 * initPointNum)
				{
					point.clear();
					GetPoint(*vecHashIndex.rbegin(), point, tstream);

					double side = vecHashIndex.rbegin()->side;
					UpdataInit(tstream, test, point, side);
					vecHashIndex.pop_back();
					UpdataCubeDivide(tstream, test, initPointNum);

				}

				if (vecHashIndex.rbegin()->objectNumber < initPointNum / 4)
				{
					point.clear();
					double side = vecHashIndex.rbegin()->side;
					GetPoint(*++vecHashIndex.rbegin(), point, tstream);
					vector<int>point1;
					GetPoint(*vecHashIndex.rbegin(), point1, tstream);
					for (int i = 0; i < point1.size(); i++)
					{
						if (point1[i] < 0)
							continue;
						point.push_back(point1[i]);
					}

					UpdataInit(tstream, test, point, side);
					vecHashIndex.pop_back();
					vecHashIndex.pop_back();
					UpdataCubeDivide(tstream, test, initPointNum);
				}
			}

		}



		for (auto iter = vecHashIndex.begin(); iter != vecHashIndex.end(); iter++)
		{

			distance = 0;
			flag = 0;
			int n = ceil(log2(tstream.getLength() / (iter->side)));
			if (n < 0 || n >= 30)
			{
				flag_2 = 1;
				break;
			}
			addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, dimensionMin, iter->side, n);

			if (addr < 0)
			{
				flag_1 = 1;
				break;
			}


			index = addr;

			addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, iter->side / 2, 1);

			FindPointIndex(test.GetD(), n, pointIndex, index, addr);

			HandelPointIndex_Updata(tstream, test, pointIndex, index, *iter, order, distance, flag);

			if (flag == 0)
			{
				break;
			}
		}



		if (flag_2 == 1)
		{
			continue;
		}

		if (flag_1 == 1)
		{
			continue;
		}




		for (auto iter = vecHashIndex.begin(); iter != vecHashIndex.end(); iter++)
		{
			if (iter->side <= distance || iter->side == vecHashIndex.rbegin()->side)
			{
				int n = ceil(log2(tstream.getLength() / (iter->side)));
				if (n >= 30)
				{
					break;
				}
				addr = Findaddr(tstream, order, test.GetD(), dimensionMin, iter->side, n);
				if (addr < 0)
					break;
				SetHashbucket(test, addr, iter->HashBucket, iter->HashBucket_two, order);

				iter->objectNumber++;
				break;
			}
			int n = ceil(log2(tstream.getLength() / (iter->side)));
			if (n >= 30)
			{
				break;
			}
			addr = Findaddr(tstream, order, test.GetD(), dimensionMin, iter->side, n);
			if (addr < 0)
				break;
			SetHashbucket(test, index, iter->HashBucket, iter->HashBucket_two);
		}
	}
}

