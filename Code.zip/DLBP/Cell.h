#pragma once

#include <vector>
#include <list>
using namespace std;

struct Cube
{
	int order;

	double side = 0;

	list<int> index;

	bool operator < (const Cube& P)const
	{
		return side < P.side;
	}

};
struct Cell_1
{
	vector<double> leftCoordinate;
	list<int> points;
	list<int> index;
	double scale;
};
struct Cell
{
	unsigned long long addr;
	vector<double> leftCoordinate;
	list<int> points;
	list<int> index;
	double scale;
};