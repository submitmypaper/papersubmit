#include "Grid.h"
#include "Test.h"

Grid::Grid()
{
}


Grid::~Grid()
{
}

void Grid::setGrid(int p, vector<double> l, double len, Test test)
{
	int dimension = test.GetD();
	double sideNum = pow(p, (double)1 / dimension);
	int n = ceil(log2(sideNum));
	sideNum = pow(2, n);
	length = len/ sideNum;
	pointNum = p;
	leftCoordinate = l;
}



int Grid::getPointNum()
{
	return pointNum;
}

double Grid::getLeftCoordinate(int i)
{
	return leftCoordinate[i];
}

Grid Grid::getGrid()
{

	return Grid();
}

double Grid::getLength()
{
	return length;
}


