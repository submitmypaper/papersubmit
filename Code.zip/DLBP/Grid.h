#pragma once
#include "TStream.h"
#include "Test.h"
class Grid
{
public:
	Grid();
	~Grid();
	void setGrid(int pointNum, vector<double> leftCoordinate, double length,Test test);

	int getPointNum();

	double getLeftCoordinate(int i);

	Grid getGrid();

	double getLength();
private:
	int pointNum;
	vector<double> leftCoordinate;
	double length;

};

