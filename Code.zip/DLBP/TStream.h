#pragma once
#include <vector>
#include "Test.h"
using namespace std;
class TStream
{
public:
	TStream();
	~TStream();

	void setFilData(int j);

	void setPointNeighbor(Test test);

	double getData(int ID);

	long GetvecDataLen();

	void setRange(Test test);
	vector<double> getLeftCoordinate();

	double cleanData(double number);
	void SetvecData_tag(Test test);

	void InitPoint(Test test);
	double getLength();
	struct PointNeighbor
	{
		int order;
		int neighbor;
		double distance;

		bool operator < (const PointNeighbor& P)const
		{
			return distance < P.distance;
		}
	};
	vector<PointNeighbor> pointNeighbor;
	double vecData_begin = 0;
	long vecData_tag = 0;
private:
	vector<double> vecData;
	vector<double> leftCoordinate;
	double length;
	double max=0;
};

