#include "TStream.h"
#include <fstream>
#include <iostream>
#include <cmath>
#include <random>
#include <string>
using namespace std;
#pragma warning(disable:4996)


TStream::TStream()
{
}


TStream::~TStream()
{
}

double TStream::getData(int ID)
{
	return vecData[ID];
}

long TStream::GetvecDataLen()
{
	return vecData.size();
}

void TStream::setRange(Test test)
{
	for (int i = 0; i < test.GetD(); i++)
	{
		leftCoordinate.push_back(0);
	}
	max = ceil(max);
	length = max;
	length = pow(2, ceil(log2(length)));

}

vector<double> TStream::getLeftCoordinate()
{
	return leftCoordinate;
}

double TStream::cleanData(double number)
{
	const int SEED = 666;
	default_random_engine dre(SEED);

	uniform_real_distribution<float> d(0, 500);
	return number + d(dre);
}

void TStream::InitPoint(Test test)
{
	PointNeighbor t;
	for (int i = 0; i < test.GetWindows() / test.GetD(); i++)
	{
		t.neighbor = -1;
		t.distance = 0x3f3f3f3f;
		pointNeighbor.push_back(t);
	}
}

double TStream::getLength()
{
	return length;
}

void TStream::SetvecData_tag(Test test)
{
	vecData_tag = test.GetWindows() / test.GetD();
}





void TStream::setFilData(int j)
{
	FILE* fp1;
	double n;
	int i = 0;
	string a = to_string(j);
	string s = "SourceFile" + a + ".txt";
	if ((fp1 = fopen(s.data(), "r")) != NULL)
	{
		while (fscanf(fp1, "%lf", &n) != EOF)
		{
			if (n > max)
			{
				max = n;
			}
			vecData.push_back(n);
			i++;
		}
	}
}

void TStream::setPointNeighbor(Test test)
{
	pointNeighbor.resize(test.GetWindows() / test.GetD());
	for (int i = 0; i < test.GetWindows() / test.GetD(); i++)
	{
		pointNeighbor[i].order = i;
	}
}



