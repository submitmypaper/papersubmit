#include <iostream>
using namespace std;
#include "TStream.h"
#include "Test.h"
#include "Index.h"
#include <ctime>
#include <fstream>
#pragma warning(disable:4996)
#include<random>


int main()
{
	FILE * fp1;
	fp1 = fopen("TopkQuery.txt", "r");
	clock_t startTime, endTime,treetime;
	double inittime = 0, createtreetime = 0;
	int number;
	vector<int> vecTopkQuery;
	while (fscanf(fp1, "%d", &number) != EOF)
	{
		vecTopkQuery.push_back(number);
	}
	for (int j = 0; j < 5; j++) {
		Test test;
		vector<Test> vecTestFile;
		TStream tstream;
		tstream.setFilData(j);
		test.Init(vecTestFile,j);
		tstream.setRange(vecTestFile[0]);
		for (int i = 0; i < vecTestFile.size(); i++)
		{
			tstream.pointNeighbor.clear();
			tstream.vecData_begin = 0;
			tstream.InitPoint(vecTestFile[i]);
			Index index;

			startTime = clock();
			index.Init(tstream, vecTestFile[i]);
			index.CubeDivide(tstream, vecTestFile[i]);
			index.FindNearestNeighbor(tstream, vecTestFile[i]);
			index.SetTIME(vecTestFile[i].GetTime());
			index.SetNF(vecTestFile[i].GetK());
			index.DivideIndex(tstream, vecTestFile[i]);
			index.FindIndex(tstream, vecTestFile[i]);
			endTime = clock();
			inittime = (float)(endTime - startTime) / CLOCKS_PER_SEC;
			cout << "Init Time : " << (float)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;

			clock_t s1, s2;

			s1 = clock();
			index.UpdataTStream(tstream, vecTestFile[i], vecTopkQuery);
			s2 = clock();
			cout << "Updata Time = " << (float)(s2 - s1) / CLOCKS_PER_SEC << "s" << endl;
			cout << "Process " << 52428800 / (float)(s2 - s1) / CLOCKS_PER_SEC << " data per second " << endl;
		}
	}

	system("pause");
}