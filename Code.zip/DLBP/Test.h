#pragma once
#include<vector>
using namespace std;
class Test
{
public:

	Test();
	~Test();
	void SetD(int d);

	void SetK(int k);

	void SetWindows(long w);

	void SetIn(int in);

	void SetTime(int time);

	int GetD();

	int GetK();

	long GetWindows();

	int GetIn();

	int GetTime();

	void setTestData();

	void Init(vector<Test>& vecTestFile,int j);


private:
	int t_D;

	int t_K;

	long t_Windows;

	int t_In;

	int t_Time;

};

