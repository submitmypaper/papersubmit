#include "Test.h"
#include <string>
#pragma warning(disable:4996)
Test::Test()
{
}

Test::~Test()
{
}

int Test::GetDimension()
{
	return dimension;
}

int Test::GetTopK()
{
	return topK;
}
int Test::GetWindowSize()
{
	return windowSize;
}

int Test::GetInFlow()
{
	return inFlow;
}

int Test::GetOutFlow()
{
	return outFlow;
}

int Test::GetQueryCycle()
{
	return queryCycle;
}

void Test::SetDimension(int d)
{
	dimension = d;
}

void Test::SetTopK(int k)
{
	topK = k;
}

void Test::SetWindowSize(int w)
{
	windowSize = w;
}

void Test::SetInFlow(int in)
{
	inFlow = in;
}

void Test::SetOutFlow(int out)
{
	outFlow = out;
}

void Test::SetQueryCycle(int c)
{
	queryCycle = c;
}


void Test::Init(vector<Test>& vecTestFile,int j)
{
	FILE* fp;
	string a = to_string(j);
	string s = "test" + a + ".txt";
	fp = fopen(s.data(), "r");
	int n;
	int i = 0;
	Test test;
	while (fscanf(fp, "%d", &n) != EOF)
	{
		if (i % 5 == 0)
		{
			test.SetDimension(n);
		}
		if (i % 5 == 1)
		{
			test.SetTopK(n);
		}
		if (i % 5 == 2)
		{
			test.SetWindowSize(n);
		}
		if (i % 5 == 3)
		{
			test.SetInFlow(n);
		}
		if (i % 5 == 4)
		{
			test.SetQueryCycle(n);
		}
		i++;
		if (i % 5 == 0 && i != 0)
		{
			test.SetOutFlow(1);
			vecTestFile.push_back(test);
		}
	}
}
