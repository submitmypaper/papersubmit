﻿#include <iostream>
#include <fstream>
#include"Test.h"
#include"Tree.h"
#include"TStream.h"
using namespace std;

int main() {
	clock_t startTime, endTime;
	double inittime = 0, createtreetime = 0;
	for (int j = 0; j < 5; j++) {
		Test test;
		TStream tstream;
		vector<Test> vecTestFile;
		test.Init(vecTestFile,j);
		tstream.Init(vecTestFile[0],j);
		tstream.setRange(vecTestFile[0]);
		for (int i = 0; i < vecTestFile.size(); i++)
		{
			double time = 0;
			Tree tree;
			tstream.SetDataStreamBegin(0);
			tstream.SetDataStreamTag(vecTestFile[i].GetWindowSize() / vecTestFile[i].GetDimension());
			startTime = clock();
			tree.CreateTree(tstream, vecTestFile[i]);
			endTime = clock();
			createtreetime = (double)(endTime - startTime) / CLOCKS_PER_SEC;
			tree.TraversalTree(tstream, vecTestFile[i]);
			endTime = clock();
			inittime = (double)(endTime - startTime) / CLOCKS_PER_SEC;
			cout << (double)(endTime - startTime) / CLOCKS_PER_SEC << endl;
			startTime = clock();
			tree.UpdateDataFlow(tstream, vecTestFile[i]);
			endTime = clock();
			cout << (double)(endTime - startTime) / CLOCKS_PER_SEC << endl;
			cout << "Process " << 52428800 / ((double)(endTime - startTime) / CLOCKS_PER_SEC) << " data per second " << endl;
		}
	}
	system("pause");
	return 0;
}