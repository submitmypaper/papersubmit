#include "TStream.h"
#include "Test.h"
#include <string>
#pragma warning(disable:4996)
TStream::TStream()
{
}

TStream::~TStream()
{
}
void TStream::ReadDataFile(int j)
{
	FILE* fp1;
	double dlNumber;
	double maxData = 0;
	double step = 0.05;
	int objectNumber = 0;
	string a = to_string(j);
	string s = "SourceFile" + a + ".txt";
	if ((fp1 = fopen(s.data(), "r")) != NULL)
	{
		while (fscanf(fp1, "%lf", &dlNumber) != EOF)
		{
			if (maxData < dlNumber)
				maxData = dlNumber;
			vecDataStream.push_back(dlNumber);
		}
	}
}
double TStream::GetDataStream(int intObjectNumber)
{
	return vecDataStream[intObjectNumber];
}

int TStream::GetDataStreamLength()
{
	return vecDataStream.size();
}

void TStream::setRange(Test& test)
{
	int objnum = GetDataStreamLength() / test.GetDimension();
	for (int i = 0; i < objnum; i++) {
		for (int j = 0; j < test.GetDimension(); j++) {
			if (i == 0) {
				DimensionMax.push_back(vecDataStream[j]);
				DimensionMin.push_back(vecDataStream[j]);
			}
			else {
				if (DimensionMax[j] < vecDataStream[i * test.GetDimension() + j])
					DimensionMax[j] = vecDataStream[i * test.GetDimension() + j];
				if (DimensionMin[j] > vecDataStream[i * test.GetDimension() + j])
					DimensionMin[j] = vecDataStream[i * test.GetDimension() + j];
			}
		}
	}
}


int TStream::GetDataStreamBegin()
{
	return dataStreamBegin;
}

int TStream::GetDataStreamTag()
{
	return dataStreamTag;
}

void TStream::SetDataStreamBegin(int begin)
{
	dataStreamBegin = begin;
}

void TStream::SetDataStreamTag(int tag)
{
	dataStreamTag = tag;
}

void TStream::Init(Test test,int j)
{
	ReadDataFile(j);
	SetDataStreamTag(test.GetWindowSize() / test.GetDimension());
	SetDataStreamBegin(0);
}

void TStream::AddDataStreamBegin(int outflow)
{
	dataStreamBegin += outflow;
}

void TStream::AddDataStreamTag(int inflow)
{
	dataStreamTag += inflow;
}

vector<double> TStream::GetDimensionMax()
{
	return DimensionMax;
}

vector<double> TStream::GetDimensionMin()
{
	return DimensionMin;
}
