#pragma once
#include <list>
#include <vector>
#include <map>
#include <queue>
#include "Tree.h"
#include "TStream.h"
using namespace std;

class Tree {
public:
	struct MBR
	{
		int hight = 0;
		int MBRID = 0;
		int maxSpan = 0;
		int minSpan = 0;
		MBR* fatherNode = NULL;
		double area = 1;
		vector<double> centerPoint;
		list<int> listObject;
		list<MBR*> listChild;
		vector<int> maxDimOrder;
		vector<double> vecLeftDown;
		vector<double> vecRightUp;
	};
	struct Pair
	{
		int objId;
		int neighborId;
	};
	int GetID();
	void AddID(int add);
	void CreateTree(TStream& tstream, Test& test);
	void RootInit(TStream& tstream, Test& test);
	void NodeSplit(TStream& tstream, Test& test, MBR* node, queue<MBR*>& queCreateTree, bool flag);
	void NodeSplitAgain(TStream& tstream, Test& test, MBR* node, MBR* fatherNode, queue<MBR*>& queCreateTree, bool flag);
	void SelectDimension(Test& test, MBR* node);
	void SetLeftNodeVar(TStream& tstream, Test& test, MBR* node, MBR* fatherNode, int dimension, double mid);
	void SetRightNodeVar(TStream& tstream, Test& test, MBR* node, MBR* fatherNode, int dimension, double mid);
	void LinkNode(MBR* node, queue<MBR*> queCreateTree);

	void TraversalTree(TStream& tstream, Test& test);
	void CalculateMBR(TStream& tstream, Test& test, MBR* node);
	double GetInitRadius(TStream& tstream, Test& test, MBR* node, int id, int& neighbor, int& ObjNum);
	double GetDistance(TStream& tstream, Test& test, int id1, int id2);
	double GetDistanceBrothers(TStream& tstream, Test& test, MBR* node, int id);
	void FindNeighbor(TStream& tstream, Test& test, int objId, int& neighbor, double& radius, int& objNum, MBR* node);
	void InsertMapCandidateSet(int objId, int neighbor, double distance);
	void Prune(TStream& tstream, Test& test, MBR* node, int objId, double radius, queue<MBR*>& queResultLevelOrder);

	void AllObjNum(TStream& tstream, Test& test);
	void UpdateDataFlow(TStream& tstream, Test& test);
	void UpdataCandidateSet(int tstreamBegin);
	bool UpdateSplit(TStream& tstream, Test& test, MBR* node, MBR* fatherNode, queue<MBR*>& que);
	MBR* ObjectInsert(TStream& tstream, Test& test, int id);
	void SplitNodes(Test& test, MBR* node);
	void CheckScale(Test& test, MBR* node);
	MBR* FindMBR(TStream& tstream, Test& test, queue<MBR*>& queNode, int objId);
	void SetNewMBRVar(Test& test, MBR* node, MBR* oldNode);
	bool IsCover(TStream& tstream, Test& test, MBR* node, int objId);
	bool QueryField(TStream& tstream, Test& test, MBR* node, int objId, queue<MBR*>& queNode);
	void DeleteOverDueObj(TStream& tstream, Test& test, int& objNum);
	void MergeMBR(TStream& tstream, Test& test, MBR* node);
	void UpdateMBR(TStream& tstream, Test& test, MBR* node);
	void UpdateLeafMBR(TStream& tstream, Test& test, MBR* node);
	void UpdateMBRSide(TStream& tstream, Test& test, MBR* node);
	void CheckMiddleNode(TStream& tstream, Test& test, MBR* node);

	MBR* CreateMBR(TStream& tstream, Test& test, MBR* node, int objId);
	MBR* DealOutsidePoints(TStream& tstream, Test& test, MBR* node, int objId);
	double GetMinIncrement(Test& test, MBR* node, vector<double>& expandLeftDown, vector<double>& expandRightUp, MBR* child);
	double GetCenterPointDis(TStream& tstream, Test& test, MBR* node, int id);
	void DestroyTree(TStream& tstream, Test& test);
	void ReCreateTree(TStream& tstream, Test& test);
	void GetTotalArea(TStream& tstream, Test& test, MBR* node);

	MBR* newObjectInsert(TStream& tstream, Test& test, int id);
	void expandMBR(TStream& tstream, Test& test, int id, MBR* node);
	void expandAreaAndmaxDimOrder(TStream& tstream, Test& test, MBR* node);
	double calculateDisToNode(TStream& tstream, Test& test, int id, MBR* node);
	void checkSplit(TStream& tstream, Test& test, MBR* node, MBR* &returnMBR,int id);
	void NewNodeSplitAgain(TStream& tstream, Test& test, MBR* &node, MBR* fatherNode,int id);
	void calCenter(Test& test, MBR*& node, vector<vector<double>>& center);
	void newsplitNode(Test& test, MBR* node1, MBR* node2, MBR* node);
	double caldisintovec(Test& test, vector<double> v1, vector<double> v2);
	void NewSetMBR(Test& test, MBR* node);
	void PrintMapSet(Test& test, int datasBegin);
private:
	MBR* root = NULL;
	long double totalArea = 0;
	long double updataTotalArea = 0;
	map<double, Pair> mapCandidateSet;
	int ID = 0;
};