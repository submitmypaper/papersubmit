#pragma once
#include <vector>
#include <math.h>
#include "Test.h"
using namespace std;
class TStream
{
public:

	TStream();
	~TStream();

	void ReadDataFile(int j);
	double GetDataStream(int intObjectNumber);
	int GetDataStreamLength();
	void setRange(Test& test);
	int GetDataStreamBegin();
	int GetDataStreamTag();
	void SetDataStreamBegin(int begin);
	void SetDataStreamTag(int tag);
	void Init(Test test,int j);
	void AddDataStreamBegin(int outflow);
	void AddDataStreamTag(int inflow);
	vector<double> GetDimensionMax();
	vector<double> GetDimensionMin();
private:
	struct ObjectNeighbor
	{
		int object;
		int objectNeighbor;
		double distance;

		bool operator < (const ObjectNeighbor& P)const
		{
			return distance < P.distance;
		}
	};
	vector<double> vecDataStream;
	int dataStreamBegin = 0;
	int dataStreamTag = 0;
	vector<double> DimensionMax;
	vector<double> DimensionMin;
};
