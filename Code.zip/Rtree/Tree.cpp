#include "Tree.h"
#include <queue>
#include <numeric>
#include <fstream>
#include <limits.h>
#include <set>
#include <stack>
#include<algorithm>

using namespace std;
#define NUM 4

static int  nodenum = 0;
static long long int queryObjNum = 0;
static int OBJNUM1 = 0;
static int OBJNUM2 = 0;
static int OBJNUM3 = 0;
static int OBJNUM4 = 0;
static int OBJNUM5 = 0;
static bool ReCreateTreeFlag = false;
int Tree::GetID()
{
	return ID;
}

void Tree::AddID(int add)
{
	ID += add;
}
void Tree::CreateTree(TStream& tstream, Test& test)
{
	int temp = 0;
	bool flag = false;
	RootInit(tstream, test);
	queue<MBR*> queCreateTree;
	queCreateTree.push(root);
	MBR* node = NULL;
	while (queCreateTree.size() < NUM) {
		node = queCreateTree.front();
		NodeSplit(tstream, test, node, queCreateTree, flag);
		queCreateTree.pop();
	}
	LinkNode(root, queCreateTree);
	flag = true;
	while (!queCreateTree.empty()) {
		node = queCreateTree.front();
		if (node->listObject.size() < NUM) {
			SelectDimension(test, node);
			if (node->hight > temp)
				temp = node->hight;
			queCreateTree.pop();
			continue;
		}
		NodeSplit(tstream, test, node, queCreateTree, flag);
		queCreateTree.pop();
	}
	GetTotalArea(tstream, test, root);
}

void Tree::RootInit(TStream& tstream, Test& test)
{
	root = new MBR;
	root->fatherNode = NULL;
	for (int i = 0; i < test.GetWindowSize() / test.GetDimension(); i++) {
		root->listObject.push_back(i);
	}
	root->vecLeftDown = tstream.GetDimensionMin();
	root->vecRightUp = tstream.GetDimensionMax();
	root->MBRID = GetID();
}

void Tree::NodeSplit(TStream& tstream, Test& test, MBR* node, queue<MBR*>& queCreateTree, bool flag)
{
	vector<double> temp;
	SelectDimension(test, node);
	double mid = 0;
	int i = 0;
	double max = -1, min = INT16_MAX;
	MBR* node1 = new MBR;
	MBR* node2 = new MBR;
	while (true) {
		if (i == test.GetDimension())
			break;
		for (auto iter = node->listObject.begin(); iter != node->listObject.end(); iter++) {
			temp.push_back(tstream.GetDataStream((*iter) * test.GetDimension() + node->maxDimOrder[i]));
		}
		nth_element(temp.begin(), temp.begin() + temp.size() / 2, temp.end());
		mid = temp[temp.size() / 2];
		for (auto iter = node->listObject.begin(); iter != node->listObject.end(); iter++) {
			if (tstream.GetDataStream((*iter) * test.GetDimension() + node->maxDimOrder[i]) <= mid) {
				node1->listObject.push_back(*iter);
			}
			else if (tstream.GetDataStream((*iter) * test.GetDimension() + node->maxDimOrder[i]) > mid) {
				node2->listObject.push_back(*iter);
			}
		}
		if (node2->listObject.size() != 0) {
			break;
		}
		temp.clear();
		node1->listObject.clear();
		i++;

	}
	if (i != test.GetDimension()) {
		SetLeftNodeVar(tstream, test, node1, node, node->maxDimOrder[i], mid);
		SetRightNodeVar(tstream, test, node2, node, node->maxDimOrder[i], mid);
		CalculateMBR(tstream, test, node1);
		CalculateMBR(tstream, test, node2);
		NodeSplitAgain(tstream, test, node1, node, queCreateTree, flag);
		NodeSplitAgain(tstream, test, node2, node, queCreateTree, flag);
		node->listObject.clear();
	}
	else if (i == test.GetDimension()) {
		delete node1;
		delete node2;
	}
}

void Tree::NodeSplitAgain(TStream& tstream, Test& test, MBR* node, MBR* fatherNode, queue<MBR*>& queCreateTree, bool flag)
{
	int i = 0;
	vector<double> temp;
	SelectDimension(test, node);
	double mid = 0;
	double max = -1, min = INT16_MAX;
	MBR* node1 = new MBR;
	MBR* node2 = new MBR;
	while (true) {
		if (i == test.GetDimension())
			break;
		for (auto iter = node->listObject.begin(); iter != node->listObject.end(); iter++) {
			temp.push_back(tstream.GetDataStream((*iter) * test.GetDimension() + node->maxDimOrder[i]));
		}
		nth_element(temp.begin(), temp.begin() + temp.size() / 2, temp.end());
		mid = temp[temp.size() / 2];
		for (auto iter = node->listObject.begin(); iter != node->listObject.end(); iter++) {
			if (tstream.GetDataStream((*iter) * test.GetDimension() + node->maxDimOrder[i]) <= mid) {
				node1->listObject.push_back(*iter);
			}
			else if (tstream.GetDataStream((*iter) * test.GetDimension() + node->maxDimOrder[i]) > mid) {
				node2->listObject.push_back(*iter);
			}
		}
		if (node2->listObject.size() != 0) {
			break;
		}
		temp.clear();
		node1->listObject.clear();
		i++;

	}
	if (i != test.GetDimension()) {
		SetLeftNodeVar(tstream, test, node1, node, node->maxDimOrder[i], mid);
		SetRightNodeVar(tstream, test, node2, node, node->maxDimOrder[i], mid);
		CalculateMBR(tstream, test, node1);
		CalculateMBR(tstream, test, node2);
		SelectDimension(test, node1);
		SelectDimension(test, node2);
		queCreateTree.push(node1);
		queCreateTree.push(node2);
		if (flag == true) {
			fatherNode->listChild.push_back(node1);
			node1->fatherNode = fatherNode;
			fatherNode->listChild.push_back(node2);
			node2->fatherNode = fatherNode;
		}
		node->listObject.clear();
		if (node->fatherNode != NULL)
			node->fatherNode->listChild.remove(node);
		if (node->fatherNode == NULL)
			delete node;
	}
	else if (i == test.GetDimension())
	{
		if (node->fatherNode == NULL) {
			node->fatherNode = fatherNode;
			fatherNode->listChild.push_back(node);
		}
		delete node1;
		delete node2;
	}
}

void Tree::SelectDimension(Test& test, MBR* node)
{
	vector<double> temp(test.GetDimension());
	node->maxDimOrder.resize(test.GetDimension());
	double dev = -1, dev2 = 0xffffff;
	for (int i = 0; i < test.GetDimension(); i++) {
		temp[i] = node->vecRightUp[i] - node->vecLeftDown[i];
	}
	for (int i = 0; i < temp.size(); i++) {
		for (int j = 0; j < temp.size(); j++) {
			if (temp[j] > dev) {
				dev = temp[j];
				node->maxDimOrder[i] = j;
			}
		}
		dev = -1;
		temp[node->maxDimOrder[i]] = -1;
	}
}

void Tree::SetLeftNodeVar(TStream& tstream, Test& test, MBR* newNode, MBR* node, int dimension, double mid)
{
	AddID(1);
	newNode->MBRID = GetID();
	newNode->hight = node->hight + 1;
	newNode->vecLeftDown = node->vecLeftDown;
	newNode->vecRightUp = node->vecRightUp;
	newNode->vecRightUp[dimension] = mid;
}

void Tree::SetRightNodeVar(TStream& tstream, Test& test, MBR* newNode, MBR* node, int dimension, double mid)
{
	AddID(1);
	newNode->MBRID = GetID();
	newNode->hight = node->hight + 1;
	newNode->vecLeftDown = node->vecLeftDown;
	newNode->vecRightUp = node->vecRightUp;
	newNode->vecLeftDown[dimension] = mid;
}

void Tree::LinkNode(MBR* node, queue<MBR*> queCreateTree)
{
	while (!queCreateTree.empty()) {
		node->listChild.push_back(queCreateTree.front());
		queCreateTree.front()->fatherNode = node;
		queCreateTree.pop();
	}
}

void Tree::TraversalTree(TStream& tstream, Test& test)
{
	queue<MBR*> queNode;
	queNode.push(root);
	int neighbor = -1;
	int num = 0;
	double queryRadius = 0;
	while (!queNode.empty()) {
		if (queNode.front()->listChild.size() == 0) {

			for (auto iter = queNode.front()->listObject.begin(); iter != queNode.front()->listObject.end(); iter++) {
				neighbor = -1;
				queryRadius = GetInitRadius(tstream, test, queNode.front(), *iter, neighbor, num);
				if (queryRadius != 0)
				{
					FindNeighbor(tstream, test, *iter, neighbor, queryRadius, num, queNode.front());
				}
				if (neighbor != -1) {
					InsertMapCandidateSet(*iter, neighbor, queryRadius);
				}
			}
		}
		else {
			for (auto iter = queNode.front()->listChild.begin(); iter != queNode.front()->listChild.end(); iter++) {
				queNode.push(*iter);
			}
		}
		queNode.pop();
	}
}

void Tree::CalculateMBR(TStream& tstream, Test& test, MBR* node)
{
	double leftDown = 0xffffff, rightUp = 0, temp = 0;
	node->centerPoint.resize(test.GetDimension());
	for (int i = 0; i < test.GetDimension(); i++) {
		for (auto iter = node->listObject.begin(); iter != node->listObject.end(); iter++) {
			if (leftDown > tstream.GetDataStream(*iter * test.GetDimension() + i)) {
				leftDown = tstream.GetDataStream(*iter * test.GetDimension() + i);
			}
			if (rightUp < tstream.GetDataStream(*iter * test.GetDimension() + i)) {
				rightUp = tstream.GetDataStream(*iter * test.GetDimension() + i);
			}
		}
		node->vecLeftDown[i] = leftDown;
		node->vecRightUp[i] = rightUp;
		node->area = node->area * (node->vecRightUp[i] - node->vecLeftDown[i]);
		temp = (node->vecLeftDown[i] + node->vecRightUp[i]) / 2;
		node->centerPoint[i] = temp;
		leftDown = 0xffffff;
		rightUp = 0;
	}
	node->area = sqrt(node->area);
}

double Tree::GetInitRadius(TStream& tstream, Test& test, MBR* node, int id, int& neighbor, int& ObjNum)
{
	int i = 0;
	double distance = 0, MinDistance = 100;
	if (node->listObject.size() > 1) {
		for (auto iter = node->listObject.begin(); iter != node->listObject.end();) {
			if (*iter < tstream.GetDataStreamBegin()) {
				iter = node->listObject.erase(iter);
				ObjNum--;
			}
			else
			{
				if (*iter != id) {
					distance = GetDistance(tstream, test, id, *iter);
					if (distance < MinDistance) {
						MinDistance = distance;
						neighbor = *iter;
					}
				}
				iter++;
			}
		}
	}
	else if (node->listObject.size() <= 1 || MinDistance == 100 || MinDistance == 0) {
		return 100;
	}
	return MinDistance;
}

double Tree::GetDistance(TStream& tstream, Test& test, int id1, int id2)
{
	double result = 0;
	for (int i = 0; i < test.GetDimension(); i++)
	{
		result += pow(tstream.GetDataStream(id1 * test.GetDimension() + i) - tstream.GetDataStream(id2 * test.GetDimension() + i), 2);
	}
	return  sqrt(result);
}

double Tree::GetDistanceBrothers(TStream& tstream, Test& test, MBR* node, int id)
{
	double result = 0;
	for (int i = 0; i < test.GetDimension(); i++)
	{
		double temp, temp1, temp2;
		temp = tstream.GetDataStream(id * test.GetDimension() + i);
		temp1 = node->vecLeftDown[i];
		temp2 = node->vecRightUp[i];
		if (temp < temp1)
		{
			result += pow(abs(temp - temp1), 2);
		}
		else if (temp > temp2)
		{
			result += pow(abs(temp2 - temp), 2);
		}
	}
	result = sqrt(result);
	return result;
}

void Tree::FindNeighbor(TStream& tstream, Test& test, int objId, int& neighbor, double& radius, int& objNum, MBR* node)
{
	int i = 0;
	double dis;
	queue<MBR*> queNode;
	queue<MBR*> stackNode;
	stackNode.push(node);
	
	while (node->fatherNode != NULL) {
		node = node->fatherNode;
		stackNode.push(node);
	}
	while (!stackNode.empty()) {
		if (stackNode.front()->fatherNode != NULL) {
			for (auto iter = stackNode.front()->fatherNode->listChild.begin(); iter != stackNode.front()->fatherNode->listChild.end(); iter++)
			{
				if ((*iter)->MBRID != stackNode.front()->MBRID) {
					double a = GetDistanceBrothers(tstream, test, *iter, objId);
					if (a <= radius) {
						queNode.push(*iter);
					}

				}

			}
		}
		stackNode.pop();

		while (!queNode.empty()) {
			if (queNode.front()->listChild.size() == 0 && queNode.front()->listObject.size() > 0)
			{
				nodenum++;
				queryObjNum += queNode.front()->listObject.size();
				for (auto iterLstObject = queNode.front()->listObject.begin(); iterLstObject != queNode.front()->listObject.end(); )
				{

					if (*iterLstObject < tstream.GetDataStreamBegin())
					{
						iterLstObject = queNode.front()->listObject.erase(iterLstObject);
						objNum--;
						continue;
					}
					dis = GetDistance(tstream, test, *iterLstObject, objId);
					if (dis < radius && dis != 0 && *iterLstObject != objId)
					{
						neighbor = *iterLstObject;
						radius = dis;
					}
					iterLstObject++;
				}
			}
			else
			{
				Prune(tstream, test, queNode.front(), objId, radius, queNode);
			}
			queNode.pop();
		}
	}
	


}


void Tree::InsertMapCandidateSet(int objId, int neighbor, double distance)
{
	int times = 0;
	double step = 0.000001;
	Pair temp, temp1;
	temp.objId = objId;
	temp.neighborId = neighbor;
	std::pair<std::map<double, Pair>::iterator, bool> ret1;
	ret1 = mapCandidateSet.insert(make_pair(distance, temp));
	temp1 = mapCandidateSet[distance];
	while (!ret1.second)
	{
		if (temp1.objId == temp.neighborId && temp1.neighborId == temp.objId)
			return;
		else
		{
			if (times > 10) {
				return;
			}
			ret1 = mapCandidateSet.insert(make_pair(distance + step, temp));
			step += 0.000001;
			times++;
		}
	}
}

void Tree::Prune(TStream& tstream, Test& test, MBR* node, int objId, double radius, queue<MBR*>& queResultLevelOrder)
{
	for (auto iterLstPointer = node->listChild.begin(); iterLstPointer != node->listChild.end(); iterLstPointer++)
	{
		double distance = 0;
		distance = GetDistanceBrothers(tstream, test, *iterLstPointer, objId);
		if (distance <= radius)
		{
			queResultLevelOrder.push(*iterLstPointer);
		}
	}
}


void Tree::AllObjNum(TStream& tstream, Test& test)
{
	queue<MBR*> queNode;
	queNode.push(root);
	while (!queNode.empty()) {
		if (queNode.front()->listChild.size() == 0) {
			if (queNode.front()->listObject.size() > 3 * NUM) {
				OBJNUM1++;
				cout << queNode.front()->listObject.size() << endl;
			}
			else if (queNode.front()->listObject.size() > 2 * NUM) {
				OBJNUM2++;
			}
			else if (queNode.front()->listObject.size() > NUM) {
				OBJNUM3++;
			}
			else if (queNode.front()->listObject.size() <= NUM)
			{
				OBJNUM4++;
			}

		}
		else {
			for (auto iter = queNode.front()->listChild.begin(); iter != queNode.front()->listChild.end(); iter++) {
				queNode.push(*iter);
			}
		}
		queNode.pop();
	}
}

void Tree::UpdateDataFlow(TStream& tstream, Test& test)
{
	int newObj = test.GetWindowSize() / test.GetDimension();
	int winsize = test.GetWindowSize() / test.GetDimension();
	int updata = winsize;
	if (newObj <= 1048576)
		updata = 1048576;
	int neighbor = -1;
	double queryRadius = 0;
	tstream.SetDataStreamTag(test.GetWindowSize() / test.GetDimension());
	tstream.SetDataStreamBegin(0);
	int objNum = test.GetWindowSize() / test.GetDimension();
	int nowObjNum = objNum;
	clock_t startTime1, endTime1;
	MBR* tagNode = NULL;
	int cc = 0;
	for (; tstream.GetDataStreamTag() < 1048576 + winsize; )
	{

		tstream.AddDataStreamBegin(1);
		tstream.AddDataStreamTag(1);

		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 102400 == 1)
		{
			startTime1 = clock();
		}
		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 102400 == 0&&tstream.GetDataStreamTag()>=102400)
		{
			endTime1 = clock();
			cout << "Current cursor:" << tstream.GetDataStreamTag() << "     Time = " << (double)(endTime1 - startTime1) / CLOCKS_PER_SEC << "s" << endl;
		}
		if ((tstream.GetDataStreamTag() - tstream.GetDataStreamBegin()) >= 10 * (test.GetWindowSize() / test.GetDimension()))
		{
			tstream.SetDataStreamBegin(tstream.GetDataStreamTag() - (test.GetWindowSize() / test.GetDimension()));
		}

		if ((tstream.GetDataStreamTag() - tstream.GetDataStreamBegin()) <= 0.1 * (test.GetWindowSize() / test.GetDimension()))
		{
			tstream.SetDataStreamTag(tstream.GetDataStreamBegin() + (test.GetWindowSize() / test.GetDimension()));
			if (tstream.GetDataStreamTag() > tstream.GetDataStreamLength() / test.GetDimension())
			{
				tstream.SetDataStreamTag(tstream.GetDataStreamLength() / test.GetDimension());
			}
		}
		cc++;
		nowObjNum++;

		if (test.GetInFlow() == 1 && test.GetOutFlow() == 1 && (tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 0)
		{
			UpdataCandidateSet(tstream.GetDataStreamBegin());
		}
		if (nowObjNum >= 2 * objNum)
		{
			DeleteOverDueObj(tstream, test, nowObjNum);
			CheckMiddleNode(tstream, test, root);
			nowObjNum = test.GetWindowSize() / test.GetDimension();
			cc = 0;
		}
		for (int i = newObj; i < tstream.GetDataStreamTag(); i++)
		{

			queryRadius = 0;
			neighbor = -1;

			tagNode = newObjectInsert(tstream, test, i);

			queryRadius = GetInitRadius(tstream, test, tagNode, i, neighbor, nowObjNum);
			FindNeighbor(tstream, test, i, neighbor, queryRadius, nowObjNum, tagNode);

			if (neighbor != -1)
				InsertMapCandidateSet(i, neighbor, queryRadius);
			tagNode = NULL;
		}
		newObj = tstream.GetDataStreamTag();
	}

}
void Tree::UpdataCandidateSet(int tstreamBegin)
{
	for (auto iterMapCandidateSet = mapCandidateSet.begin(); iterMapCandidateSet != mapCandidateSet.end(); )
	{
		if (iterMapCandidateSet->second.neighborId < tstreamBegin || iterMapCandidateSet->second.objId < tstreamBegin)
		{
			mapCandidateSet.erase(iterMapCandidateSet++);
		}
		else
		{
			iterMapCandidateSet++;
		}
	}
}

bool Tree::UpdateSplit(TStream& tstream, Test& test, MBR* node, MBR* fatherNode, queue<MBR*>& que)
{
	int i = 0;
	vector<double> temp;
	SelectDimension(test, node);
	double mid = 0;
	double max = -1, min = INT16_MAX;
	MBR* node1 = new MBR;
	MBR* node2 = new MBR;
	while (true) {
		if (i == test.GetDimension())
			break;
		for (auto iter = node->listObject.begin(); iter != node->listObject.end(); iter++) {
			temp.push_back(tstream.GetDataStream((*iter) * test.GetDimension() + node->maxDimOrder[i]));
		}
		nth_element(temp.begin(), temp.begin() + temp.size() / 2, temp.end());
		mid = temp[temp.size() / 2];
		for (auto iter = node->listObject.begin(); iter != node->listObject.end(); iter++) {
			if (tstream.GetDataStream((*iter) * test.GetDimension() + node->maxDimOrder[i]) <= mid) {
				node1->listObject.push_back(*iter);
			}
			else if (tstream.GetDataStream((*iter) * test.GetDimension() + node->maxDimOrder[i]) > mid) {
				node2->listObject.push_back(*iter);
			}
		}
		if (node2->listObject.size() != 0) {
			break;
		}
		temp.clear();
		node1->listObject.clear();
		i++;

	}
	if (i != test.GetDimension()) {
		SetLeftNodeVar(tstream, test, node1, node, node->maxDimOrder[i], mid);
		SetRightNodeVar(tstream, test, node2, node, node->maxDimOrder[i], mid);
		CalculateMBR(tstream, test, node1);
		CalculateMBR(tstream, test, node2);
		SelectDimension(test, node1);
		SelectDimension(test, node2);
		if (node1->listObject.size() > NUM)
			que.push(node1);
		if (node2->listObject.size() > NUM)
			que.push(node2);
		fatherNode->listChild.push_back(node1);
		fatherNode->listChild.push_back(node2);
		node1->fatherNode = fatherNode;
		node2->fatherNode = fatherNode;
		node->listObject.clear();
		node->fatherNode->listChild.remove(node);
		return true;
	}
	else if (i == test.GetDimension())
	{
		delete node1;
		delete node2;
		return false;
	}
}

Tree::MBR* Tree::ObjectInsert(TStream& tstream, Test& test, int id)
{
	queue<MBR*> queNode;
	double dis;
	double mindis = 0xffffffff;
	MBR* node = NULL;
	MBR* temp = NULL;
	MBR* tempNode = NULL;
	queNode.push(root);
	while (!queNode.empty()) {
		if (queNode.front()->listChild.size() == 0) {
			queNode.front()->listObject.push_back(id);
			if (queNode.front()->listObject.size() > NUM) {
				NodeSplitAgain(tstream, test, queNode.front(), queNode.front()->fatherNode, queNode, true);
				if (queNode.front()->listObject.size() == 0)
				{
					CheckScale(test, queNode.front()->fatherNode);
					temp = queNode.front();
					delete temp;
					temp = NULL;
				}
			}
			node = FindMBR(tstream, test, queNode, id);
			break;
		}
		else if(!QueryField(tstream,test,queNode.front(),id,queNode)){
			node = DealOutsidePoints(tstream, test, queNode.front(), id);
			break;

		}
		queNode.pop();
	}
	return node;

}

void Tree::calCenter(Test& test, MBR*& node, vector<vector<double>>& center) {
	int dimension = test.GetDimension();
	vector<double> tem;
	for (int i = 0; i < dimension; ++i) {
		tem.push_back((node->vecRightUp[i] + node->vecLeftDown[i]) / 2);
	}
	center.push_back(tem);
}

double Tree::caldisintovec(Test& test, vector<double> v1, vector<double> v2) {
	int dimension = test.GetDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow((v1[i] - v2[i]), 2);
	}
	return sqrt(dis);
}

void Tree::NewSetMBR(Test& test, MBR* node)
{
	AddID(1);
	node->MBRID = GetID();
	double maxd = 0;
	double mind = DBL_MAX;
	double area = 1;
	double tem = 0;
	for (int i = 0; i < test.GetDimension(); ++i) {
		maxd = 0;
		mind = DBL_MAX;
		for (auto child : node->listChild) {
			if (child->vecLeftDown[i] < mind) {
				mind = child->vecLeftDown[i];
			}
			if (child->vecRightUp[i] > maxd) {
				maxd = child->vecRightUp[i];
			}
		}
		node->vecLeftDown.push_back(maxd);
		node->vecRightUp.push_back(mind);
		area *= (maxd - mind);
	}
	SelectDimension(test, node);
	node->area = sqrt(area);
	for (int i = 0; i < test.GetDimension(); ++i) {
		tem = (node->vecLeftDown[i] + node->vecRightUp[i]) / 2;
		node->centerPoint.push_back(tem);
	}
}

void Tree::PrintMapSet(Test& test, int datasBegin)
{
	int k = 0;
	for (auto iter = mapCandidateSet.begin(); iter != mapCandidateSet.end(); iter++)
	{

		if (k == test.GetTopK())
			break;
		if (iter->second.objId < datasBegin || iter->second.neighborId < datasBegin)
		{
			continue;
		}
		k++;
		cout << "The nearest neighbor of " << iter->second.objId << " is " << iter->second.neighborId << "distance:" << iter->first << endl;
	}
}

void Tree::newsplitNode(Test& test, MBR* node1, MBR* node2, MBR* node) {
	double dis1, dis2;
	for (auto child : node->listChild) {
		dis1 = caldisintovec(test, node1->centerPoint, child->centerPoint);
		dis2 = caldisintovec(test, node2->centerPoint, child->centerPoint);
		if (dis1 <= dis2) {
			node1->listChild.push_back(child);
			child->fatherNode = node1;
		}
		else {
			node2->listChild.push_back(child);
			child->fatherNode = node2;
		}
	}
	node->listChild.clear();
	if (node != root) {
		node1->fatherNode = node->fatherNode;
		node2->fatherNode = node->fatherNode;
		node->fatherNode->listChild.push_back(node1);
		node->fatherNode->listChild.push_back(node2);
		node->fatherNode->listChild.remove(node);
	}
	else {
		node1->fatherNode = node;
		node2->fatherNode = node;
		node->listChild.push_back(node1);
		node->listChild.push_back(node2);
	}
}

void Tree::SplitNodes(Test& test, MBR* node)
{
	
	MBR* newNode1 = new MBR;
	MBR* newNode2 = new MBR;
	bool flag = true;
	SelectDimension(test, node);
	int chooseDimension = node->maxDimOrder[0];
	int middleNum = (node->vecRightUp[chooseDimension] + node->vecLeftDown[chooseDimension]) / 2;
	for (auto child : node->listChild) {
		if (child->vecLeftDown[chooseDimension] >= middleNum) {
			newNode2->listChild.push_back(child);
			child->fatherNode = newNode2;
		}
		else if (child->vecRightUp[chooseDimension] <= middleNum) {
			newNode1->listChild.push_back(child);
			child->fatherNode = newNode1;
		}
		else {
			if ((middleNum - child->vecLeftDown[chooseDimension]) <= (child->vecRightUp[chooseDimension] - middleNum)) {
				newNode2->listChild.push_back(child);
				child->fatherNode = newNode2;
			}
			else {
				newNode1->listChild.push_back(child);
				child->fatherNode = newNode1;
			}
		}
	}
	node->listChild.clear();
	if (node != root) {
		newNode1->fatherNode = node->fatherNode;
		newNode2->fatherNode = node->fatherNode;
		node->fatherNode->listChild.push_back(newNode1);
		node->fatherNode->listChild.push_back(newNode2);
		node->fatherNode->listChild.remove(node);
	}
	else {
		newNode1->fatherNode = node;
		newNode2->fatherNode = node;
		node->listChild.push_back(newNode1);
		node->listChild.push_back(newNode2);
	}
	NewSetMBR(test, newNode1);
	NewSetMBR(test, newNode2);

}
void Tree::CheckScale(Test& test, MBR* node)
{

	MBR* temp = NULL;
	while (node->listChild.size() > 32) {

		if (node->fatherNode == NULL)
		{
			SplitNodes(test, node);
			break;
		}
		SplitNodes(test, node);
		temp = node;
		node = node->fatherNode;
		delete temp;
		temp = NULL;
	}
}

Tree::MBR* Tree::FindMBR(TStream& tstream, Test& test, queue<MBR*>& queNode, int objId)
{
	if (queNode.size() == 1)
		return queNode.front();
	queNode.pop();
	while (!queNode.empty()) {
		for (auto temp : queNode.front()->listObject) {
			if (temp == objId)
				return queNode.front();
		}
		queNode.pop();
	}
}

void Tree::SetNewMBRVar(Test& test, MBR* node, MBR* oldNode)
{
	AddID(1);
	node->MBRID = GetID();
	if (oldNode == root) {
		node->fatherNode = oldNode;
		oldNode->listChild.push_back(node);
	}
	else {
		node->fatherNode = oldNode->fatherNode;
		oldNode->fatherNode->listChild.push_back(node);
	}
	node->hight = oldNode->hight + 1;
	node->vecLeftDown = oldNode->vecLeftDown;
	node->vecRightUp = oldNode->vecRightUp;

	double left = 0xffffffff, right = -1, temp;
	for (int i = 0; i < test.GetDimension(); i++) {
		for (auto iter = node->listChild.begin(); iter != node->listChild.end(); iter++) {
			if ((*iter)->vecLeftDown[i] < left)
				left = (*iter)->vecLeftDown[i];
			if ((*iter)->vecRightUp[i] > right)
				right = (*iter)->vecRightUp[i];
		}
		node->vecLeftDown[i] = node->vecLeftDown[i] < left ? left : node->vecLeftDown[i];
		node->vecRightUp[i] = node->vecRightUp[i] > right ? right : node->vecRightUp[i];
		temp = (node->vecLeftDown[i] + node->vecRightUp[i]) / 2;
		node->centerPoint.push_back(temp);
	}

	SelectDimension(test, node);
}

bool Tree::IsCover(TStream& tstream, Test& test, MBR* node, int objId)
{
	for (int i = 0; i < test.GetDimension(); i++)
	{
		double  temp = tstream.GetDataStream(objId * test.GetDimension() + i);
		if (tstream.GetDataStream(objId * test.GetDimension() + i) >= node->vecLeftDown[i] && tstream.GetDataStream(objId * test.GetDimension() + i) < node->vecRightUp[i])
		{
			continue;
		}
		else
		{
			return false;
		}
	}
	return true;
}

bool Tree::QueryField(TStream& tstream, Test& test, MBR* node, int objId, queue<MBR*>& queNode)
{
	for (auto iter = node->listChild.begin(); iter != node->listChild.end(); iter++) {
		if (IsCover(tstream, test, *iter, objId))
		{
			queNode.push(*iter);
			return true;
		}
	}
	return false;
}

void Tree::DeleteOverDueObj(TStream& tstream, Test& test, int& objNum)
{
	queue<MBR*> queDleOrder;
	MBR* orderPointer = root;
	queDleOrder.push(orderPointer);
	while (!queDleOrder.empty())
	{
		orderPointer = queDleOrder.front();

		if (orderPointer->listChild.size() == 0)
		{
			for (auto iterObject = orderPointer->listObject.begin(); iterObject != orderPointer->listObject.end(); )
			{
				if (*iterObject < tstream.GetDataStreamBegin())
				{
					iterObject = orderPointer->listObject.erase(iterObject);
					objNum--;
					continue;
				}
				else {
					break;
				}

			}
		}
		for (auto iterLstPointer = orderPointer->listChild.begin(); iterLstPointer != orderPointer->listChild.end(); iterLstPointer++)
		{
			queDleOrder.push(*iterLstPointer);
		}
		queDleOrder.pop();
	}
}
void Tree::MergeMBR(TStream& tstream, Test& test, MBR* node)
{
	queue<MBR*> queNode;
	MBR* temp = NULL;
	queNode.push(node);
	while (!queNode.empty()) {
		if (queNode.front()->listChild.size() != 0 && queNode.front()->listChild.size() < 4 && queNode.front() != root) {
			for (auto iter = queNode.front()->listChild.begin(); iter != queNode.front()->listChild.end(); iter++) {
				queNode.front()->fatherNode->listChild.push_back(*iter);
				(*iter)->fatherNode = queNode.front()->fatherNode;
			}
			queNode.front()->fatherNode->listChild.remove(queNode.front());
			CheckScale(test, queNode.front()->fatherNode);
			queNode.front()->listChild.clear();
			temp = queNode.front();
			delete temp;
			temp = NULL;
		}
		else {
			for (auto iter = queNode.front()->listChild.begin(); iter != queNode.front()->listChild.end(); iter++) {
				queNode.push(*iter);
			}
		}
		queNode.pop();
	}
}
void Tree::UpdateMBR(TStream& tstream, Test& test, MBR* node)
{
	double tempMin = 0xffffffff, tempMax = -1;
	for (int i = 0; i < test.GetDimension(); i++) {
		for (auto iter = node->listChild.begin(); iter != node->listChild.end(); iter++) {
			tempMin = min(tempMin, (*iter)->vecLeftDown[i]);
			tempMax = max(tempMax, (*iter)->vecRightUp[i]);
		}
		node->vecLeftDown[i] = tempMin > node->vecLeftDown[i] ? tempMin : node->vecLeftDown[i];
		node->vecRightUp[i] = tempMax < node->vecRightUp[i] ? tempMax : node->vecRightUp[i];
	}
}
void Tree::UpdateLeafMBR(TStream& tstream, Test& test, MBR* node)
{
	double tempMin = 0xffffffff, tempMax = -1, tempTotal = 1;
	for (int i = 0; i < test.GetDimension(); i++) {
		for (auto iter = node->listObject.begin(); iter != node->listObject.end(); iter++) {
			tempMin = min(tempMin, tstream.GetDataStream(*iter * test.GetDimension() + i));
			tempMax = max(tempMax, tstream.GetDataStream(*iter * test.GetDimension() + i));
		}
		node->vecLeftDown[i] = tempMin > node->vecLeftDown[i] ? tempMin : node->vecLeftDown[i];
		node->vecRightUp[i] = tempMax < node->vecRightUp[i] ? tempMax : node->vecRightUp[i];
		tempTotal = tempTotal * (node->vecRightUp[i] - node->vecLeftDown[i]);
	}
	tempTotal = sqrt(tempTotal);
	if (node->area > tempTotal) {
		updataTotalArea -= (node->area - tempTotal);
		node->area = tempTotal;
	}
}

void Tree::UpdateMBRSide(TStream& tstream, Test& test, MBR* node)
{
	set<MBR*> checkSet;
	stack<MBR*> checkStack;
	checkStack.push(node);
	MBR* temNode = NULL;
	MBR* temParentNode = NULL;
	int num = 0;
	while (!checkStack.empty()) {
		temNode = checkStack.top();
		if (!checkSet.count(temNode)) {
			if (temNode->listChild.size() != 0) {
				for (auto child : temNode->listChild) {
					checkStack.push(child);
				}
			}
			else {
				UpdateLeafMBR(tstream, test, temNode);
				num++;
				checkStack.pop();
			}
			checkSet.insert(temNode);
		}
		else {
			if (temNode->listChild.size() == num) {
				UpdateMBR(tstream, test, temNode);
				num = 0;
			}
			checkStack.pop();
		}
	}

}
void Tree::CheckMiddleNode(TStream& tstream, Test& test, MBR* node) {

	set<MBR*> checkSet;
	stack<MBR*> checkStack;
	checkStack.push(node);
	MBR* temNode = NULL;
	MBR* temParentNode = NULL;
	int num = 0;
	while (!checkStack.empty()) {
		temNode = checkStack.top();
		if (!checkSet.count(temNode)) {
			if (temNode->listChild.size() != 0) {
				for (auto child : temNode->listChild) {
					checkStack.push(child);
				}
			}
			else if (temNode->listObject.size() == 0) {
				temParentNode = temNode->fatherNode;
				temNode->area = sqrt(temNode->area);
				updataTotalArea -= temNode->area;
				temParentNode->listChild.remove(temNode);
				delete temNode;
				temNode = NULL;
				temParentNode = NULL;
				checkStack.pop();
				continue;
			}
			else if (temNode->listObject.size() != 0) {
				UpdateLeafMBR(tstream, test, temNode);
				num++;
				checkStack.pop();
			}
			checkSet.insert(temNode);
		}
		else {
			if (temNode->listChild.size() == 0 && temNode->listObject.size() == 0) {
				temParentNode = temNode->fatherNode;
				temParentNode->listChild.remove(temNode);
				delete temNode;
				temNode = NULL;
				temParentNode = NULL;
			}
			else if (temNode->listChild.size() == num) {
				if (temNode != root) {
					UpdateMBR(tstream, test, temNode);
				}
				num = 0;
			}
			checkStack.pop();
		}
	}
}

Tree::MBR* Tree::CreateMBR(TStream& tstream, Test& test, MBR* node, int objId)
{
	MBR* newNode = new MBR;
	AddID(1);
	newNode->MBRID = GetID();
	newNode->fatherNode = node;
	newNode->listObject.push_back(objId);
	newNode->vecLeftDown.resize(test.GetDimension());
	newNode->vecRightUp.resize(test.GetDimension());
	double temp;
	for (int i = 0; i < test.GetDimension(); i++) {
		temp = node->vecRightUp[i] - node->vecLeftDown[i];
		newNode->vecLeftDown[i] = tstream.GetDataStream(objId * test.GetDimension() + i) - temp / 8;
		newNode->vecRightUp[i] = tstream.GetDataStream(objId * test.GetDimension() + i) + temp / 8;
		if (newNode->vecLeftDown[i] < node->vecLeftDown[i])
			newNode->vecLeftDown[i] = node->vecLeftDown[i];
		if (newNode->vecRightUp[i] > node->vecRightUp[i])
			newNode->vecRightUp[i] = node->vecRightUp[i];
		newNode->area *= newNode->vecRightUp[i] - newNode->vecLeftDown[i];
	}
	SelectDimension(test, newNode);
	node->listChild.push_back(newNode);
	OBJNUM5++;
	return newNode;
}

Tree::MBR* Tree::DealOutsidePoints(TStream& tstream, Test& test, MBR* node, int objId)
{
	double temp;
	double increment;
	double dis;
	double tempArea = 1;
	double minIncrement = 0xffffffffffff;
	MBR* tempNode = NULL;
	MBR* tempNode2 = NULL;
	queue<MBR*> queNode;
	vector<double> expandLeftDown;
	vector<double> expandRightUp;
	while (node->listChild.size() != 0 && node != NULL) {
		for (auto iter = node->listChild.begin(); iter != node->listChild.end(); iter++) {
			expandLeftDown = (*iter)->vecLeftDown;
			expandRightUp = (*iter)->vecRightUp;
			for (int i = 0; i < test.GetDimension(); i++) {
				temp = tstream.GetDataStream(objId * test.GetDimension() + i);
				expandLeftDown[i] = temp < (*iter)->vecLeftDown[i] ? temp : (*iter)->vecLeftDown[i];
				expandRightUp[i] = temp > (*iter)->vecRightUp[i] ? temp : (*iter)->vecRightUp[i];
			}
			increment = GetMinIncrement(test, node, expandLeftDown, expandRightUp,*iter);

			if (minIncrement > increment&&increment!=-1) {
				minIncrement = increment;
				tempNode = *iter;
			}
		}
		if (tempNode != NULL) {
			tempNode->vecLeftDown = expandLeftDown;
			tempNode->vecRightUp = expandRightUp;
			node = tempNode;
		}
		minIncrement = 0xffffffffffff;

	}
	if (node != NULL) {
		for (int i = 0; i < test.GetDimension(); i++) {
			tempArea *= (node->vecRightUp[i] - node->vecLeftDown[i]);
		}
		tempArea = sqrt(tempArea);
		updataTotalArea += (tempArea - node->area);
		node->area = tempArea;
		node->listObject.push_back(objId);
		queNode.push(node);
		if (node->listObject.size() > NUM) {
			NodeSplitAgain(tstream, test, node, node->fatherNode, queNode, true);
			if (node->listObject.size() == 0)
			{
				CheckScale(test, node->fatherNode);
				tempNode2 = node;
				delete tempNode2;
				tempNode2 = NULL;
			}
			node = FindMBR(tstream, test, queNode, objId);
		}
	}
	return node;


}

double Tree::GetMinIncrement(Test& test, MBR* node, vector<double>& expandLeftDown, vector<double>& expandRightUp, MBR* child)
{
	double temp1 = 1, temp2 = 1;
	for (int i = 0; i < test.GetDimension(); i++) {
		temp1 = temp1 * (expandRightUp[i] - expandLeftDown[i]);
		temp2 = temp2 * (child->vecRightUp[i] - child->vecLeftDown[i]);
	}
	return temp1 - temp2;
}



double Tree::GetCenterPointDis(TStream& tstream, Test& test, MBR* node, int id)
{
	double result = 0, temp;
	for (int i = 0; i < test.GetDimension(); i++) {
		result += pow(tstream.GetDataStream(id * test.GetDimension() + i) - node->centerPoint[i], 2);
	}
	return sqrt(result);
}

void Tree::DestroyTree(TStream& tstream, Test& test)
{
	list<MBR*> destroyList;
	vector<int> point;
	queue<MBR*> queNode;
	MBR* temp = NULL;
	queNode.push(root);
	while (!queNode.empty()) {
		if (queNode.front()->listChild.size() == 0) {
			for (auto iter = queNode.front()->listObject.begin(); iter != queNode.front()->listObject.end(); iter++) {
				point.push_back(*iter);
			}
		}
		for (auto iter = queNode.front()->listChild.begin(); iter != queNode.front()->listChild.end(); iter++) {
			queNode.push(*iter);
		}
		destroyList.push_back(queNode.front());
		queNode.pop();
	}
	for (auto iter = destroyList.begin(); iter != destroyList.end(); iter++) {
		if (*iter == root)
			continue;
		temp = *iter;
		delete temp;
		temp = NULL;
	}
	destroyList.clear();
	root->listChild.clear();
	sort(point.begin(), point.end());
	for (auto iter = point.begin(); iter != point.end(); iter++) {
		root->listObject.push_back(*iter);
	}
}

void Tree::ReCreateTree(TStream& tstream, Test& test)
{
	bool flag = false;
	queue<MBR*> queCreateTree;
	queCreateTree.push(root);
	MBR* node = NULL;
	while (queCreateTree.size() < NUM) {
		node = queCreateTree.front();
		NodeSplit(tstream, test, node, queCreateTree, flag);
		queCreateTree.pop();
	}
	LinkNode(root, queCreateTree);
	flag = true;
	while (!queCreateTree.empty()) {
		node = queCreateTree.front();
		if (node->listObject.size() < NUM) {
			SelectDimension(test, node);
			queCreateTree.pop();
			continue;
		}
		NodeSplit(tstream, test, node, queCreateTree, flag);
		queCreateTree.pop();
	}
	GetTotalArea(tstream, test, root);
}

void Tree::GetTotalArea(TStream& tstream, Test& test, MBR* node)
{
	double total = 1, temp = 1, tempTotal = 0;
	queue<MBR*> queNode;
	queNode.push(node);
	while (!queNode.empty()) {
		if (queNode.front()->listChild.size() == 0) {
			for (int i = 0; i < test.GetDimension(); i++) {
				total *= (queNode.front()->vecRightUp[i] - queNode.front()->vecLeftDown[i]);
			}
			total = sqrt(total);
			totalArea += total;
		}
		else {
			for (auto iter = queNode.front()->listChild.begin(); iter != queNode.front()->listChild.end(); iter++) {
				queNode.push(*iter);
			}
		}
		queNode.pop();
	}
	updataTotalArea = total;

}


Tree::MBR* Tree::newObjectInsert(TStream& tstream, Test& test, int id) {
	MBR* nodeTemInRadius = nullptr;
	MBR* nodeTemToIncress = nullptr;
	MBR* returnMBR;
	MBR* node = root;
	double minDis = DBL_MAX;
	double minToIncrease = DBL_MAX;
	double dis = 0;
	double disToNode=0;
	double temp;
	vector<double>expandLeftDown;
	vector<double>expandRightUp;
	while (1) {
		minDis = DBL_MAX;
		minToIncrease = DBL_MAX;
		nodeTemInRadius = nullptr;
		nodeTemToIncress = nullptr;
		if (node->listChild.size()==0) {
			node->listObject.push_back(id);
			if (!IsCover(tstream, test, node, id)) {
				expandMBR(tstream, test, id, node);
			}
			returnMBR = node;
			break;
		}
		else {
			for (auto child : node->listChild) {
				if (child->listChild.size() != 0 || child->listObject.size() != 0) {
					if (IsCover(tstream, test, child, id)) {
						dis = GetCenterPointDis(tstream, test, child, id);
						if (dis < minDis) {
							minDis = dis;
							nodeTemInRadius = child;
						}
					}
					else {
						
						expandLeftDown = child->vecLeftDown;
						expandRightUp = child->vecRightUp;
						for (int i = 0; i < test.GetDimension(); i++) {
							temp = tstream.GetDataStream(id * test.GetDimension() + i);
							expandLeftDown[i] = temp < child->vecLeftDown[i] ? temp : child->vecLeftDown[i];
							expandRightUp[i] = temp > child->vecRightUp[i] ? temp : child->vecRightUp[i];
						}
						disToNode = GetMinIncrement(test, node, expandLeftDown, expandRightUp, child);
						if (disToNode < minToIncrease) {
							minToIncrease = disToNode;
							nodeTemToIncress = child;
						}
					}
				}
			}
			if (nodeTemInRadius != nullptr) {
				node = nodeTemInRadius;
			}
			else if(nodeTemToIncress!=nullptr){
				node = nodeTemToIncress;
				expandMBR(tstream, test, id, node);
			}
			else {
				node = *node->listChild.begin();
			}
		}
	}
	checkSplit(tstream, test, node, returnMBR,id);
	return returnMBR;
}

void Tree::expandMBR(TStream& tstream, Test& test, int id, MBR* node) {
	int dimension = test.GetDimension();
	double dataValue;
	for (int i = 0; i < dimension; ++i) {
		dataValue = tstream.GetDataStream(id * dimension + i);
		if (dataValue < node->vecLeftDown[i]) {
			node->vecLeftDown[i] = dataValue;
		}
		else if (dataValue > node->vecRightUp[i]) {
			node->vecRightUp[i] = dataValue;
		}
	}
	expandAreaAndmaxDimOrder(tstream, test, node);
}
void Tree::expandAreaAndmaxDimOrder(TStream& tstream, Test& test, MBR* node) {
	multimap<double, int> dimMap;
	int dimension = test.GetDimension();
	double dif;
	double newArea = 1;
	for (int i = 0; i < dimension; ++i) {
		dif = node->vecRightUp[i] - node->vecLeftDown[i];
		dimMap.emplace(dif, i);
		newArea *= dif;
	}
	int index = 0;
	for (auto x : dimMap) {
		node->maxDimOrder[index++] = x.second;
	}
	newArea = sqrt(newArea);
	updataTotalArea += (newArea - node->area);
	node->area = newArea;
}
double Tree::calculateDisToNode(TStream& tstream, Test& test, int id, MBR* node) {
	int dimension = test.GetDimension();
	double dataValue;
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dataValue = tstream.GetDataStream(id * dimension + i);
		if (dataValue < node->vecLeftDown[i]) {
			dis += pow(node->vecLeftDown[i] - dataValue, 2);
		}
		else if (dataValue > node->vecRightUp[i]) {
			dis += pow(dataValue - node->vecRightUp[i], 2);
		}
		else {
			dis += 0;
		}
	}
	return sqrt(dis);
}
void Tree::checkSplit(TStream& tstream, Test& test, MBR* node, MBR* &returnMBR,int id) {
	
	if (node->listObject.size() > NUM) {
		NewNodeSplitAgain(tstream, test, returnMBR, returnMBR->fatherNode, id);
		node = returnMBR->fatherNode;
		CheckScale(test, node);
	}
}

void Tree::NewNodeSplitAgain(TStream& tstream, Test& test, MBR* &node, MBR* fatherNode,int id)
{
	int i = 0,index=-1;
	vector<double> temp;
	SelectDimension(test, node);
	double mid = 0;
	double max = -1, min = INT16_MAX;
	MBR* node1 = new MBR;
	MBR* node2 = new MBR;
	MBR* tempNode = NULL;
	while (true) {
		if (i == test.GetDimension())
			break;
		for (auto iter = node->listObject.begin(); iter != node->listObject.end(); iter++) {
			temp.push_back(tstream.GetDataStream((*iter) * test.GetDimension() + node->maxDimOrder[i]));
		}
		nth_element(temp.begin(), temp.begin() + temp.size() / 2, temp.end());
		mid = temp[temp.size() / 2];
		for (auto iter = node->listObject.begin(); iter != node->listObject.end(); iter++) {
			if (tstream.GetDataStream((*iter) * test.GetDimension() + node->maxDimOrder[i]) <= mid) {
				node1->listObject.push_back(*iter);
				if (*iter == id)
					index = 1;
			}
			else if (tstream.GetDataStream((*iter) * test.GetDimension() + node->maxDimOrder[i]) > mid) {
				node2->listObject.push_back(*iter);
				if (*iter == id)
					index = 2;
			}
		}
		if (node2->listObject.size() != 0) {
			break;
		}
		temp.clear();
		index = -1;
		node1->listObject.clear();
		i++;

	}
	if (i != test.GetDimension()) {
		SetLeftNodeVar(tstream, test, node1, node, node->maxDimOrder[i], mid);
		SetRightNodeVar(tstream, test, node2, node, node->maxDimOrder[i], mid);
		CalculateMBR(tstream, test, node1);
		CalculateMBR(tstream, test, node2);
		SelectDimension(test, node1);
		SelectDimension(test, node2);
		fatherNode->listChild.push_back(node1);
		node1->fatherNode = fatherNode;
		fatherNode->listChild.push_back(node2);
		node2->fatherNode = fatherNode;
		node->listObject.clear();
		
		if (node->fatherNode != NULL)
			node->fatherNode->listChild.remove(node);
		tempNode = node;
		delete tempNode;
		tempNode = NULL;
		if (index == 1)
			node = node1;
		else if (index == 2)
			node = node2;
		
	}
	else if (i == test.GetDimension())
	{
		delete node1;
		delete node2;
	}
}
