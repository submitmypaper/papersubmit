#include "Test.h"
#include <string>
#pragma warning(disable:4996)
int Test::getDimension()
{
    return dimension;
}

int Test::getTopK()
{
    return topK;
}

int Test::getWindowSize()
{
    return windowSize;
}

int Test::getInFlow()
{
    return inFlow;
}

int Test::getOutFlow()
{
    return outFlow;
}

int Test::getCount()
{
	return count;
}


void Test::setCount(int c)
{
	count = c;
}

void Test::addCount(int c)
{
	count += c;
}

void Test::subCount(int c)
{
	count -= c;
}

void Test::setDimension(int d)
{
    dimension = d;
}

void Test::setTopK(int k)
{
    topK = k;
}

void Test::setWindowSize(int w)
{
    windowSize = w;
}

void Test::setInFlow(int in)
{
    inFlow = in;
}

void Test::setOutFlow(int out)
{
    outFlow = out;
}

void Test::Init(vector<Test>& testList,int j)
{
    FILE* fp;
    int data,i = 0;
	string a = to_string(j);
	string s = "test" + a + ".txt";
	Test test;
    if ((fp = fopen(s.data(), "r")) != NULL) {
        while (fscanf(fp, "%d", &data) != EOF)
        {
			if (i % 5 == 0)
			{
				test.setDimension(data);
			}
			if (i % 5 == 1)
			{
				test.setTopK(data);
			}
			if (i % 5 == 2)
			{
				test.setWindowSize(data);
			}
			if (i % 5 == 3)
			{
				test.setInFlow(data);
			}
			if (i % 5 == 4)
			{
				test.setOutFlow(data);
			}
			i++;
			if(i!=0&&i%5==0)
				testList.push_back(test);
        }
    }
}
