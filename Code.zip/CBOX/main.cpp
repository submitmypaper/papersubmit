#include <iostream>
#include <fstream>
#include "DataStream.h"
#include "Test.h"
#include "Tree.h"
using namespace std;

int main() {
	clock_t starttime, endtime, inittime;
	for (int j = 0; j < 5; j++) {
		DataStream datastream;
		Test test;
		vector<Test> testList; 
		test.Init(testList,j);
		datastream.readFile(j);
		datastream.setRange(testList[0]);
		for (int i = 0; i < testList.size(); i++) {
			CBOX tree;
			datastream.setDataBegin(0);
			datastream.setDataTag(testList[i].getWindowSize() / testList[i].getDimension());
			starttime = clock();
			tree.createTree(datastream, testList[i]);
			tree.traversalTree(datastream, testList[i]);
			endtime = clock();
			inittime = (double)(endtime - starttime) / CLOCKS_PER_SEC;
			cout << "Init time = " << (double)(endtime - starttime) / CLOCKS_PER_SEC << "s" << endl;
			starttime = clock();
			tree.updataDataStream(datastream, testList[i]);
			endtime = clock();
			cout << "Running time = " << (double)(endtime - starttime) / CLOCKS_PER_SEC << "s" << endl;
			cout << "Process " << 52428800 / ((double)(endtime - starttime) / CLOCKS_PER_SEC) << " data per second " << endl;
		}
	}
	return 0;
	
}