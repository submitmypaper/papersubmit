#pragma once
#include <iostream>
#include <vector>
#include <list>
#include <math.h>
#include <queue>
#include <map>
#include "DataStream.h"
#include "Test.h"
using namespace std;

class CBOX {
public:
	struct Treenode {
		list<int> objects;
		Treenode* Lchild=NULL;
		Treenode* Rchild=NULL;
		Treenode* father=NULL;
		vector<double> LeftDown;
		vector<double> RightUp;
		int height=0;
		int divideDimension=0;
		double mid = 0;
	};
	struct Pair {
		int objID;
		int neighborID;
	};
	void createTree(DataStream& datastream, Test& test);
	void rootInit(DataStream& datastream, Test& test);
	int calculateVar(Test& test,Treenode* node);
	void nodeSplit(DataStream& datastream, Test& test, Treenode* node,
		queue<Treenode*>& queCreateTree);
	void setLeftDataRange(DataStream &datastream,Test &test,Treenode* node,Treenode* prenode);
	void setRightDataRange(DataStream& datastream, Test& test, Treenode* node, Treenode* prenode);
	void setNodeOtherVar(DataStream& datastream, Test &test,Treenode* node,Treenode* prenode);

	void traversalTree(DataStream& datastream, Test& test);
	double getDistance(DataStream& datastream, Test& test, int obj1, int obj2);
	double getRadius(DataStream& datastream, Test& test, Treenode* node, int obj,int &neighbor);
	void FindNeighbor(DataStream& datastream, Test& test, int objId, double& radius, int& neighbor,Treenode* node);
	bool Prune(DataStream& datastream, Test& test, Treenode* node, int objId, double radius, queue<Treenode*>& queNode);
	double getDistanceNode(DataStream& datastream, Test& test, Treenode* node, int obj);
	double getDisNode(DataStream& datastream, Test& test, Treenode* node, int obj);
	void InsertMapSet(int obj, int neighbor, double distance);

	void updataDataStream(DataStream& datastream, Test& test);
	void updataMapSet(int dataBegin);
	Treenode* TreeNodeInsert(DataStream& datastream, Test& test, int i);
	void updataNodeSplit(DataStream& datastream, Test& test, Treenode* node,int i,Treenode* &result);
	void updataTreeSize(DataStream& datastream, Test& test);
	void balanceTree(DataStream& datastream, Test& test);
	void nodeResplit(DataStream& datastream, Test& test,queue<Treenode*> &queSplit);
	void reInsert(DataStream& datastream, Test& test, int i);

	void PrintMapSet(Test& test, int dataBegin);
private:
	Treenode* root;
	map<double, Pair> mapSet;
};