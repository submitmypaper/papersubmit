#include "Tree.h"
#include <numeric>
#include <math.h>
#include <queue>
#include <stack>
#include <map>
#include <fstream>
#define NUM 6

void CBOX::createTree(DataStream& datastream, Test& test)
{
	rootInit(datastream, test);
	queue<Treenode*> queCreateTree;
	queCreateTree.push(root);
	while (!queCreateTree.empty()) {
		if (queCreateTree.front()->objects.size() <= NUM) {
			queCreateTree.pop();
			continue;
		}
		nodeSplit(datastream, test, queCreateTree.front(), queCreateTree);
		queCreateTree.pop();
	}
}

void CBOX::rootInit(DataStream& datastream, Test& test)
{
	root = new Treenode;
	for (int i = 0; i < test.getWindowSize() / test.getDimension(); i++) {
		root->objects.push_back(i);
	}
	root->LeftDown = datastream.getDimensionMin();
	root->RightUp = datastream.getDimensionMax();
	root->father = NULL;
	root->height =0;
	root->divideDimension =calculateVar( test, root);
}

int CBOX::calculateVar( Test& test, Treenode* node)
{
	int d = 0;
	double dev = -1;
	for (int i = 0; i < test.getDimension(); i++) {
		if (dev < node->RightUp[i] - node->LeftDown[i]) {
			dev = node->RightUp[i] - node->LeftDown[i];
			d = i;
		}
	}
	return d;
}


void CBOX::nodeSplit(DataStream& datastream, Test& test, Treenode* node, queue<Treenode*>& queCreateTree)
{
	vector<double> temp;
	int flag = 0;
	list<int> s1, s2;
	for (auto iter = node->objects.begin(); iter != node->objects.end(); iter++) {
		temp.push_back(datastream.getData((*iter) * test.getDimension() + node->divideDimension));
	}
	nth_element(temp.begin(), temp.begin() + temp.size()/2, temp.end());
	node->mid = temp[temp.size() / 2];
	Treenode* Lchild = new Treenode;
	Treenode* Rchild = new Treenode;
	node->Lchild = Lchild;
	node->Rchild = Rchild;
	for (auto iter = node->objects.begin(); iter != node->objects.end(); iter++) {
		if (datastream.getData((*iter) * test.getDimension() + node->divideDimension) <= node->mid)
			Lchild->objects.push_back(*iter);
		else if(datastream.getData((*iter) * test.getDimension() + node->divideDimension) > node->mid)
			Rchild->objects.push_back(*iter);
	}
	
	if (Rchild->objects.size() == 0)
	{
		int r = node->divideDimension;	
		flag++;
		while ((r+1)%test.getDimension()!=node->divideDimension&&s2.empty())
		{
			r = r + 1;
			flag++;
			vector<double> temp;
			for (auto iter = node->objects.begin(); iter != node->objects.end(); iter++) {
				temp.push_back(datastream.getData((*iter) * test.getDimension() + r));
			}
			nth_element(temp.begin(), temp.begin() + temp.size() / 2, temp.end());
			for (auto iter = node->objects.begin(); iter != node->objects.end(); iter++) {
				if (datastream.getData((*iter) * test.getDimension() + r) <= temp[temp.size()/2])
					s1.push_back(*iter);
				else if (datastream.getData((*iter) * test.getDimension() + r) > temp[temp.size() / 2])
					s2.push_back(*iter);
			}
		}
	}
	s1.clear();
	s2.clear();
	setLeftDataRange(datastream, test, Lchild,node);
	setRightDataRange(datastream, test, Rchild,node);
	setNodeOtherVar(datastream,test, Lchild, node);
	setNodeOtherVar(datastream,test, Rchild, node);
	if(Lchild->objects.size()>NUM&&flag!=test.getDimension())
		queCreateTree.push(Lchild);
	if(Rchild->objects.size()>NUM)
		queCreateTree.push(Rchild);
	node->objects.clear();
}

void CBOX::setLeftDataRange(DataStream &datastream,Test &test,Treenode* node,Treenode* prenode)
{
	node->LeftDown = prenode->LeftDown;
	node->RightUp = prenode->RightUp;
	node->RightUp[prenode->divideDimension] = prenode->mid;
}

void CBOX::setRightDataRange(DataStream& datastream, Test& test, Treenode* node, Treenode* prenode)
{
	node->LeftDown = prenode->LeftDown;
	node->RightUp = prenode->RightUp;
	node->LeftDown[prenode->divideDimension] = prenode->mid;
}

void CBOX::setNodeOtherVar(DataStream &datastream,Test &test,Treenode* node,Treenode *prenode)
{
	node->height = prenode->height+1;
	node->father = prenode;
	node->divideDimension = (prenode->divideDimension+1)%test.getDimension();
}

void CBOX::traversalTree(DataStream& datastream, Test& test)
{
	queue<Treenode*> queNode;
	Treenode* node = root;
	queNode.push(node);
	int i = 0;
	int neighbor = -1;
	mapSet.clear();
	while (!queNode.empty()) {
		if (queNode.front()->Lchild == NULL && queNode.front()->Rchild == NULL) {
			for (auto iter = queNode.front()->objects.begin(); iter != queNode.front()->objects.end(); iter++)
			{			
				double radius=getRadius(datastream,test,queNode.front(),*iter,neighbor);
				FindNeighbor(datastream, test, *iter, radius, neighbor,queNode.front()->father);
				if (neighbor != -1) {
					InsertMapSet(*iter, neighbor, radius);
				}
			}
		}
		else{	
			if(queNode.front()->Lchild!=NULL)
				queNode.push(queNode.front()->Lchild);
			if(queNode.front()->Rchild!=NULL)
				queNode.push(queNode.front()->Rchild);
		}
		queNode.pop();

	}
}

double CBOX::getDistance(DataStream& datastream, Test& test, int obj1, int obj2)
{
	double dis = 0;
	for (int i = 0; i < test.getDimension(); i++) {
		dis += pow(datastream.getData(obj1 * test.getDimension() + i) - datastream.getData(obj2 * test.getDimension() + i), 2);
	}
	return sqrt(dis);
}

double CBOX::getRadius(DataStream& datastream, Test& test, Treenode* node, int obj,int& neighbor)
{
	double dis = 0;
	double min = 0xffffffff;
	for (auto iter = node->objects.begin(); iter != node->objects.end(); ) {
		if (*iter < datastream.getDataBegin()) {
			iter = node->objects.erase(iter);
			test.subCount(1);
		}
		else {
			dis = getDistance(datastream, test, obj, *iter);
			if (dis < min && dis != 0) {
				min = dis;
				neighbor = *iter;
			}
			iter++;
		}	
	}
	return min;
}

void CBOX::FindNeighbor(DataStream& datastream, Test& test, int objId, double& radius, int& neighbor, Treenode* node)
{
	double dis;
	queue<Treenode*> queNode;
	queue<Treenode*> stackNode;
	stackNode.push(node);
	while (node->father != NULL) {
		node = node->father;
		stackNode.push(node);
	}
	while (!stackNode.empty()) {
		if (datastream.getData(objId * test.getDimension() + stackNode.front()->divideDimension) > stackNode.front()->mid) {
			if(getDistanceNode(datastream,test,stackNode.front()->Lchild,objId)<=radius)
				queNode.push(stackNode.front()->Lchild);
		}	
		else
			if (getDistanceNode(datastream, test, stackNode.front()->Rchild, objId) <= radius)
				queNode.push(stackNode.front()->Rchild);
		stackNode.pop();
		
		while (!queNode.empty()) {
			if (queNode.front()->Lchild == NULL && queNode.front()->Rchild == NULL && queNode.front()->objects.size() > 0) {
				for (auto iterLstObject = queNode.front()->objects.begin(); iterLstObject != queNode.front()->objects.end(); )
				{
					dis = 0;
					if (*iterLstObject < datastream.getDataBegin())
					{
						iterLstObject = queNode.front()->objects.erase(iterLstObject);
						test.subCount(1);
						continue;
					}
					dis = getDistance(datastream, test, *iterLstObject, objId);
					if (dis <= radius && dis != 0 && *iterLstObject != objId)
					{
						neighbor = *iterLstObject;
						radius = dis;
					}
					iterLstObject++;
				}
			}
			else {
				if (queNode.front()->Lchild!=NULL)
					Prune(datastream, test, queNode.front()->Lchild, objId, radius, queNode);
				if(queNode.front()->Rchild!=NULL)
					Prune(datastream, test, queNode.front()->Rchild, objId, radius, queNode);
			}
			queNode.pop();
		}	
	}
}

bool CBOX::Prune(DataStream& datastream, Test& test, Treenode* node, int objId, double radius, queue<Treenode*>& queNode)
{
	double distance = 0;
	distance = getDistanceNode(datastream, test, node, objId);
	if (distance <= radius)
	{
		queNode.push(node);
		return true;
	}
	return false;
}

double CBOX::getDistanceNode(DataStream& datastream, Test& test, Treenode* node, int obj)
{
	double result = 0;
	double temp, temp1, temp2;
	if (node->LeftDown.size() == 0 || node->RightUp.size() == 0)
		return 0xffffffff;
	for (int i = 0; i < test.getDimension(); i++)
	{
		temp = datastream.getData(obj * test.getDimension() + i);
		temp1 = node->LeftDown[i];
		temp2 = node->RightUp[i];
		if (temp < temp1)
		{
			result += pow(abs(temp - temp1), 2);
		}
		else if (temp > temp2)
		{
			result += pow(abs(temp2 - temp), 2);
		}
	}
	result = sqrt(result);
	return result;
}

double CBOX::getDisNode(DataStream& datastream, Test& test, Treenode* node, int obj)
{
	return fabs(datastream.getData(obj*test.getDimension()+node->divideDimension)-node->mid);
}

void CBOX::InsertMapSet(int obj, int neighbor, double distance)
{
	int times = 0;
	double step = 0.000001;
	Pair temp, temp1;
	temp.objID = obj;
	temp.neighborID = neighbor;
	std::pair<std::map<double, Pair>::iterator, bool> ret1;
	ret1 = mapSet.insert(make_pair(distance, temp));
	temp1 = mapSet[distance];
	while (!ret1.second)
	{
		if (temp1.objID == temp.neighborID && temp1.neighborID == temp.objID)
			return;
		else
		{
			if (times > 100) {
				return;
			}
			ret1 = mapSet.insert(make_pair(distance + step, temp));
			step += 0.000001;
			times++;
		}
	}
}

void CBOX::updataDataStream(DataStream& datastream, Test& test)
{
	int newObj = test.getWindowSize() / test.getDimension();
	int neighbor = -1;
	double radius = 0;
	int num=0;
	int windowSize = test.getWindowSize() / test.getDimension();
	Treenode* node =NULL;
	clock_t startTime1, endTime1;
	for (; datastream.getDataTag() < 52428800 + windowSize;) {
		datastream.updataBegin(1);
		datastream.updataTag(1);
		if ((datastream.getDataTag() - test.getWindowSize() / test.getDimension()) % 1048576 == 1)
		{
			startTime1 = clock();
		}
		if ((datastream.getDataTag() - test.getWindowSize() / test.getDimension()) % 1048576 == 0&&datastream.getDataTag()>= 1048576)
		{
			endTime1 = clock();
			cout << "Current cursor:" << datastream.getDataTag() << "     Time = " << (double)(endTime1 - startTime1) / CLOCKS_PER_SEC << "s" << endl;
		}
		test.addCount(1);
		if (test.getCount() >=1.2*(test.getWindowSize()/test.getDimension())) {
			updataTreeSize(datastream, test);
			balanceTree(datastream, test);
			test.setCount(test.getWindowSize() / test.getDimension());
		}	
		if ((datastream.getDataTag() - test.getWindowSize() / test.getDimension()) % 1048576 == 0) {
			updataMapSet(datastream.getDataBegin());  
		}
		for (int i = newObj; i < datastream.getDataTag(); i++) {
			
			node = TreeNodeInsert(datastream, test, i);
			radius = getRadius(datastream, test, node, i,neighbor);		
			FindNeighbor(datastream, test, i, radius, neighbor,node->father);
			
			if (neighbor != -1) {
				InsertMapSet(i, neighbor, radius);
			}
			node = NULL;
		}
		newObj = datastream.getDataTag();
	}
}

void CBOX::updataMapSet(int dataBegin)
{
	for (auto iter = mapSet.begin(); iter != mapSet.end(); ) {
		if (iter->second.objID < dataBegin || iter->second.neighborID < dataBegin) {
			mapSet.erase(iter++);
		}
		else iter++;
	}
}

CBOX::Treenode* CBOX::TreeNodeInsert(DataStream& datastream, Test& test, int i)
{
	queue<Treenode*> queNode;
	Treenode* result = NULL;            
	queNode.push(root);
	while (!queNode.empty()) {
		if (queNode.front()->Lchild == NULL && queNode.front()->Rchild == NULL) {
			queNode.front()->objects.push_back(i);
			for (auto iter = queNode.front()->objects.begin(); iter != queNode.front()->objects.end();) {
				if (*iter < datastream.getDataBegin()) {
					iter = queNode.front()->objects.erase(iter);
					test.subCount(1);
				}	
				else
					iter++;
			}
			if (queNode.front()->objects.size() >0.5*NUM) {
				updataNodeSplit(datastream, test, queNode.front(), i, result);		
			}
			else {
				result = queNode.front();
			}
				
		}
		else {
			if (datastream.getData(test.getDimension() * i + queNode.front()->divideDimension) <= queNode.front()->mid) {
				queNode.push(queNode.front()->Lchild);			
			}
			else {
				queNode.push(queNode.front()->Rchild);
			}
				
		}
		queNode.pop();
	}
	return result;
}

void CBOX::updataNodeSplit(DataStream& datastream, Test& test, Treenode* node,int i,Treenode* &result)
{
	vector<double> temp;
	for (auto iter = node->objects.begin(); iter != node->objects.end(); iter++) {
		temp.push_back(datastream.getData((*iter) * test.getDimension() + node->divideDimension));
	}
	nth_element(temp.begin(), temp.begin() + temp.size() / 2, temp.end());
	node->mid =  temp[temp.size() / 2];
	Treenode* Lchild = new Treenode;
	Treenode* Rchild = new Treenode;
	node->Lchild = Lchild;
	node->Rchild = Rchild;
	for (auto iter = node->objects.begin(); iter != node->objects.end(); iter++) {
		if (datastream.getData((*iter) * test.getDimension() + node->divideDimension) <= node->mid) {
			Lchild->objects.push_back(*iter);
		}		
		else
			Rchild->objects.push_back(*iter);
	}
	setLeftDataRange(datastream, test, Lchild,node);
	setRightDataRange(datastream, test, Rchild,node);
	setNodeOtherVar(datastream,test, Lchild, node);
	setNodeOtherVar(datastream,test, Rchild, node);
	if (datastream.getData(test.getDimension() * i + node->divideDimension) <= node->mid) {
		result = node->Lchild;
	}
	else
		result = node->Rchild;
	node->objects.clear();
}

void CBOX::updataTreeSize(DataStream& datastream, Test& test)
{
	queue<Treenode*> queNode;
	queue<Treenode*> deleteNode;
	Treenode* temp = NULL;
	queNode.push(root);
	while (!queNode.empty()) {
		if (queNode.front()->Lchild == NULL && queNode.front()->Rchild == NULL) {
			for (auto iter = queNode.front()->objects.begin(); iter != queNode.front()->objects.end();) {
				if (*iter < datastream.getDataBegin()) {
					iter = queNode.front()->objects.erase(iter);
					test.subCount(1);
				}
				else
					iter++;
			}
		}
		else {
			if (queNode.front()->Lchild != NULL)
				queNode.push(queNode.front()->Lchild);
			if (queNode.front()->Rchild != NULL)
				queNode.push(queNode.front()->Rchild);
		}
		queNode.pop();	
	}
}

void CBOX::balanceTree(DataStream& datastream, Test& test)
{	
	queue<Treenode*> queNode;
	queue<Treenode*> queSplit;
	queNode.push(root);
	while (!queNode.empty()) {
		if (queNode.front()->height >= log2(test.getWindowSize()/test.getDimension())&&queNode.front()->Lchild!=NULL&&queNode.front()->Rchild!=NULL) {
			queSplit.push(queNode.front());
			queNode.pop();
			continue;
		}
		else{
			if (queNode.front()->Lchild != NULL)
				queNode.push(queNode.front()->Lchild);
			if (queNode.front()->Rchild != NULL)
				queNode.push(queNode.front()->Rchild);
		}
		queNode.pop();
	}
	nodeResplit(datastream, test, queSplit);
}

void CBOX::nodeResplit(DataStream& datastream, Test& test, queue<Treenode*>& queSplit)
{
	list<int> objects;
	list<Treenode*> lists;
	queue<Treenode*> queNode=queSplit;
	Treenode* temp = NULL;
	while (!queSplit.empty()) {
		if (queSplit.front()->Lchild == NULL && queSplit.front()->Rchild == NULL) {
			objects.splice(objects.begin(), queSplit.front()->objects);
			queSplit.pop();
			continue;
		}
		else
		{
			if (queSplit.front()->Lchild != NULL) {
				queSplit.push(queSplit.front()->Lchild);
				lists.push_back(queSplit.front()->Lchild);
			}	
			if (queSplit.front()->Rchild != NULL) {
				queSplit.push(queSplit.front()->Rchild);
				lists.push_back(queSplit.front()->Rchild);
			}		
		}
		queSplit.pop();
	}
	for (auto iter = lists.begin(); iter != lists.end(); iter++) {
		temp = *iter;
		delete temp;
		temp = NULL;
	}
	lists.clear();
	while (!queNode.empty()) {
		queNode.front()->Lchild = NULL;
		queNode.front()->Rchild = NULL;
		queNode.pop();
	}
	for (auto iter = objects.begin(); iter != objects.end(); iter++) {
		reInsert(datastream, test, *iter);
	}
	objects.clear();
}

void CBOX::reInsert(DataStream& datastream, Test& test, int i)
{
	queue<Treenode*> queNode;
	Treenode* result = NULL;
	queNode.push(root);
	while (!queNode.empty()) {
		if (queNode.front()->Lchild == NULL && queNode.front()->Rchild == NULL) {
			queNode.front()->objects.push_back(i);
			if (queNode.front()->objects.size() > 2.5*NUM) {
				updataNodeSplit(datastream, test, queNode.front(), i, result);
			}
		}
		else {
			if (datastream.getData(test.getDimension() * i + queNode.front()->divideDimension) <= queNode.front()->mid) {
				queNode.push(queNode.front()->Lchild);
			}
			else {
				queNode.push(queNode.front()->Rchild);
			}

		}
		queNode.pop();
	}
}


void CBOX::PrintMapSet(Test& test, int dataBegin)
{
	int k = 0;
	for (auto iter = mapSet.begin(); iter != mapSet.end(); iter++)
	{
		
		if (k == test.getTopK())
			break;
		if (iter->second.objID < dataBegin || iter->second.neighborID < dataBegin)
		{
			continue;
		}
		k++;
		cout  << "The nearest neighbor of "<< iter->second.objID<<" is " << iter->second.neighborID << "distance:" << iter->first << endl;
	}
}

