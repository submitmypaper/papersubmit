#pragma once
#include <vector>
#include <iostream>
#include <math.h>
#include "Test.h"
using namespace std;
class DataStream {
public:
	void readFile(int j);	
	double getData(int ID); 
	double getDataLength(); 
	int getDataBegin();
	int getDataTag();
	vector<double> getDimensionMax();
	vector<double> getDimensionMin();

	void setDataTag(int tag);
	void setDataBegin(int begin);
	void updataBegin(int outflow);	
	void updataTag(int inflow);		
	void setRange(Test& test);  
private:
	vector<double> Data;
	vector<double> DimensionMax;   
	vector<double> DimensionMin;
	int dataBegin = 0;
	int dataTag = 0;
};