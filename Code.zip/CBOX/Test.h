#pragma once
#include <vector>

using namespace std;
class Test {
public:
	
	int getDimension();
	int getTopK();
	int getWindowSize();
	int getInFlow();
	int getOutFlow();
	int getCount();
	void setCount(int c);
	void addCount(int c);
	void subCount(int c);
	void setDimension(int d);
	void setTopK(int k);
	void setWindowSize(int w);
	void setInFlow(int in);		
	void setOutFlow(int out);	
	void Init(vector<Test>& testList,int j);
private: 
	int dimension = 0;
	int topK = 0;
	int windowSize = 0;
	int inFlow = 0;
	int outFlow = 0;
	int count = 0;
	
};