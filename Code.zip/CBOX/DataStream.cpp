#include "DataStream.h"
#include<iostream>
#include <string>
#pragma warning(disable:4996)
void DataStream::readFile(int j)
{
	FILE* fp;
	double data;
	string a = to_string(j);
	string s = "SourceFile" + a + ".txt";

	if ((fp = fopen(s.data(), "r") )!= NULL) {
		while (fscanf(fp, "%lf", &data) != EOF) {
			Data.push_back(data);
		}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
	}
}

double DataStream::getData(int ID)
{
	return Data[ID];
}

double DataStream::getDataLength()
{
	return Data.size();
}

int DataStream::getDataBegin()
{
	return dataBegin;
}

int DataStream::getDataTag()
{
	return dataTag;
}

vector<double> DataStream::getDimensionMax()
{
	return DimensionMax;
}

vector<double> DataStream::getDimensionMin()
{
	return DimensionMin;
}

void DataStream::setDataTag(int tag)
{
	dataTag = tag;
}

void DataStream::setDataBegin(int begin)
{
	dataBegin = begin;
}

void DataStream::updataBegin(int outflow)
{
	dataBegin += outflow;
}

void DataStream::updataTag(int inflow)
{
	dataTag += inflow;
}

void DataStream::setRange(Test& test)
{
	int objnum = getDataLength() / test.getDimension();
	for (int i = 0; i < objnum; i++) {
		for (int j = 0; j < test.getDimension(); j++) {
			if (i == 0) {
				DimensionMax.push_back(Data[j]);
				DimensionMin.push_back(Data[j]);
			}
			else {
				if (DimensionMax[j] < Data[i * test.getDimension() + j])
					DimensionMax[j] = Data[i * test.getDimension() + j];
				if (DimensionMin[j] > Data[i * test.getDimension() + j])
					DimensionMin[j] = Data[i * test.getDimension() + j];
			}
		}
	}
}
