#include "Test.h"
#include "TStream.h"
#include "Tree.h"
#include <fstream>
int main()
{
	clock_t startTime, endTime, time2, time3;
	Test test;
	TStream tstream;
	vector<Test> vecTestFile;
	test.Init(vecTestFile);
	tstream.Init(vecTestFile[0]);
	for (int i = 0; i < vecTestFile.size(); i++)
	{
		double time = 0;
		Tree tree;
		tstream.SetDataStreamBegin(0);
		tstream.SetDataStreamTag(vecTestFile[i].GetWindowSize() / vecTestFile[i].GetDimension());
		startTime = clock();
		tree.CreateTree(tstream, vecTestFile[i]);
		tree.PreOrderTree(tstream, vecTestFile[i]);
		endTime = clock();
		cout << "Init Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
		time2 = (double)(endTime - startTime) / CLOCKS_PER_SEC;
		startTime = clock();
		tree.UpdateDataFlow(tstream, vecTestFile[i], time);
		endTime = clock();
		time3 = (double)(endTime - startTime) / CLOCKS_PER_SEC;
		cout << "Running Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC - time << "s" << endl;
		cout << "Process " << 52428800 / ((double)(endTime - startTime) / CLOCKS_PER_SEC) << " data per second " << endl;
	}
	system("pause");


}