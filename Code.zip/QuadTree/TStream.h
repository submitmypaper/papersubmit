#pragma once
#pragma once
#include <vector>
#include <math.h>
#include "Test.h"
using namespace std;
class TStream
{
public:

	TStream();
	~TStream();

	void ReadDataFile();
	double GetDataStream(int intObjectNumber);
	int GetDataStreamLength();
	double GetLength();
	int GetDataStreamBegin();
	int GetDataStreamTag();
	void SetDataStreamBegin(int begin);
	void SetDataStreamTag(int tag);
	void Init(Test test);
	void AddDataStreamBegin(int outflow);
	void AddDataStreamTag(int inflow);
private:
	struct ObjectNeighbor
	{
		int object;
		int objectNeighbor;
		double distance;

		bool operator < (const ObjectNeighbor& P)const
		{
			return distance < P.distance;
		}
	};
	vector<double> vecDataStream;
	double length;
	int dataStreamBegin = 0;
	int dataStreamTag = 0;
};

