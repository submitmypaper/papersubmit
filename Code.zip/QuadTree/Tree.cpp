#include "Tree.h"
#include <stack>
#define NUM 8


Tree::Tree()
{
}

Tree::~Tree()
{
}

void Tree::FindNeighbor(TStream& tstream, Test& test, int objId, int& neighbor, double& radius, int tstreamBegin)
{
	double distance = 0;
	TreeNode* node;
	queue<TreeNode*> queLevelOrder;
	queLevelOrder.push(root);

	while (!queLevelOrder.empty())
	{
		node = queLevelOrder.front();
		if (node->lstPointer.size() == 0 && node->vecObject.size() > 0)
		{
			for (auto iterLstObject = node->vecObject.begin(); iterLstObject != node->vecObject.end(); )
			{
				distance = 0;
				if (*iterLstObject < tstreamBegin)
				{
					iterLstObject = node->vecObject.erase(iterLstObject);
					continue;
				}
				distance = GetDistance(tstream, test, *iterLstObject, objId);
				if (distance <= radius && distance != 0 && *iterLstObject != objId)
				{
					neighbor = *iterLstObject;
					radius = distance;
				}
				iterLstObject++;
			}
		}
		else
		{
			Prune(tstream, test, node, objId, radius, queLevelOrder);
		}
		queLevelOrder.pop();
	}
	return;
}

void Tree::InsertMapCandidateSet(int objId, int neighbor, double distance)
{
	int times = 0;
	double step = 0.000001;
	Pair temp, temp1;
	temp.objId = objId;
	temp.neighborId = neighbor;
	std::pair<std::map<double, Pair>::iterator, bool> ret1;
	ret1 = mapCandidateSet.insert(make_pair(distance, temp));
	temp1 = mapCandidateSet[distance];
	while (!ret1.second)
	{
		if (temp1.objId == temp.neighborId && temp1.neighborId == temp.objId)
			return;
		else
		{
			if (times > 10) {
				return;
			}
			ret1 = mapCandidateSet.insert(make_pair(distance + step, temp));
			step += 0.000001;
			times++;
		}
	}
}

long Tree::Findaddr(TStream& tstream, int objNo, int d, vector<double>& vecLeftDown, double side)
{
	long addr = 0;
	int temp = 0;
	for (int i = 0; i < d; i++)
	{
		temp = (tstream.GetDataStream(objNo * d + i) - vecLeftDown[i]) / side;
		addr = (addr << 1) | temp;
	}
	return addr;
}

void Tree::RootInit(TStream& tstream, Test& test)
{
	for (int i = 0; i < test.GetWindowSize() / test.GetDimension(); i++)
	{
		root->vecObject.push_back(i);
	}
	for (int i = 0; i < test.GetDimension(); i++)
	{
		root->vecLeftDown.push_back(0);
		root->vecRightUp.push_back(tstream.GetLength());
	}
	root->sideLength = tstream.GetLength();
	root->height = 0;
}

void Tree::TreeNodeSplit(TStream& tstream, Test& test, TreeNode* node)
{
	long addr = 0;
	vector<double> newVecLeftDown;
	vector<double> newVecRightUp;
	for (auto iterlstObj = node->vecObject.begin(); iterlstObj != node->vecObject.end(); iterlstObj++)
	{
		addr = Findaddr(tstream, *iterlstObj, test.GetDimension(), node->vecLeftDown, node->sideLength / 2);
		TreeNodePushBack(*iterlstObj, addr, node);
	}
	for (auto iterlstNode = node->lstPointer.begin(); iterlstNode != node->lstPointer.end(); iterlstNode++)
	{
		if ((*iterlstNode)->vecObject.size() > 0)
		{
			GetTreeNodeCoordinate(tstream, (*iterlstNode)->vecObject.front(), test.GetDimension(), node->vecLeftDown, newVecLeftDown, node->vecRightUp, newVecRightUp, node->sideLength / 2);
			SetTreeNodeCoordinate(*iterlstNode, newVecLeftDown, newVecRightUp);
			newVecLeftDown.clear();
			newVecRightUp.clear();
		}
	}
	node->vecObject.clear();
}

void Tree::UpdateTreeNodeSplit(TStream& tstream, Test& test, TreeNode* node)
{
	long addr = 0;
	vector<double> newVecLeftDown;
	vector<double> newVecRightUp;
	for (auto iterlstObj = node->vecObject.begin(); iterlstObj != node->vecObject.end(); iterlstObj++)
	{
		addr = Findaddr(tstream, *iterlstObj, test.GetDimension(), node->vecLeftDown, node->sideLength / 2);
		TreeNodePushBack(*iterlstObj, addr, node);
	}
	for (auto iterlstNode = node->lstPointer.begin(); iterlstNode != node->lstPointer.end(); iterlstNode++)
	{
		if ((*iterlstNode)->vecObject.size() > 0 && (*iterlstNode)->vecLeftDown.size() == 0)
		{
			GetTreeNodeCoordinate(tstream, (*iterlstNode)->vecObject.front(), test.GetDimension(), node->vecLeftDown, newVecLeftDown, node->vecRightUp, newVecRightUp, node->sideLength / 2);
			SetTreeNodeCoordinate(*iterlstNode, newVecLeftDown, newVecRightUp);
			newVecLeftDown.clear();
			newVecRightUp.clear();
		}
	}
	node->vecObject.clear();
}

void Tree::TreeNodePushBack(int objNo, long addr, TreeNode* node)
{
	for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
	{

		if ((*iterLstPointer)->addr == addr)
		{
			(*iterLstPointer)->vecObject.push_back(objNo);
			return;
		}
	}
	CreateTreeNode(node, objNo, addr, node->height, node->sideLength);
}

void Tree::GetTreeNodeCoordinate(TStream& tstream, int objNo, int d, vector<double>& vecLeftDown, vector<double>& newVecLeftDown, vector<double>& vecRightUp, vector<double>& newVecRightUp, double side)
{
	int temp = 0;
	for (int i = 0; i < d; i++)
	{
		temp = (tstream.GetDataStream(objNo * d + i) - vecLeftDown[i]) / side;
		newVecLeftDown.push_back(vecLeftDown[i] + temp * side);
		newVecRightUp.push_back(vecRightUp[i] - (1 - temp) * side);
	}
}

void Tree::SetTreeNodeCoordinate(TreeNode* node, vector<double>& vecLeftDown, vector<double>& vecRightUp)
{
	for (int i = 0; i < vecLeftDown.size(); i++) {
		node->vecLeftDown.push_back(vecLeftDown[i]);
		node->vecRightUp.push_back(vecRightUp[i]);
	}
}

void Tree::CreateTree(TStream& tstream, Test& test)
{
	root = new TreeNode;
	RootInit(tstream, test);
	queue<TreeNode*> queCreateTree;
	queCreateTree.push(root);
	root->fatherNode = NULL;

	int leafId = 0;
	while (!queCreateTree.empty())
	{
		if (queCreateTree.front()->sideLength <= tstream.GetLength() / 1024 / 1024 / 1024)
		{
			queCreateTree.pop();
			continue;
		}
		TreeNodeSplit(tstream, test, queCreateTree.front());
		for (auto iterLstPointer = queCreateTree.front()->lstPointer.begin(); iterLstPointer != queCreateTree.front()->lstPointer.end(); iterLstPointer++)
		{
			if ((*iterLstPointer)->vecObject.size() > NUM)
			{
				queCreateTree.push((*iterLstPointer));
			}
		}
		queCreateTree.pop();
	}
}

void Tree::CreateTreeNode(TreeNode* node, int objNo, int addr, int height, int sideLenght)
{
	TreeNode* newnode = new TreeNode;
	newnode->vecObject.push_back(objNo);
	newnode->addr = addr;
	newnode->height = node->height + 1;
	newnode->sideLength = node->sideLength / 2;
	newnode->fatherNode = node;
	node->lstPointer.push_back(newnode);
}

double Tree::GetQueryRadiusInThis(TStream& tstream, Test& test, int objId, vector<int> vecObject, int& neighbor)
{
	double distance = 0;
	double minPair = 0x3f3f3f3f;
	for (auto iterLstObject = vecObject.begin(); iterLstObject != vecObject.end(); iterLstObject++)
	{
		distance = 0;
		if (*iterLstObject < tstream.GetDataStreamBegin())
			continue;
		for (int i = 0; i < test.GetDimension(); i++)
		{
			distance += pow(tstream.GetDataStream(objId * test.GetDimension() + i) - tstream.GetDataStream(*iterLstObject * test.GetDimension() + i), 2);
		}
		distance = sqrt(distance);
		if (distance < minPair && distance != 0)
		{
			neighbor = *iterLstObject;
			minPair = distance;
			break;
		}
	}
	if (minPair == 0x3f3f3f3f)
		return -1;
	return minPair;
}

double Tree::GetQueryRadiusInOther(TStream& tstream, Test& test, int objId, TreeNode* fatherNode, int& neighbor)
{
	queue<TreeNode*> queGetQueryRadius;
	queGetQueryRadius.push(fatherNode);
	TreeNode* node;
	TreeNode* minNode;
	double pairDistance = 0x3f3f3f3f;
	double minPairDistance = 0x3f3f3f3f;
	double minDistanceNode = 0x3f3f3f3f;
	double distanceNode = 0;
	while (!queGetQueryRadius.empty())
	{
		node = queGetQueryRadius.front();
		if (node->lstPointer.size() == 0 && node->vecObject.size() > 0)
		{
			pairDistance = GetQueryRadiusInThis(tstream, test, objId, node->vecObject, neighbor);
			break;
		}
		queGetQueryRadius.pop();
		for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
		{
			bool flagInBox = 1;
			for (int i = 0; i < test.GetDimension(); i++)
			{
				if (tstream.GetDataStream(objId * test.GetDimension() + i) >= (*iterLstPointer)->vecLeftDown[i] && tstream.GetDataStream(objId * test.GetDimension() + i) < (*iterLstPointer)->vecRightUp[i])
				{
					continue;
				}
				else
				{
					flagInBox = 0;
					break;
				}
			}
			if (flagInBox == 1 && (*iterLstPointer)->vecObject.size() == 1)
			{
				continue;
			}
			distanceNode = 0;
			distanceNode = GetDistanceFromOtherNode(tstream, test, objId, (*iterLstPointer)->vecLeftDown, (*iterLstPointer)->vecRightUp);
			if (distanceNode < minDistanceNode)
			{
				queGetQueryRadius.push(*iterLstPointer);
				break;
			}
		}
	}
	if (pairDistance == -1)
		return -1;
	if (pairDistance == 0x3f3f3f3f)
		return -1;
	return pairDistance;
}

double Tree::GetDistanceFromOtherNode(TStream& tstream, Test& test, int objId, vector<double>& vecLeftDown, vector<double>& vecRightUp)
{
	double distanceLeft = 0;
	double disRight = 0;
	double minDistance = 0x3f3f3f3f;
	for (int i = 0; i < test.GetDimension(); i++)
	{
		distanceLeft += pow(tstream.GetDataStream(objId * test.GetDimension() + i) - vecLeftDown[i], 2);
		disRight += pow(tstream.GetDataStream(objId * test.GetDimension() + i) - vecRightUp[i], 2);
	}
	distanceLeft = sqrt(distanceLeft);
	disRight = sqrt(disRight);
	distanceLeft < disRight ? minDistance = distanceLeft : minDistance = disRight;
	return minDistance;
}

void Tree::PreOrderTree(TStream& tstream, Test& test)
{
	queue<TreeNode*> quePreOrder;
	int neighbor = -1;
	int unUsed = 0;
	TreeNode* orderPointer = root;
	mapCandidateSet.clear();
	double queryRadius = 0;
	quePreOrder.push(orderPointer);
	while (!quePreOrder.empty())
	{
		orderPointer = quePreOrder.front();

		if (orderPointer->lstPointer.size() == 0)
		{
			for (auto iterObject = orderPointer->vecObject.begin(); iterObject != orderPointer->vecObject.end(); iterObject++)
			{
				neighbor = -1;
				queryRadius = GetInitRadius(tstream, test, orderPointer, *iterObject, neighbor);
				if (queryRadius != 0)
				{
					FindNeighbor(tstream, test, *iterObject, neighbor, queryRadius, 0);
				}
				if (neighbor != -1) {
					InsertMapCandidateSet(*iterObject, neighbor, queryRadius);
				}
			}
		}
		for (auto iterLstPointer = orderPointer->lstPointer.begin(); iterLstPointer != orderPointer->lstPointer.end(); iterLstPointer++)
		{
			quePreOrder.push(*iterLstPointer);
		}
		quePreOrder.pop();
	}
}

double Tree::GetInitRadius(TStream& tstream, Test& test, TreeNode* node, int objId, int& neighbor)
{
	double distance;
	double maxDifference = -1;
	double minDistance = 0xffffffff;
	if (test.GetDimension() < 4)
	{
		if (node->vecObject.size() > 1)
		{
			for (auto iterVecObject = node->vecObject.begin(); iterVecObject != node->vecObject.end(); )
			{
				distance = 0;
				if (*iterVecObject < tstream.GetDataStreamBegin())
				{
					iterVecObject = node->vecObject.erase(iterVecObject);
				}
				else
				{
					distance = GetDistance(tstream, test, objId, *iterVecObject);
					if (distance < minDistance&&distance!=0)
					{
						minDistance = distance;
					}
					iterVecObject++;
				}
			}
		}
		else if (node->vecObject.size() <= 1 || minDistance == 0xffffffff || minDistance == 0)
		{
			return node->sideLength;
		}
		return minDistance;
	}
	else
	{
		if (node->vecObject.size() > 1)
		{
			for (auto iterVecObject = node->vecObject.begin(); iterVecObject != node->vecObject.end(); )
			{
				distance = 0;
				if (*iterVecObject < tstream.GetDataStreamBegin())
				{
					iterVecObject = node->vecObject.erase(iterVecObject);
				}
				else
				{
					distance = GetMaxDifference(tstream, test, objId, *iterVecObject);
					if (distance > maxDifference&&distance!=0)
					{
						maxDifference = distance;
					}
					iterVecObject++;
				}
			}
		}
		else if (node->vecObject.size() <= 1 || maxDifference == -1 || maxDifference == 0)
		{
			return node->sideLength / 2;
		}
		return maxDifference / 2;
	}
}

void Tree::UpdateDataFlow(TStream& tstream, Test& test, double& time)
{
	int newObj = test.GetWindowSize() / test.GetDimension();
	int windowsize = test.GetWindowSize() / test.GetDimension();
	int neighbor = -1;
	double queryRadius = 0;
	tstream.SetDataStreamTag(test.GetWindowSize() / test.GetDimension());
	tstream.SetDataStreamBegin(0);
	clock_t startTime1, endTime1;
	time = 0;
	for (; tstream.GetDataStreamTag() < 52428800 +windowsize ; )
	{
		double step = 0.0000001;

		tstream.AddDataStreamBegin(1);
		tstream.AddDataStreamTag(1);
		
		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 1)
		{
			startTime1 = clock();
		}
		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 0 && tstream.GetDataStreamTag() >= 1048576)
		{
			endTime1 = clock();
			cout << "Current cursor:" << tstream.GetDataStreamTag() << "     Time = " << (double)(endTime1 - startTime1) / CLOCKS_PER_SEC << "s" << endl;
		}

		if ((tstream.GetDataStreamTag() - tstream.GetDataStreamBegin()) >= 10 * (test.GetWindowSize() / test.GetDimension()))
		{
			tstream.SetDataStreamBegin(tstream.GetDataStreamTag() - (test.GetWindowSize() / test.GetDimension()));
		}

		if ((tstream.GetDataStreamTag() - tstream.GetDataStreamBegin()) <= 0.1 * (test.GetWindowSize() / test.GetDimension()))
		{
			tstream.SetDataStreamTag(tstream.GetDataStreamBegin() + (test.GetWindowSize() / test.GetDimension()));
			if (tstream.GetDataStreamTag() > tstream.GetDataStreamLength() / test.GetDimension())
			{
				tstream.SetDataStreamTag(tstream.GetDataStreamLength() / test.GetDimension());
			}

		}


		if (test.GetInFlow() == 1 && test.GetOutFlow() == 1 && (tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 0)
		{

			UpdataCandidateSet(tstream.GetDataStreamBegin());
		}

		for (int i = newObj; i < tstream.GetDataStreamTag(); i++)
		{
			TreeNode* tagNode;
			queryRadius = 0;
			neighbor = -1;
			tagNode = TreeNodeInsert(tstream, test, i);

			queryRadius = GetInitRadius(tstream, test, tagNode, i, neighbor);

			if (queryRadius != 0)
			{
				FindNeighbor(tstream, test, i, neighbor, queryRadius, tstream.GetDataStreamBegin());
			}
			if (neighbor != -1)
				InsertMapCandidateSet(i, neighbor, queryRadius);
			tagNode = NULL;
		}
		newObj = tstream.GetDataStreamTag();
	}

}

void Tree::Prune(TStream& tstream, Test& test, TreeNode* node, int objId, double radius, queue<TreeNode*>& queResultLevelOrder)
{

	for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
	{
		if (IsCover(tstream, test, *iterLstPointer, objId))
		{
			queResultLevelOrder.push(*iterLstPointer);
		}
		else
		{
			double distance = 0;
			distance = GetDistanceBrothers(tstream, test, *iterLstPointer, objId);
			if (distance <= radius)
			{
				queResultLevelOrder.push(*iterLstPointer);
			}
		}
	}
}

void Tree::Prune(TStream& tstream, Test& test, int objId, double radius, queue<TreeNode*>& queResultLevelOrder)
{
	queue<TreeNode*> result;
	TreeNode* node;
	while (!queResultLevelOrder.empty())
	{
		node = queResultLevelOrder.front();
		if (IsCover(tstream, test, node, objId))
		{
			result.push(node);
		}
		else
		{
			double distance = 0;
			distance = GetDistanceBrothers(tstream, test, node, objId);
			if (distance <= radius)
			{
				result.push(node);
			}
		}
		queResultLevelOrder.pop();
	}
	queResultLevelOrder.swap(result);
}

bool Tree::IsCover(TStream& tstream, Test& test, TreeNode* node, int objId)
{
	for (int i = 0; i < test.GetDimension(); i++)
	{
		double  temp = tstream.GetDataStream(objId * test.GetDimension() + i);
		if (tstream.GetDataStream(objId * test.GetDimension() + i) >= node->vecLeftDown[i] && tstream.GetDataStream(objId * test.GetDimension() + i) <= node->vecRightUp[i])
		{
			continue;
		}
		else
		{
			return false;
		}
	}
	return true;

}

double Tree::GetDistanceBrothers(TStream& tstream, Test& test, TreeNode* node, int objId)
{
	double result = 0;
	for (int i = 0; i < test.GetDimension(); i++)
	{
		double temp, temp1, temp2;
		temp = tstream.GetDataStream(objId * test.GetDimension() + i);
		temp1 = node->vecLeftDown[i];
		temp2 = node->vecLeftDown[i] + node->sideLength;
		if (temp < temp1)
		{
			result += pow(abs(temp - temp1), 2);
		}
		else if (temp > temp2)
		{
			result += pow(abs(temp2 - temp), 2);
		}
	}
	result = sqrt(result);
	return result;
}

double Tree::GetDistance(TStream& tstream, Test& test, int objId1, int objId2)
{
	double result = 0;
	for (int i = 0; i < test.GetDimension(); i++)
	{
		result += pow(tstream.GetDataStream(objId1 * test.GetDimension() + i) - tstream.GetDataStream(objId2 * test.GetDimension() + i), 2);
	}
	return  sqrt(result);

}

double Tree::GetMaxDifference(TStream& tstream, Test& test, int objId1, int objId2)
{
	double maxDifference = -1;
	for (int i = 0; i < test.GetDimension(); i++)
	{
		if (fabs(tstream.GetDataStream(objId1 * test.GetDimension() + i) - tstream.GetDataStream(objId2 * test.GetDimension() + i)) > maxDifference)
		{
			maxDifference = tstream.GetDataStream(objId1 * test.GetDimension() + i) - tstream.GetDataStream(objId2 * test.GetDimension() + i);
		}
	}
	return maxDifference;
}

Tree::TreeNode* Tree::TreeNodeInsert(TStream& tstream, Test& test, int objId)
{
	queue<TreeNode*> queCreateTree;
	TreeNode* result = NULL;
	queCreateTree.push(root);
	root->vecObject.push_back(objId);
	while (!queCreateTree.empty())
	{
		if (queCreateTree.front()->lstPointer.size() == 0)
		{
			for (auto iterVecObject = queCreateTree.front()->vecObject.begin(); iterVecObject != queCreateTree.front()->vecObject.end(); )
			{
				if (*iterVecObject < tstream.GetDataStreamBegin())
				{
					iterVecObject = queCreateTree.front()->vecObject.erase(iterVecObject);
				}
				else
				{
					iterVecObject++;
				}
			}
		}
		if (queCreateTree.front()->sideLength <= tstream.GetLength() / 1024 / 1024 / 1024)
		{
			queCreateTree.pop();
			continue;
		}

		UpdateTreeNodeSplit(tstream, test, queCreateTree.front());
		for (auto iterLstPointer = queCreateTree.front()->lstPointer.begin(); iterLstPointer != queCreateTree.front()->lstPointer.end(); iterLstPointer++)
		{
			if (IsCover(tstream, test, *iterLstPointer, objId))
			{
				result = *iterLstPointer;
			}
			if ((*iterLstPointer)->vecObject.size() > NUM || ((*iterLstPointer)->vecObject.size() == 1 && (*iterLstPointer)->lstPointer.size() != 0))
			{
				queCreateTree.push((*iterLstPointer));
			}
		}
		queCreateTree.pop();
	}
	return result;
}

void Tree::UpdataCandidateSet(int tstreamBegin)
{
	for (auto iterMapCandidateSet = mapCandidateSet.begin(); iterMapCandidateSet != mapCandidateSet.end(); )
	{
		if (iterMapCandidateSet->second.neighborId < tstreamBegin || iterMapCandidateSet->second.objId < tstreamBegin)
		{
			mapCandidateSet.erase(iterMapCandidateSet++);
		}
		else
		{
			iterMapCandidateSet++;
		}
	}
}

void Tree::PrintMapCandidateSet(Test& test, int tstreamBegin)
{
	int k = 0;
	for (auto iterMapCandidateSet = mapCandidateSet.begin(); iterMapCandidateSet != mapCandidateSet.end(); iterMapCandidateSet++)
	{
		if (k == 10)
			break;
		if (iterMapCandidateSet->second.objId < tstreamBegin || iterMapCandidateSet->second.neighborId < tstreamBegin)
		{
			continue;
		}
		k++;
	}
}

void Tree::PrintMapSet(Test& test, int datasBegin)
{
	int k = 0;
	for (auto iter = mapCandidateSet.begin(); iter != mapCandidateSet.end(); iter++)
	{

		if (k == test.GetTopK())
			break;
		if (iter->second.objId < datasBegin || iter->second.neighborId < datasBegin)
		{
			continue;
		}
		k++;
		cout << "The nearest neighbor of " << iter->second.objId << " is " << iter->second.neighborId << "distance:" << iter->first << endl;
	}
}