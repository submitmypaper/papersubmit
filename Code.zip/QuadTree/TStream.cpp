#include "TStream.h"
#include<string>
#pragma warning(disable:4996)
TStream::TStream()
{
}

TStream::~TStream()
{
}
void TStream::ReadDataFile()
{
	FILE* fp1;
	double dlNumber;
	double maxData = 0;
	double step = 0.05;
	int objectNumber = 0;
	if ((fp1 = fopen("SourceFile.txt", "r")) != NULL)
	{
		while (fscanf(fp1, "%lf", &dlNumber) != EOF)
		{
			if (maxData < dlNumber)
				maxData = dlNumber;
			vecDataStream.push_back(dlNumber);
		}
	}
	length = maxData;
	length = pow(2, ceil(log2(length)));
}
double TStream::GetDataStream(int intObjectNumber)
{
	return vecDataStream[intObjectNumber];
}

int TStream::GetDataStreamLength()
{
	return vecDataStream.size();
}



double TStream::GetLength()
{
	return length;
}

int TStream::GetDataStreamBegin()
{
	return dataStreamBegin;
}

int TStream::GetDataStreamTag()
{
	return dataStreamTag;
}

void TStream::SetDataStreamBegin(int begin)
{
	dataStreamBegin = begin;
}

void TStream::SetDataStreamTag(int tag)
{
	dataStreamTag = tag;
}

void TStream::Init(Test test)
{
	ReadDataFile();
	SetDataStreamTag(test.GetWindowSize() / test.GetDimension());
	SetDataStreamBegin(0);
}

void TStream::AddDataStreamBegin(int outflow)
{
	dataStreamBegin += outflow;
}

void TStream::AddDataStreamTag(int inflow)
{
	dataStreamTag += inflow;
}
