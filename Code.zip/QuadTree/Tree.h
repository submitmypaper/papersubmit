#pragma once
#pragma once
#include <vector>
#include <list>
#include <queue>
#include <map>
#include "TStream.h"
#include "Test.h"
using namespace std;
class Tree
{
public:
	Tree();

	~Tree();

	struct TreeNode
	{
		long addr = 0;
		vector<int> vecObject;
		list<TreeNode*> lstPointer;
		TreeNode* fatherNode;
		vector<double> vecLeftDown;
		vector<double> vecRightUp;
		double sideLength;
		int height;
	};
	struct Pair
	{
		int objId;
		int neighborId;
	};
	void FindNeighbor(TStream& tstream, Test& test, int objId, int& neighbor, double& radius, int tstreamBegin);
	void InsertMapCandidateSet(int objId, int neighbor, double distance);
	long Findaddr(TStream& tstream, int objNo, int d, vector<double>& vecLeftDown, double side);
	void CreateTree(TStream& tstream, Test& test);
	void CreateTreeNode(TreeNode* node, int objNo, int addr, int height, int sideLenght);
	void RootInit(TStream& tstream, Test& test);
	void TreeNodeSplit(TStream& tstream, Test& test, TreeNode* node);
	void UpdateTreeNodeSplit(TStream& tstream, Test& test, TreeNode* node);
	void TreeNodePushBack(int objNo, long addr, TreeNode* node);
	void GetTreeNodeCoordinate(TStream& tstream, int objNo, int d, vector<double>& vecLeftDown, vector<double>& newVecLeftDown, vector<double>& vecRightUp, vector<double>& newVecRightUp, double side);
	void SetTreeNodeCoordinate(TreeNode* node, vector<double>& vecLeftDown, vector<double>& vecRightUp);
	void PreOrderTree(TStream& tstream, Test& test);
	double GetInitRadius(TStream& tstream, Test& test, TreeNode* node, int objId, int& neighbor);
	void UpdateDataFlow(TStream& tstream, Test& test, double& time);
	void Prune(TStream& tstream, Test& test, TreeNode* node, int objId, double radius, queue<TreeNode*>& queResultLevelOrder);
	void Prune(TStream& tstream, Test& test, int objId, double radius, queue<TreeNode*>& queResultLevelOrder);
	bool IsCover(TStream& tstream, Test& test, TreeNode* node, int objId);
	double GetDistanceBrothers(TStream& tstream, Test& test, TreeNode* node, int objId);
	double GetDistance(TStream& tstream, Test& test, int objId1, int objId2);
	double GetMaxDifference(TStream& tstream, Test& test, int objId1, int objId2);
	TreeNode* TreeNodeInsert(TStream& tstream, Test& test, int objId);
	void UpdataCandidateSet(int tstreamBegin);
	void PrintMapCandidateSet(Test& test, int tstreamBegin);
	double GetQueryRadiusInThis(TStream& tstream, Test& test, int objId, vector<int> vecObject, int& neighbor);
	double GetQueryRadiusInOther(TStream& tstream, Test& test, int objId, TreeNode* fatherNode, int& neighbor);
	double GetDistanceFromOtherNode(TStream& tstream, Test& test, int objId, vector<double>& vecLeftDown, vector<double>& vecRightUp);
	void PrintMapSet(Test& test, int datasBegin);
private:

	TreeNode* root;
	map<double, Pair> mapCandidateSet;

};

