#include "Tree.h"
#include <stack>
#include <iomanip>
#include <deque>
#include <fstream>
#define NUM 8
static int nodenum = 0;
static long long int queryObjNum = 0;
Tree::Tree()
{
}

Tree::~Tree()
{
}

int Tree::GetID()
{
	return ID;
}

void Tree::AddID(int add)
{
	ID += add;
}


void Tree::FindNeighbor(TStream& tstream, Test& test, int objId, int& neighbor, double& radius, int tstreamBegin, int& objNum,TreeNode* node)
{
	double dis;
	queue<TreeNode*> queNode;
	queue<TreeNode*> stackNode;
	stackNode.push(node);
	
	while (node->fatherNode != NULL) {
		node = node->fatherNode;
		stackNode.push(node);
	}
	while (!stackNode.empty()) {
		if (stackNode.front()->fatherNode != NULL) {
			for (auto iter = stackNode.front()->fatherNode->lstPointer.begin(); iter != stackNode.front()->fatherNode->lstPointer.end(); iter++) {
				if ((*iter)->NodeID != stackNode.front()->NodeID&&GetDistanceBrothers(tstream,test,*iter,objId)<= radius)
					queNode.push(*iter);
			}
		}
		stackNode.pop();

		while (!queNode.empty()) {
			if (queNode.front()->lstPointer.size() == 0 && queNode.front()->vecObject.size() > 0)
			{
				nodenum++;
				queryObjNum += queNode.front()->vecObject.size();
				for (auto iterLstObject = queNode.front()->vecObject.begin(); iterLstObject != queNode.front()->vecObject.end(); )
				{
					if (*iterLstObject < tstream.GetDataStreamBegin())
					{
						iterLstObject = queNode.front()->vecObject.erase(iterLstObject);
						continue;
					}
					dis = GetDistance(tstream, test, *iterLstObject, objId);
					if (dis < radius && dis != 0 && *iterLstObject != objId)
					{
						neighbor = *iterLstObject;
						radius = dis;
					}
					iterLstObject++;
				}
			}
			else
			{
				Prune(tstream, test, queNode.front(), objId, radius, queNode);
			}
			queNode.pop();
		}
	}
}

bool Tree::GetdisNode(TStream& tstream, Test& test, int objId, TreeNode* node, double radius)
{
	for (int i = 0; i < test.GetDimension(); i++) {
		
		if (min(fabs(tstream.GetDataStream(objId * test.GetDimension() + i) - node->vecLeftDown[i]), fabs(tstream.GetDataStream(objId * test.GetDimension() + i) - node->vecRightUp[i])) > radius)
		{
			return false;
		}
	}
	return true;
}

void Tree::InsertMapCandidateSet(int objId, int neighbor, double distance)
{
	int times = 0;
	double step = 0.000001;
	Pair temp, temp1;
	temp.objId = objId;
	temp.neighborId = neighbor;
	std::pair<std::map<double, Pair>::iterator, bool> ret1;
	ret1 = mapCandidateSet.insert(make_pair(distance, temp));
	temp1 = mapCandidateSet[distance];
	while (!ret1.second)
	{
		if (temp1.objId == temp.neighborId && temp1.neighborId == temp.objId)
			return;
		else
		{
			if (times > 10) {
				return;
			}
			ret1 = mapCandidateSet.insert(make_pair(distance + step, temp));
			step += 0.000001;
			times++;
		}
	}
}

long Tree::Findaddr(TStream& tstream, int objNo, int d, vector<double>& vecLeftDown, double side)
{
	long addr = 0;
	int temp = 0;

	for (int i = 0; i < d; i++)
	{
		double a = tstream.GetDataStream(objNo * d + i);
		temp = (tstream.GetDataStream(objNo * d + i) - vecLeftDown[i]) / side;
		addr = (addr << 1) | temp;
	}
	return addr;
}

void Tree::RootInit(TStream& tstream, Test& test)
{
	for (int i = 0; i < test.GetWindowSize() / test.GetDimension(); i++)
	{
		root->vecObject.push_back(i);
	}
	for (int i = 0; i < test.GetDimension(); i++)
	{
		root->vecLeftDown.push_back(0);
		root->vecRightUp.push_back(tstream.GetLength());
	}
	root->sideLength = tstream.GetLength();
	root->height = 0;
	root->fatherNodeObjNum = root->vecObject.size();
	root->vecSide.insert(root->vecSide.begin(), test.GetWindowSize() / test.GetDimension(), -100);
	root->NodeID = GetID();
}

void Tree::TreeNodeSplit(TStream& tstream, Test& test, TreeNode* node)
{
	long addr = 0;
	for (auto iterlstObj = node->vecObject.begin(); iterlstObj != node->vecObject.end(); iterlstObj++)
	{
		addr = Findaddr(tstream, *iterlstObj, test.GetDimension(), node->vecLeftDown, node->sideLength / 2);
		TreeNodePushBack(tstream,test,*iterlstObj, addr, node); 
	}
	node->vecObject.clear();
}

void Tree::NewTreeNodeSplit(TStream& tstream, Test& test, TreeNode* node)
{
	long addr = 0;
	for (auto iterlstObj = node->vecObject.begin(); iterlstObj != node->vecObject.end(); iterlstObj++)
	{
		if (IsCover(tstream, test, node->lstPointer.front(), *iterlstObj)) {
			node->lstPointer.front()->vecObject.push_back(*iterlstObj);
			continue;
		}
		addr = Findaddr(tstream, *iterlstObj, test.GetDimension(), node->vecLeftDown, node->sideLength / 2);
		TreeNodePushBack(tstream,test,*iterlstObj, addr, node);
	}
	node->vecObject.clear();
}

bool Tree::CreatNewTree(TStream& tstream, Test& test, TreeNode* node)
{

	vector<double> medianCoordinate;
	vector<double> coordinate;
	double newSide = 0.0;
	long addr = 0;
	int n = 0;
	node->fatherNode->flag = 1;

	for (int number = 0; number < node->vecObject.size(); number++)
	{
		root->vecSide[number] = -100;
	}

	GetMedian(tstream, test, node, coordinate, medianCoordinate);
	newSide = GetNewSide(tstream, test, node, medianCoordinate);
	if (newSide == 0)
		return false;
	TreeNode* newNode = NewCreateTreeNode(node, newSide);

	for (int i = 0; i < test.GetDimension(); i++)
	{
		newNode->vecLeftDown.push_back(node->vecLeftDown[i]);
		newNode->vecRightUp.push_back(node->vecLeftDown[i] + newSide);
	}

	for (auto iter=node->vecObject.begin();iter!=node->vecObject.end();)
	{
		if (IsCover(tstream, test, newNode, *iter)) {
			newNode->vecObject.push_back(*iter);
			iter = node->vecObject.erase(iter);
		}
		iter++;
	}
	return true;
}

void Tree::InitRootTree(TStream& tstream, Test& test, TreeNode* node)
{
	vector<double> medianCoordinate;
	vector<double> coordinate(node->vecObject.size() * test.GetDimension(), 0);
	double newSide = 0.0;

	GetMedian(tstream, test, node, coordinate, medianCoordinate);
	newSide = GetNewSide(tstream, test, node, medianCoordinate);
	TreeNode* newNode = InitCreateTreeNode(node, newSide);

	for (int number = 0; number < node->vecObject.size(); number++)
	{
		root->vecSide[number] = -100;
	}

	for (int i = 0; i < test.GetDimension(); i++)
	{
		newNode->vecLeftDown.push_back(node->vecLeftDown[i]);
		newNode->vecRightUp.push_back(node->vecLeftDown[i] + newSide);
	}

	for (auto iter = node->vecObject.begin(); iter != node->vecObject.end();)
	{
		if (IsCover(tstream, test, newNode, *iter)) {
			newNode->vecObject.push_back(*iter);
			iter = node->vecObject.erase(iter);
		}
		iter++;
	}
}

void Tree::GetMedian(TStream& tstream, Test& test, TreeNode* node, vector<double>& objCoordinate, vector<double>& result)
{
	
	for (int i = 0; i < test.GetDimension(); i++)
	{
		for (auto iter=node->vecObject.begin();iter!=node->vecObject.end();iter++)
		{
			objCoordinate.push_back(tstream.GetDataStream((*iter) * test.GetDimension() + i));
		}
	}
	for (int i = 0; i < test.GetDimension(); i++) {
		nth_element(objCoordinate.begin() + i * node->vecObject.size(), objCoordinate.begin() + node->vecObject.size() / 2 + i * node->vecObject.size() - 1, objCoordinate.begin() + node->vecObject.size() * (i + 1));
		result.push_back(objCoordinate[i * node->vecObject.size() + node->vecObject.size() / 2]);
	}
}

double Tree::GetMedian(TStream& tstream, Test& test, TreeNode* node, vector<double>& objCoordinate)
{
	
	for (int i = 0; i < test.GetDimension(); i++)
	{
		int number = 0;
		for (auto iter=node->vecObject.begin();iter!=node->vecObject.end();iter++)
		{
			objCoordinate[i * node->vecObject.size() + number] = tstream.GetDataStream((*iter) * test.GetDimension() + i);
			number++;
		}
	}
	nth_element(objCoordinate.begin(), objCoordinate.begin() + objCoordinate.size() / 2 - 1, objCoordinate.end());
	return objCoordinate[objCoordinate.size() / 2];
}

double Tree::GetNewSide(TStream& tstream, Test& test, TreeNode* node, vector<double> medianCoordinate)
{
	double distance = 0;
	int resolution = 0;
	int n;
	long addr1;
	long addr2;
	long addr3 = 0;
	double minSide = 0;
	double temp1 = 0;
	double temp = 0;
	double temp3 = 0;
	double temp4 = 0;
	for (int i = 0; i < test.GetDimension(); i++)
	{
		int number = 0;
		for (auto iter =node->vecObject.begin();iter!=node->vecObject.end();iter++)
		{
			distance = abs(tstream.GetDataStream((*iter) * test.GetDimension() + i) - medianCoordinate[i]);
			if (distance == 0)
			{
				continue;
			}
			temp1 = node->sideLength / distance;
			temp = log(node->sideLength / distance) / log(2);
			resolution = ceil(log(node->sideLength / distance) / log(2));
			n = pow(2, resolution);
			minSide = node->sideLength / n;
			addr1 = floor((medianCoordinate[i] - node->vecLeftDown[i]) / minSide);
			addr2 = floor(((tstream.GetDataStream((*iter) * test.GetDimension() + i)) - node->vecLeftDown[i]) / minSide);
			addr3 = addr1 ^ addr2;
			addr3 = floor(log(addr3)) - resolution + 1;
			root->vecSide[number] = (double)max((long)root->vecSide[number], addr3);
			number++;
		}
	}
	nth_element(root->vecSide.begin(), root->vecSide.begin() + node->vecObject.size() / 2, root->vecSide.begin() + node->vecObject.size());
	temp3 = root->vecSide[node->vecObject.size() / 2];
	temp4 = node->sideLength * pow(2, min(root->vecSide[node->vecObject.size() / 2], -1.0));
	return node->sideLength * pow(2, min(root->vecSide[node->vecObject.size() / 2], -1.0));
}

int Tree::GetDecimalPlaces(double num) {
	num = num - (int)num;
	for (int i = 0; i < 10; i++) {
		num *= 10;
		if (num - (int)num == 0) {
			return i + 1;
		}
	}
}

void Tree::UpdateTreeNodeSplit(TStream& tstream, Test& test, TreeNode* node)
{
	long addr = 0;
	for (auto iterlstObj = node->vecObject.begin(); iterlstObj != node->vecObject.end(); iterlstObj++)
	{
		addr = Findaddr(tstream, *iterlstObj, test.GetDimension(), node->vecLeftDown, node->sideLength / 2);
		TreeNodePushBack(tstream,test,*iterlstObj, addr, node);
	}
	node->vecObject.clear();
}

void Tree::TreeNodePushBack(TStream& tstream, Test& test, int objNo, long addr, TreeNode* node)
{
	for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
	{

		if ((*iterLstPointer)->addr == addr)
		{
			(*iterLstPointer)->vecObject.push_back(objNo);
			return;
		}
	}
	CreateTreeNode(tstream,test,node, objNo, addr, node->height, node->sideLength);
}


void Tree::SetTreeNodeCoordinate(TStream& tstream,TreeNode* node, int objNo,int d,vector<double>& vecLeftDown, vector<double>& vecRightUp,double side)
{
	int temp = 0;
	for (int i = 0; i < d; i++)
	{
		temp = (tstream.GetDataStream(objNo * d + i) - vecLeftDown[i]) / side;
		node->vecLeftDown.push_back(vecLeftDown[i] + temp * side);
		node->vecRightUp.push_back(vecRightUp[i] - (1 - temp) * side);
	}
}

void Tree::CreateTree(TStream& tstream, Test& test)
{
	root = new TreeNode;
	RootInit(tstream, test);
	queue<TreeNode*> queCreateTree;
	queCreateTree.push(root);
	root->fatherNode = NULL;
	TreeNode* node;
	int objectNum = 0;

	while (!queCreateTree.empty())
	{
		node = queCreateTree.front();
		if (node->sideLength <= tstream.GetLength() / 1024 / 1024 / 1024)
		{
			queCreateTree.pop();
			continue;
		}
		TreeNodeSplit(tstream, test, node);
		for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
		{
			if ((((*iterLstPointer)->vecObject.size() > 0.5 * node->fatherNodeObjNum) && node->flag != 1) && ((*iterLstPointer)->vecObject.size() > NUM))
			{
				if (CreatNewTree(tstream, test, *iterLstPointer))
					queCreateTree.push(node->lstPointer.front());
			}
			if ((*iterLstPointer)->vecObject.size() > NUM)
			{
				queCreateTree.push((*iterLstPointer));
			}
		}
		queCreateTree.pop();
	}
}

void Tree::CreateTreeNode(TStream& tstream, Test& test, TreeNode* node, int objNo, int addr, int height, int sideLenght)
{
	TreeNode* newnode = new TreeNode;
	newnode->vecObject.push_back(objNo);
	if (newnode->vecObject.size() == 1) {
		SetTreeNodeCoordinate(tstream,newnode, newnode->vecObject.front(),test.GetDimension(),node->vecLeftDown,node->vecRightUp,node->sideLength/2);
	}
	newnode->addr = addr;
	newnode->height = node->height + 1;
	newnode->sideLength = node->sideLength / 2;
	newnode->fatherNode = node;
	newnode->fatherNodeObjNum = node->vecObject.size();
	AddID(1);
	newnode->NodeID = GetID();
	node->lstPointer.push_back(newnode);
}

Tree::TreeNode* Tree::NewCreateTreeNode(TreeNode* node, int sideLenght)
{
	TreeNode* newnode = new TreeNode;
	newnode->addr = -1;
	newnode->height = node->height;
	newnode->sideLength = sideLenght;
	newnode->fatherNode = node->fatherNode;
	newnode->fatherNodeObjNum = node->fatherNodeObjNum;
	AddID(1);
	newnode->NodeID = GetID();
	node->fatherNode->lstPointer.push_front(newnode);
	return newnode;
}

Tree::TreeNode* Tree::InitCreateTreeNode(TreeNode* node, int sideLenght)
{
	TreeNode* newnode = new TreeNode;
	newnode->addr = -1;
	newnode->height = node->height + 1;
	newnode->sideLength = sideLenght;
	newnode->fatherNode = node;
	node->lstPointer.push_front(newnode);
	return newnode;
}

void Tree::GetNodeNum(TStream& tstream, Test& test, long& num)
{
	queue<TreeNode*> queTreeNode;
	queTreeNode.push(root);
	while (!queTreeNode.empty())
	{
		num += queTreeNode.front()->lstPointer.size();
		for (auto it = queTreeNode.front()->lstPointer.begin(); it != queTreeNode.front()->lstPointer.end(); it++) {
			queTreeNode.push(*it);
		}
		queTreeNode.pop();
	}
}

void Tree::DeleteOverDueObj(TStream& tstream, Test& test, int& objNum)
{
	queue<TreeNode*> queDleOrder;
	TreeNode* orderPointer = root;
	queDleOrder.push(orderPointer);
	while (!queDleOrder.empty())
	{
		orderPointer = queDleOrder.front();

		if (orderPointer->lstPointer.size() == 0)
		{
			for (auto iterObject = orderPointer->vecObject.begin(); iterObject != orderPointer->vecObject.end(); )
			{
				if (*iterObject < tstream.GetDataStreamBegin())
				{
					iterObject = orderPointer->vecObject.erase(iterObject);
					continue;
				}
				else {
					break;
				}
				
			}
		}

		for (auto iterLstPointer = orderPointer->lstPointer.begin(); iterLstPointer != orderPointer->lstPointer.end(); iterLstPointer++)
		{
			queDleOrder.push(*iterLstPointer);
		}
		queDleOrder.pop();
	}

}

void Tree::UpdateNodeObjNum(TStream& tstream, Test& test)
{
	deque<TreeNode*> postTree;
	stack<TreeNode*> stkNode;
	stkNode.push(root);
	TreeNode* node;
	root->childNodeObjNum = 0;
	while (!stkNode.empty())
	{
		node = stkNode.top();
		stkNode.pop();
		postTree.push_back(node);
		for (auto& childNode : node->lstPointer)
		{
			childNode->childNodeObjNum = 0;
			if (childNode->lstPointer.size() == 0)
				childNode->childNodeObjNum = childNode->vecObject.size();
			stkNode.push(childNode);
		}
	}
	while (!postTree.empty())
	{
		node = postTree.back();
		postTree.pop_back();
		if (node->fatherNode != nullptr)
			node->fatherNode->childNodeObjNum += node->childNodeObjNum;
	}
}

void Tree::Restructure(TStream& tstream, Test& test, TreeNode* node)
{
	list<TreeNode*>::iterator temp;
	int num = -1;
	for (auto iter = node->lstPointer.begin(); iter != node->lstPointer.end(); iter++) {
		if ((*iter)->childNodeObjNum > num) {
			temp = iter;
			num = ( * temp)->childNodeObjNum;
		}
	}
	(*temp)->addr = -1;

	node->fatherNode->lstPointer.push_front(*temp);
	node->fatherNode->lstPointer.front()->fatherNode = node->fatherNode;
	node->fatherNode->lstPointer.front()->height--;
	node->childNodeObjNum -= (*temp)->childNodeObjNum;
	node->lstPointer.erase(temp);
}

void Tree::MergeTree(TStream& tstream, Test& test, TreeNode* node)
{
	for (auto itlstPoint1 = --node->lstPointer.end(); itlstPoint1 != node->lstPointer.begin(); itlstPoint1--)
	{
		for (auto itlstPoint2 = --itlstPoint1; itlstPoint2 != node->lstPointer.begin(); )
		{
			if (IsCover(tstream, test, *itlstPoint1, *itlstPoint2))
			{
				itlstPoint1++;
				(*itlstPoint1)->lstPointer.push_front(*itlstPoint2);
				(*itlstPoint2)->fatherNode = *itlstPoint1;
				(*itlstPoint2)->height++;

				(*itlstPoint1)->childNodeObjNum += (*itlstPoint2)->childNodeObjNum;
				itlstPoint2 = node->lstPointer.erase(itlstPoint2);
			}
			itlstPoint2--;
		}
		itlstPoint1++;
	}
}

void Tree::UpdateTreeNode(TStream& tstream, Test& test, TreeNode* node)
{
	int max = -1;
	list<TreeNode*>::iterator  tag;
	if (node->lstPointer.size() == 0)
		return;
	for (auto itlstpoint = node->lstPointer.begin(); itlstpoint != node->lstPointer.end(); itlstpoint++)
	{
		if ((*itlstpoint)->childNodeObjNum >0)
			if (max < (*itlstpoint)->childNodeObjNum)
			{
				max = (*itlstpoint)->childNodeObjNum;
				tag = itlstpoint;
			}
	}
	(*tag)->addr = -1;

	node->fatherNode->lstPointer.push_front(*tag);
	node->fatherNode->lstPointer.front()->fatherNode = node->fatherNode;
	node->fatherNode->lstPointer.front()->height--;


	node->childNodeObjNum -= (*tag)->childNodeObjNum;
	node->lstPointer.erase(tag);
}

void Tree::initSubTree(TStream& tstream, Test& test, TreeNode* temp)
{
	queue<TreeNode*> queCreateTree;
	queCreateTree.push(temp);
	TreeNode* node;
	while (!queCreateTree.empty())
	{
		node = queCreateTree.front();
		if (node->sideLength <= tstream.GetLength() / 1024 / 1024 / 1024)
		{
			queCreateTree.pop();
			continue;
		}
		TreeNodeSplit(tstream, test, node);
		for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
		{
			if ((((*iterLstPointer)->vecObject.size() > 0.75 * node->fatherNodeObjNum) && node->flag != 1) && ((*iterLstPointer)->vecObject.size() >NUM))
			{
				if (CreatNewTree(tstream, test, *iterLstPointer))
					queCreateTree.push(node->lstPointer.front());
			}
			if ((*iterLstPointer)->vecObject.size() > NUM)
			{
				queCreateTree.push((*iterLstPointer));
			}
		}
		queCreateTree.pop();
	}
}

void Tree::GetPoint(TStream& tstream, TreeNode* node, list<int>& lists,list<TreeNode*>& postTree)
{
	queue<TreeNode*> queNode;
	queNode.push(node);
	list<TreeNode*> nodeList;
	TreeNode* temp = NULL;
	while (!queNode.empty()) {
		if (queNode.front()->lstPointer.size() == 0) {
			for (auto iter = queNode.front()->vecObject.begin(); iter != queNode.front()->vecObject.end(); iter++) {
				if (*iter < tstream.GetDataStreamBegin()) {
					continue;
				}
				lists.push_back(*iter);
			}
			queNode.front()->vecObject.clear();
			queNode.pop();
			continue;
		}
		for (auto iter = queNode.front()->lstPointer.begin(); iter != queNode.front()->lstPointer.end(); iter++) {
			queNode.push(*iter);
			nodeList.push_back(*iter);
		}
		queNode.pop();
	}
	node->lstPointer.clear();
	for (auto iter = nodeList.begin(); iter != nodeList.end(); iter++) {
		postTree.remove(*iter);
		temp = *iter;
		delete temp;
		temp = NULL;
	}
	nodeList.clear();
}

bool Tree::IsCover(TStream& tstream, Test& test, TreeNode* node1, TreeNode* node2)
{
	for (int i = 0; i < test.GetDimension(); i++)
	{
		if (node1->vecLeftDown[i] <= node2->vecLeftDown[i] && node1->vecRightUp[i] >= node2->vecRightUp[i])
		{
			continue;
		}
		else
		{
			return false;
		}
	}
	return true;
}

void Tree::PrintMapSet(Test& test, int datasBegin)
{
	int k = 0;
	for (auto iter = mapCandidateSet.begin(); iter != mapCandidateSet.end(); iter++)
	{

		if (k == test.GetTopK())
			break;
		if (iter->second.objId < datasBegin || iter->second.neighborId < datasBegin)
		{
			continue;
		}
		k++;
		cout << "The nearest neighbor of " << iter->second.objId << " is " << iter->second.neighborId << "distance:" << iter->first << endl;
	}
}

void Tree::PreOrderTree(TStream& tstream, Test& test)
{
	queue<TreeNode*> quePreOrder;
	int neighbor = -1;
	int unUsed = 0;
	TreeNode* orderPointer;
	mapCandidateSet.clear();
	double queryRadius = 0;
	quePreOrder.push(root);

	while (!quePreOrder.empty())
	{
		orderPointer = quePreOrder.front();
		if (orderPointer->lstPointer.size() == 0)
		{
			for (auto iterObject = orderPointer->vecObject.begin(); iterObject != orderPointer->vecObject.end(); iterObject++)
			{
				neighbor = -1;
				queryRadius = GetInitRadius(tstream, test, orderPointer, *iterObject, neighbor, unUsed);		
				if (queryRadius != 0)
				{
					FindNeighbor(tstream, test, *iterObject, neighbor, queryRadius, 0, unUsed,orderPointer);
				}
				if (neighbor != -1) {
					InsertMapCandidateSet(*iterObject, neighbor, queryRadius);
				}
				
			}
		}

		for (auto iterLstPointer = orderPointer->lstPointer.begin(); iterLstPointer != orderPointer->lstPointer.end(); iterLstPointer++)
		{
			quePreOrder.push(*iterLstPointer);
		}
		quePreOrder.pop();
	}
}

double Tree::GetInitRadius(TStream& tstream, Test& test, TreeNode* node, int objId, int& neighbor, int& objNum)
{
	double distance;
	double minDistance = 0xfffffff;
	if (node->vecObject.size() > 1)
	{
		for (auto iterVecObject = node->vecObject.begin(); iterVecObject != node->vecObject.end(); )
		{
			distance = 0;
			if (*iterVecObject < tstream.GetDataStreamBegin())
			{
				iterVecObject = node->vecObject.erase(iterVecObject);
				objNum--;
			}
			else
			{
				if (*iterVecObject != objId) {
					distance = GetDistance(tstream, test, objId, *iterVecObject);
					if (distance < minDistance)
					{
						minDistance = distance;
						neighbor = *iterVecObject;
					}
				}
				iterVecObject++;
			}
		}
	}
	else if (node->vecObject.size() <= 1 || minDistance == 0xfffffff || minDistance == 0)
	{
		return node->sideLength;
	}
	return minDistance;
	
}

int Tree::GetObjNumber(TStream& tstream, Test& test, TreeNode* node) {
	int objNumber = 0;
	queue<TreeNode*> queInsert;
	queInsert.push(node->fatherNode);
	TreeNode* temp;

	while (!queInsert.empty())
	{
		temp = queInsert.front();
		if (temp->lstPointer.size() == 0)
		{
			for (auto iterVecObject = temp->vecObject.begin(); iterVecObject != temp->vecObject.end(); )
			{
				if (*iterVecObject < tstream.GetDataStreamBegin())
				{
					iterVecObject = node->vecObject.erase(iterVecObject);
					continue;
				}
				objNumber += temp->vecObject.size();
				iterVecObject++;
			}
		}
		else
		{
			for (auto iterLstPointer = temp->lstPointer.begin(); iterLstPointer != temp->lstPointer.end(); iterLstPointer++)
			{
				queInsert.push(*iterLstPointer);
			}
		}
		queInsert.pop();
	}
	return objNumber;
}

void Tree::UpdateDataFlow(TStream& tstream, Test& test, double& time)
{
	int newObj = test.GetWindowSize() / test.GetDimension();
	int neighbor = -1;
	double queryRadius = 0;
	tstream.SetDataStreamTag(test.GetWindowSize() / test.GetDimension());
	tstream.SetDataStreamBegin(0);
	int objNum = test.GetWindowSize() / test.GetDimension();
	int nowObjNum = objNum;
	TreeNode* tagNode;

	time = 0;
	int flags = 0;
	clock_t startTime1, endTime1;
	for (; tstream.GetDataStreamTag() < 52428800 + objNum; )
	{

		tstream.AddDataStreamBegin(1);
		tstream.AddDataStreamTag(1);

		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 1)
		{
			startTime1 = clock();
		}
		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 0&& tstream.GetDataStreamTag()>= 1048576)
		{
			endTime1 = clock();
			cout << "Current cursor:" << tstream.GetDataStreamTag() << "     Time = " << (double)(endTime1 - startTime1) / CLOCKS_PER_SEC << "s" << endl;
		}

		if ((tstream.GetDataStreamTag() - tstream.GetDataStreamBegin()) >= 10 * (test.GetWindowSize() / test.GetDimension()))
		{
			tstream.SetDataStreamBegin(tstream.GetDataStreamTag() - (test.GetWindowSize() / test.GetDimension()));
		}

		if ((tstream.GetDataStreamTag() - tstream.GetDataStreamBegin()) <= 0.1 * (test.GetWindowSize() / test.GetDimension()))
		{
			tstream.SetDataStreamTag(tstream.GetDataStreamBegin() + (test.GetWindowSize() / test.GetDimension()));
			if (tstream.GetDataStreamTag() > tstream.GetDataStreamLength() / test.GetDimension())
			{
				tstream.SetDataStreamTag(tstream.GetDataStreamLength() / test.GetDimension());
			}
		}

		nowObjNum++;

		if (test.GetInFlow() == 1 && test.GetOutFlow() == 1 && (tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 0)
		{
			UpdataCandidateSet(tstream.GetDataStreamBegin());
		}
		if (nowObjNum >= 1.2 * objNum)
		{	
			DeleteOverDueObj(tstream, test, nowObjNum);
			UpdateTree(tstream, test);
			nowObjNum = test.GetWindowSize() / test.GetDimension();
		}

		for (int i = newObj; i < tstream.GetDataStreamTag(); i++)
		{
			queryRadius = 0;
			neighbor = -1;	
			tagNode = TreeNodeInsert(tstream, test, i);	
			queryRadius = GetInitRadius(tstream, test, tagNode, i, neighbor, nowObjNum);
			FindNeighbor(tstream, test, i, neighbor, queryRadius, tstream.GetDataStreamBegin(), nowObjNum,tagNode);
			
			if (neighbor != -1)
				InsertMapCandidateSet(i, neighbor, queryRadius);
			tagNode = NULL;
		}
		newObj = tstream.GetDataStreamTag();
	}

}

void Tree::UpdateTree(TStream& tstream, Test& test) {

	UpdateNodeObjNum(tstream, test);
	list<TreeNode*> postTree;
	queue<TreeNode*> queNode;
	queNode.push(root);
	TreeNode *node,*temp=NULL;
	static int num = 0;
	while (!queNode.empty())
	{
		if (queNode.front()->lstPointer.size() == 0)
		{
			if (queNode.front()->vecObject.size() == 0)
			{
				temp = queNode.front();
				queNode.front()->fatherNode->lstPointer.remove(queNode.front());
				delete temp;
				temp = NULL;
			}
		}
		else {
			if (queNode.front()->childNodeObjNum == 0) {
				queNode.front()->fatherNode->lstPointer.remove(queNode.front());
				destorySubTree(queNode.front());
			}
			else {
				for (auto iter = queNode.front()->lstPointer.begin(); iter != queNode.front()->lstPointer.end(); iter++) {
					queNode.push(*iter);
				}	
			}
		}
		queNode.pop();
		
	}
	postTree.push_back(root);
	while (!postTree.empty())
	{
		node = postTree.front();
		postTree.pop_front();
		if (node->fatherNode != nullptr)
		{
			if (node->childNodeObjNum > 0.75 * node->fatherNode->childNodeObjNum && node->fatherNode->childNodeObjNum > NUM && node->childNodeObjNum != node->fatherNode->childNodeObjNum&& node->lstPointer.size()!=0)
			{
				
				Restructure(tstream, test, node);
			}
			
			if (node->lstPointer.size() > 2 * pow(2, test.GetDimension())) {
				MergeTree(tstream,test,node);
				
			}
		}
		if(node->lstPointer.size()!=0)
			for (auto iter = node->lstPointer.begin(); iter != node->lstPointer.end(); iter++) {
				postTree.push_back(*iter);
			}
	}
}

void Tree::destorySubTree(TreeNode* node)
{
	queue<TreeNode*> queNode;
	list<TreeNode*> lists;
	TreeNode* temp = NULL;
	queNode.push(node);
	while (!queNode.empty()) {
		lists.push_back(queNode.front());
		for (auto iter = queNode.front()->lstPointer.begin(); iter != queNode.front()->lstPointer.end(); iter++)
		{
			queNode.push(*iter);
		}
		queNode.pop();
	}
	for (auto iter = lists.begin(); iter != lists.end(); iter++) {
		temp = *iter;
		delete temp;
		temp = NULL;
	}
	lists.clear();
}

void Tree::Prune(TStream& tstream, Test& test, TreeNode* node, int objId, double radius, queue<TreeNode*>& queResultLevelOrder)
{
	for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
	{
		double distance = 0;
		distance = GetDistanceBrothers(tstream, test, *iterLstPointer, objId);
		if (distance <= radius)
		{
			queResultLevelOrder.push(*iterLstPointer);
		}
	}
}

bool Tree::IsCover(TStream& tstream, Test& test, TreeNode* node, int objId)
{
	for (int i = 0; i < test.GetDimension(); i++)
	{
		double  temp = tstream.GetDataStream(objId * test.GetDimension() + i);
		if (tstream.GetDataStream(objId * test.GetDimension() + i) >= node->vecLeftDown[i] && tstream.GetDataStream(objId * test.GetDimension() + i) < node->vecRightUp[i])
		{
			continue;
		}
		else
		{
			return false;
		}
	}
	return true;

}

double Tree::GetDistanceBrothers(TStream& tstream, Test& test, TreeNode* node, int objId)
{
	double result = 0;
	for (int i = 0; i < test.GetDimension(); i++)
	{
		double temp, temp1, temp2;
		temp = tstream.GetDataStream(objId * test.GetDimension() + i);
		temp1 = node->vecLeftDown[i];
		temp2 = node->vecLeftDown[i] + node->sideLength;
		if (temp < temp1)
		{
			result += pow(abs(temp - temp1), 2);
		}
		else if (temp > temp2)
		{
			result += pow(abs(temp2 - temp), 2);
		}
	}
	result = sqrt(result);
	return result;
}

double Tree::GetDistance(TStream& tstream, Test& test, int objId1, int objId2)
{
	double result = 0;
	for (int i = 0; i < test.GetDimension(); i++)
	{
		result += pow(tstream.GetDataStream(objId1 * test.GetDimension() + i) - tstream.GetDataStream(objId2 * test.GetDimension() + i), 2);
	}
	return  sqrt(result);

}

double Tree::GetMaxDifference(TStream& tstream, Test& test, int objId1, int objId2)
{
	double maxDifference = -1;
	for (int i = 0; i < test.GetDimension(); i++)
	{
		if (fabs(tstream.GetDataStream(objId1 * test.GetDimension() + i) - tstream.GetDataStream(objId2 * test.GetDimension() + i)) > maxDifference)
		{
			maxDifference = tstream.GetDataStream(objId1 * test.GetDimension() + i) - tstream.GetDataStream(objId2 * test.GetDimension() + i);
		}
	}
	return maxDifference;
}

Tree::TreeNode* Tree::TreeNodeInsert(TStream& tstream, Test& test, int objId)
{
	
	queue<TreeNode*> queNode;
	TreeNode* node=NULL;
	queNode.push(root);
	while (!queNode.empty()) {
		if (queNode.front()->lstPointer.size() == 0) {
			queNode.front()->vecObject.push_back(objId);
			if(queNode.front()->vecObject.size()>2.5*NUM&& queNode.front()->sideLength > tstream.GetLength() / 1024 / 1024 / 1024)
				TreeNodeSplit(tstream, test, queNode.front());
			node = FindNode(tstream, test, queNode.front(), objId);
			break;
		}
		else if(!QueryField(tstream,test,queNode.front(),objId,queNode)){
			InsertLeaf(tstream, test, queNode.front(), objId);
			node = queNode.front()->lstPointer.back();
			break;
		}
		queNode.pop();
	}
	return node;
}

bool Tree::QueryField(TStream& tstream, Test& test, TreeNode* node, int objId, queue<TreeNode*>& queNode)
{
	for (auto iter = node->lstPointer.begin(); iter != node->lstPointer.end(); iter++) {
		if (IsCover(tstream, test, *iter, objId))
		{
			queNode.push(*iter);
			return true;
		}
	}
	return false;
}

void Tree::InsertLeaf(TStream& tstream, Test& test, TreeNode* node, int objId)
{
	long addr;
	addr = Findaddr(tstream, objId, test.GetDimension(), node->vecLeftDown, node->sideLength / 2);
	CreateTreeNode(tstream, test, node, objId, addr, node->height, node->sideLength);
}

Tree::TreeNode* Tree::FindNode(TStream& tstream, Test& test, TreeNode* node, int objId)
{
	if (node->lstPointer.size() == 0)
		return node;
	for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
	{
		if (IsCover(tstream, test, *iterLstPointer, objId))
		{
			return *iterLstPointer;
		}
	}
}

void Tree::UpdataCandidateSet(int tstreamBegin)
{
	for (auto iterMapCandidateSet = mapCandidateSet.begin(); iterMapCandidateSet != mapCandidateSet.end(); )
	{
		if (iterMapCandidateSet->second.neighborId < tstreamBegin || iterMapCandidateSet->second.objId < tstreamBegin)
		{
			mapCandidateSet.erase(iterMapCandidateSet++);
		}
		else
		{
			iterMapCandidateSet++;
		}
	}
}


