#pragma once
#include <vector>
#include <list>
#include <queue>
#include <map>
#include <cassert>
#include <math.h>
#include <algorithm>
#include "TStream.h"
#include "Test.h"
using namespace std;
class Tree
{
public:
	Tree();

	~Tree();

	struct TreeNode
	{
		int NodeID = 0;
		long addr = 0;
		list<int> vecObject;
		list<TreeNode*> lstPointer;
		TreeNode* fatherNode;
		vector<double> vecLeftDown;
		vector<double> vecRightUp;
		vector<double> vecSide;
		double sideLength;
		int height;
		int flag = 0;
		int fatherNodeObjNum = 0;
		long childNodeObjNum = 0;
	};
	struct Pair
	{
		int objId;
		int neighborId;
	};
	int GetID();
	void AddID(int add);
	void FindNeighbor(TStream& tstream, Test& test, int objId, int& neighbor, double& radius, int tstreamBegin, int& objNum,TreeNode* node);
	bool GetdisNode(TStream& tstream, Test& test, int objId,TreeNode* node,double radius);
	void InsertMapCandidateSet(int objId, int neighbor, double distance);
	long Findaddr(TStream& tstream, int objNo, int d, vector<double>& vecLeftDown, double side);
	void CreateTree(TStream& tstream, Test& test);
	void CreateTreeNode(TStream& tstream, Test& test, TreeNode* node, int objNo, int addr, int height, int sideLenght);
	TreeNode* NewCreateTreeNode(TreeNode* node, int sideLenght);
	TreeNode* InitCreateTreeNode(TreeNode* node, int sideLenght);
	void RootInit(TStream& tstream, Test& test);
	void UpdateTree(TStream& tstream, Test& test);
	void destorySubTree(TreeNode* node);
	int GetObjNumber(TStream& tstream, Test& test, TreeNode* node);
	void TreeNodeSplit(TStream& tstream, Test& test, TreeNode* node);
	void NewTreeNodeSplit(TStream& tstream, Test& test, TreeNode* node);
	bool CreatNewTree(TStream& tstream, Test& test, TreeNode* node);
	void InitRootTree(TStream& tstream, Test& test, TreeNode* node);
	void GetMedian(TStream& tstream, Test& test,TreeNode* node, vector<double>& objCoordinate,  vector<double>& result);
	double GetNewSide(TStream& tstream, Test& test, TreeNode* node, vector<double> medianCoordinate);
	int GetDecimalPlaces(double num);
	void UpdateTreeNodeSplit(TStream& tstream, Test& test, TreeNode* node);
	void TreeNodePushBack(TStream& tstream, Test& test, int objNo, long addr, TreeNode* node);
	void SetTreeNodeCoordinate(TStream& tstream, TreeNode* node, int objNo,int d, vector<double>& vecLeftDown, vector<double>& vecRightUp,double side);
	void PreOrderTree(TStream& tstream, Test& test);
	double GetInitRadius(TStream& tstream, Test& test, TreeNode* node, int objId, int& neighbor, int& objNum);
	void UpdateDataFlow(TStream& tstream, Test& test,double &time);
	void Prune(TStream& tstream, Test& test, TreeNode* node, int objId, double radius, queue<TreeNode*>& queResultLevelOrder);
	bool IsCover(TStream& tstream, Test& test, TreeNode* node, int objId);
	double GetDistanceBrothers(TStream& tstream, Test& test, TreeNode* node, int objId);
	double GetDistance(TStream& tstream, Test& test, int objId1, int objId2);
	double GetMaxDifference(TStream& tstream, Test& test, int objId1, int objId2);

	TreeNode* TreeNodeInsert(TStream& tstream, Test& test, int objId);
	bool QueryField(TStream& tstream, Test& test, TreeNode* node, int objId, queue<TreeNode*>& queNode);
	void InsertLeaf(TStream& tstream, Test& test, TreeNode* node, int objId);
	TreeNode* FindNode(TStream& tstream, Test& test, TreeNode* node, int objId);
	void UpdataCandidateSet(int tstreamBegin);
	double GetMedian(TStream& tstream, Test& test, TreeNode* node, vector<double>& objCoordinate);
	void GetNodeNum(TStream& tstream, Test& test,long& num);

	void DeleteOverDueObj(TStream& tstream, Test& test, int& objNum);
	void UpdateNodeObjNum(TStream& tstream, Test& test);
	void Restructure(TStream& tstream, Test& test,TreeNode* node);
	void MergeTree(TStream& tstream, Test& test, TreeNode* node);
	void UpdateTreeNode(TStream& tstream, Test& test, TreeNode* node);
	void initSubTree(TStream& tstream, Test& test, TreeNode* node);
	void GetPoint(TStream& tstream, TreeNode* node, list<int>& lists,list<TreeNode*> &postTree);
	bool IsCover(TStream& tstream, Test& test, TreeNode* node1, TreeNode* node2);
	void PrintMapSet(Test& test, int datasBegin);
private:
	int ID=0;
	TreeNode* root;
	map<double, Pair> mapCandidateSet;

};

