#include "Test.h"
#include "TStream.h"
#include "Tree.h"
#include<iostream>
#include<fstream>
using namespace std;

int main()
{
	clock_t startTime, endTime, treetime;
	double inittime = 0, createtreetime = 0;
	for (int j = 0; j < 5; j++) {
		Test test;
		TStream tstream;
		vector<Test> vecTestFile;
		test.Init(vecTestFile,j);
		tstream.Init(vecTestFile[0],j);
		for (int i = 0; i < vecTestFile.size(); i++)
		{
			double time = 0;
			Tree tree;
			tstream.SetDataStreamBegin(0);
			tstream.SetDataStreamTag(vecTestFile[i].GetWindowSize() / vecTestFile[i].GetDimension());
			startTime = clock();
			tree.CreateTree(tstream, vecTestFile[i]);
			treetime = clock();
			createtreetime = (double)(treetime - startTime) / CLOCKS_PER_SEC;
			tree.PreOrderTree(tstream, vecTestFile[i]);
			endTime = clock();
			inittime = (double)(endTime - startTime) / CLOCKS_PER_SEC;
			cout << "Init Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;

			startTime = clock();
			tree.UpdateDataFlow(tstream, vecTestFile[i], time);
			endTime = clock();
			cout << "Running Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC - time << "s" << endl;
			cout << "Process " << 52428800 / ((double)(endTime - startTime) / CLOCKS_PER_SEC) << " data per second " << endl;
		}
	}
	
	system("pause");
}