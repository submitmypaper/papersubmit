#pragma once
#include "Test.h"
#include "TStream.h"
#include<map>
#pragma warning(disable:4996)

using namespace std;
class Index
{
	struct Pair
	{
		int order;
		int neighbor;
	};
			
public:
	void Init(TStream& tstream, Test& test);
	void FindNeighbor(TStream& tstream, Test& test, map<double, int>& WidestDimensionMap,int d,int max);
	double getdistance(TStream& tstream, Test& test,int id1,int id2);
	void InsertMap(int id,int neighbor,double distance);
	void UpdataTStream(TStream& tstream, Test& test);
	void updataMapSet(int dataBegin);
	void updataWidestDimensionMap(int dataBegin);
	void PrintMapSet(Test& test, int dataBegin);
private:
	map<double, Pair> MapSet;
	map<double, int> WidestDimensionMap;
};