#include "Index.h"

void Index::Init(TStream& tstream, Test& test)
{
	double step = 0.000001;
	int max_d = tstream.MaxDimension(test);
	for (int i = 0; i < test.GetWindowSize() / test.GetDimension(); i++) {
		std::pair<std::map<double, int>::iterator, bool> ret;
		ret = WidestDimensionMap.insert(make_pair(tstream.GetDataStream(i * test.GetDimension()+max_d), i));
		while (!ret.second)
		{
			ret = WidestDimensionMap.insert(make_pair(tstream.GetDataStream(i * test.GetDimension()+max_d) + step, i));
			step += 0.000001;
		}
	}
	double max = 0;
	for (int i = 0; i < 5; i++)
	{
		double min = 0x3f3f3f3f;
		int R = -1;
		for (int j = i + 1; j < test.GetWindowSize() / test.GetDimension(); j++)
		{
			float distance = 0;
			for (int w = 0; w < test.GetDimension(); w++)
			{
				distance += pow(tstream.GetDataStream(i * test.GetDimension() + w) - tstream.GetDataStream(j * test.GetDimension() + w), 2);
			}
			distance = sqrt(distance);
			if (distance <= min && distance != 0)
			{
				min = distance;
				R = j;
			}
		}
		if (min > max)
			max = min;
	}
	FindNeighbor(tstream, test, WidestDimensionMap, max_d, max);

}

void Index::FindNeighbor(TStream& tstream, Test& test, map<double, int>& WidestDimensionMap,int d,int max)
{
	for (auto iter = WidestDimensionMap.begin(); iter != WidestDimensionMap.end(); iter++) {
		auto fast_iter = iter; 
		auto last_iter = iter;
		double min = 0x3f3f3f3f;
		int neighbor = -1;
		while (iter->first - fast_iter->first < max) {
			int flag = 0;
			if (fast_iter == WidestDimensionMap.begin()) {
				for (int i = d + 1; i != d; i = (i + 1) % test.GetDimension()) {
					if (fabs(tstream.GetDataStream(iter->second * test.GetDimension() + i) - tstream.GetDataStream(fast_iter->second * test.GetDimension() + i)) > max) {
						flag = -1;
						break;
					}
				}
				if (flag == -1)
					break;
				double dis = getdistance(tstream, test, iter->second, fast_iter->second);
				if (dis < min && dis != 0) {
					min = dis;
					neighbor = fast_iter->second;
				}	
				break;
			}
			for (int i = d + 1; i != d; i = (i + 1) % test.GetDimension()) {
				if (fabs(tstream.GetDataStream(iter->second * test.GetDimension() + i) - tstream.GetDataStream(fast_iter->second * test.GetDimension() + i)) > max) {
					flag = -1;
				}
			}
			if (flag == -1) {
				fast_iter--;
				continue;
			}
			double dis = getdistance(tstream, test, iter->second, fast_iter->second);
			if (dis < min && dis != 0) {
				min = dis;
				neighbor = fast_iter->second;
			}
			fast_iter--;
		}
		
		while (last_iter->first - iter->first < max) {
			int flag = 0;
			if (last_iter == WidestDimensionMap.end()) {
				for (int i = d + 1; i != d; i = (i + 1) % test.GetDimension()) {
					if (fabs(tstream.GetDataStream(iter->second * test.GetDimension() + i) - tstream.GetDataStream(last_iter->second * test.GetDimension() + i)) > max) {
						flag = -1;
						break;
					}
				}
				if (flag == -1)
					break;
				double dis = getdistance(tstream, test, iter->second, last_iter->second);
				if (dis < min && dis != 0) {
					min = dis;
					neighbor = last_iter->second;
				}
				break;
			}
			for (int i = d + 1; i != d; i = (i + 1) % test.GetDimension()) {
				if (fabs(tstream.GetDataStream(iter->second * test.GetDimension() + i) - tstream.GetDataStream(last_iter->second * test.GetDimension() + i)) > max) {
					flag = -1;
				}
			}
			if (flag == -1) {
				last_iter++;
				continue;
			}
			double dis = getdistance(tstream, test, iter->second, last_iter->second);
			if (dis < min && dis != 0) {
				min = dis;
				neighbor = last_iter->second;
			}
			last_iter++;
		}
		if (neighbor != -1) {
			InsertMap(iter->second, neighbor, min);
		}
	}
}

double Index::getdistance(TStream& tstream, Test& test, int id1,int id2)
{
	double dis = 0;
	for (int i = 0; i < test.GetDimension(); i++) {
		dis += pow(tstream.GetDataStream(id1 * test.GetDimension() + i) - tstream.GetDataStream(id2 * test.GetDimension() + i), 2);
	}
	return sqrt(dis);
}
void Index::InsertMap(int id, int neighbor, double distance)
{
	double step = 0.000001;
	Pair p,temp;
	p.order = id;
	p.neighbor = neighbor;
	std::pair<std::map<double, Pair>::iterator, bool> ret;
	ret = MapSet.insert(make_pair(distance, p));
	temp = MapSet[distance];
	while (!ret.second)
	{
		if (temp.neighbor == p.order && temp.order == p.neighbor)
			return;
		ret = MapSet.insert(make_pair(distance + step, p));
		step += 0.000001;
	}
}
	

void Index::UpdataTStream(TStream& tstream, Test& test)
{
	clock_t startTime1, endTime1;
	int max_d = tstream.MaxDimension(test);
	int num = test.GetWindowSize() / test.GetDimension();
	int winsize = test.GetWindowSize() / test.GetDimension();
	
	for (int i = tstream.GetDataStreamTag(); i < 52428800 +winsize; i++) {
		tstream.AddDataStreamTag(1);
		tstream.AddDataStreamBegin(1);
		num++;
		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 1)
		{
			startTime1 = clock();
		}
		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 0&& tstream.GetDataStreamTag()>= 1048576)
		{
			endTime1 = clock();
			cout << "Current cursor:" << tstream.GetDataStreamTag() << "     Time = " << (double)(endTime1 - startTime1) / CLOCKS_PER_SEC << "s" << endl;
		}
		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 102400 == 0) {
			updataMapSet(tstream.GetDataStreamBegin());
		}
		
		if (num >= 1.2 * test.GetWindowSize() / test.GetDimension()) {
			updataWidestDimensionMap(tstream.GetDataStreamBegin());
			num = test.GetWindowSize() / test.GetDimension();
		}
		double step = 0.000001;
		std::pair<std::map<double, int>::iterator, bool> ret;
		ret = WidestDimensionMap.insert(make_pair(tstream.GetDataStream(i * test.GetDimension() + max_d), i));
		while (!ret.second)
		{
			ret = WidestDimensionMap.insert(make_pair(tstream.GetDataStream(i * test.GetDimension() + max_d) + step, i));
			step += 0.000001;
		}
		
		double max = MapSet.rbegin()->first;
		
		double key = tstream.GetDataStream(i * test.GetDimension() + max_d)+step-0.000001;
		auto iter = WidestDimensionMap.lower_bound(key);
		auto fast_iter = WidestDimensionMap.lower_bound(key);
		auto last_iter = WidestDimensionMap.upper_bound(key);
		double min = max;
		int neighbor = -1;

		while (iter->first - fast_iter->first < max) {
			int flag = 0;
			if (fast_iter == WidestDimensionMap.begin()) {
				for (int i = max_d + 1; i != max_d; i = (i + 1) % test.GetDimension()) {
					if (fabs(tstream.GetDataStream(iter->second * test.GetDimension() + i) - tstream.GetDataStream(fast_iter->second * test.GetDimension() + i)) > max) {
						flag = -1;
						break;
					}
				}
				if (flag == -1)
					break;
				double dis = getdistance(tstream, test, iter->second, fast_iter->second);
				if (dis < min && dis != 0) {
					min = dis;
					neighbor = fast_iter->second;
				}
				break;
			}
			for (int i = max_d + 1; i != max_d; i = (i + 1) % test.GetDimension()) {
				if (fabs(tstream.GetDataStream(iter->second * test.GetDimension() + i) - tstream.GetDataStream(fast_iter->second * test.GetDimension() + i)) > max) {
					flag = -1;
				}
			}
			if (flag == -1) {
				fast_iter--;
				continue;
			}
			double dis = getdistance(tstream, test, iter->second, fast_iter->second);
			if (dis < min && dis != 0) {
				min = dis;
				neighbor = fast_iter->second;
			}
			fast_iter--;
		}

		while (last_iter->first - iter->first < max) {
			int flag = 0;
			if (last_iter == WidestDimensionMap.end()) {
				for (int i = max_d + 1; i != max_d; i = (i + 1) % test.GetDimension()) {
					if (fabs(tstream.GetDataStream(iter->second * test.GetDimension() + i) - tstream.GetDataStream(last_iter->second * test.GetDimension() + i)) > max) {
						flag = -1;
						break;
					}
				}
				if (flag == -1)
					break;
				double dis = getdistance(tstream, test, iter->second, last_iter->second);
				if (dis < min && dis != 0) {
					min = dis;
					neighbor = last_iter->second;
				}
				break;
			}
			for (int i = max_d + 1; i != max_d; i = (i + 1) % test.GetDimension()) {
				if (fabs(tstream.GetDataStream(iter->second * test.GetDimension() + i) - tstream.GetDataStream(last_iter->second * test.GetDimension() + i)) > max) {
					flag = -1;
				}
			}
			if (flag == -1) {
				last_iter++;
				continue;
			}
			double dis = getdistance(tstream, test, iter->second, last_iter->second);
			if (dis < min && dis != 0) {
				min = dis;
				neighbor = last_iter->second;
			}
			last_iter++;
		}
		if (neighbor != -1) {
			InsertMap(iter->second, neighbor, min);
		}
	}
}

void Index::updataMapSet(int dataBegin)
{
	for (auto iter = MapSet.begin(); iter != MapSet.end(); ) {
		if (iter->second.order < dataBegin || iter->second.neighbor < dataBegin) {
			MapSet.erase(iter++);
		}
		else iter++;
	}
}

void Index::updataWidestDimensionMap(int dataBegin)
{
	for (auto iter = WidestDimensionMap.begin(); iter != WidestDimensionMap.end(); ) {
		if (iter->second < dataBegin ) {
			WidestDimensionMap.erase(iter++);
		}
		else iter++;
	}

}

void Index::PrintMapSet(Test& test, int dataBegin)
{
	int k = 0;
	for (auto iter = MapSet.begin(); iter != MapSet.end(); iter++)
	{

		if (k == test.GetTopK())
			break;
		if (iter->second.order < dataBegin || iter->second.neighbor < dataBegin)
		{
			continue;
		}
		k++;
		cout << "The nearest neighbor of " << iter->second.order << " is " << iter->second.neighbor << "distance:" << iter->first << endl;
	}
}


