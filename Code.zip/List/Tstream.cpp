#include "TStream.h"
#include <string>
#pragma warning(disable:4996)
TStream::TStream()
{
}

TStream::~TStream()
{
}
void TStream::ReadDataFile(int j)
{
	FILE* fp1;
	double dlNumber;
	double maxData = 0;
	double step = 0.05;
	int objectNumber = 0;
	string a = to_string(j);
	string s = "SourceFile" + a + ".txt";
	if ((fp1 = fopen(s.data(), "r")) != NULL)
	{
		while (fscanf(fp1, "%lf", &dlNumber) != EOF)
		{
			if (maxData < dlNumber)
				maxData = dlNumber;
			vecDataStream.push_back(dlNumber);
		}
	}
	length = maxData;
	length = pow(2, ceil(log2(length)));
}
double TStream::GetDataStream(int intObjectNumber)
{
	return vecDataStream[intObjectNumber];
}

int TStream::GetDataStreamLength()
{
	return vecDataStream.size();
}
void TStream::setRange(Test& test)
{
	int objnum = GetDataStreamLength() / test.GetDimension();
	for (int i = 0; i < objnum; i++) {
		for (int j = 0; j < test.GetDimension(); j++) {
			if (i == 0) {
				dimensionMax.push_back(vecDataStream[j]);
				dimensionMin.push_back(vecDataStream[j]);
			}
			else {
				if (dimensionMax[j] < vecDataStream[i * test.GetDimension() + j])
					dimensionMax[j] = vecDataStream[i * test.GetDimension() + j];
				if (dimensionMin[j] > vecDataStream[i * test.GetDimension() + j])
					dimensionMin[j] = vecDataStream[i * test.GetDimension() + j];
			}
		}
	}
}

int TStream::MaxDimension(Test& test)
{
	int max = -1;
	int d=0;
	for (int i = 0; i < test.GetDimension(); i++) {
		if (dimensionMax[i] - dimensionMin[i] > max) {
			max = dimensionMax[i] - dimensionMin[i];
			d = i;
		}
	}
	return d;
}


double TStream::GetLength()
{
	return length;
}

int TStream::GetDataStreamBegin()
{
	return dataStreamBegin;
}

int TStream::GetDataStreamTag()
{
	return dataStreamTag;
}

void TStream::SetDataStreamBegin(int begin)
{
	dataStreamBegin = begin;
}

void TStream::SetDataStreamTag(int tag)
{
	dataStreamTag = tag;
}

void TStream::Init(int j)
{
	ReadDataFile(j);
	
}

void TStream::AddDataStreamBegin(int outflow)
{
	dataStreamBegin += outflow;
}

void TStream::AddDataStreamTag(int inflow)
{
	dataStreamTag += inflow;
}
