#include<iostream>
#include"Test.h"
#include"Tstream.h"
#include "Index.h"
#pragma warning(disable:4996)
using namespace std;

int main() {
	clock_t starttime, endtime;
	for (int j = 0; j < 5; j++) {
	
		TStream tstream;
		Test test;
		vector<Test> vecTestFile;
		test.Init(vecTestFile,j);
		tstream.ReadDataFile(j);
		tstream.setRange(vecTestFile[0]);

		for (int i = 0; i < vecTestFile.size(); i++) {
			Index index;
			tstream.SetDataStreamTag(vecTestFile[i].GetWindowSize() / vecTestFile[i].GetDimension());
			tstream.SetDataStreamBegin(0);
			starttime = clock();
			index.Init(tstream, vecTestFile[i]);
			endtime = clock();
			cout << "Init Time = " << (float)(endtime - starttime) / CLOCKS_PER_SEC << "s" << endl;


			starttime = clock();
			index.UpdataTStream(tstream, vecTestFile[i]);
			endtime = clock();
			cout << "Running Time = " << (float)(endtime - starttime) / CLOCKS_PER_SEC << "s" << endl;
			cout << "Process " << 52428800 / ((double)(endtime - starttime) / CLOCKS_PER_SEC) << " data per second " << endl;
		}
	}
	
	

}