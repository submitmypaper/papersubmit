#pragma once
#include "TStream.h"
#include "Cell.h"
#include "Index.h"

//�õ�index.cpp��д��
Index::Hash Findaddr1(TStream tstream,int d,Cube vecs1,vector<float> min,int n, float len, Index::Hash temp);
long Findaddr2(TStream tstream,int order, int d,vector<float> &vecLeftCoordinate ,vector<float> min, float len,int n);
long Findaddr3(TStream tstream, int order, int d, vector<float> vecLeftCoordinate, float len, int n);
void FindPointIndex(int d,int v[][24],int n, vector<long> &pointIndex,long index,int addr);
Index::HashIndex Findaddr4(TStream tstream, int d,int order , vector<float> min, int n, float len, Index::HashIndex temp);