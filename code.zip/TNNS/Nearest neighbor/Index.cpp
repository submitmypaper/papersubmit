#include "Index.h"
#include <cmath>
#include <iostream>
#include <map>
#include <unordered_map>
#include <vector>
#include "Grid.h"
#include "TStream.h"


using namespace std;
Index::Index()
{
}


Index::~Index()
{
}

void Index::SetNF(int f)
{
	NF = f;
}

void Index::SetTIME(int time)
{
	TIME = time;
}

int Index::getHashKey(int addr, int hashBucketSize)
{
	addr = addr / 5;
	addr = addr % hashBucketSize;
	return addr;
}

long Index::Findaddr(TStream& tstream, int order, int d, vector<double>& vecLeftCoordinate, vector<double>& min, double len, int n)
{
	long addr = 0;
	for (int w = 0; w < d; w++)
	{
		long temp = ((tstream.getData(order * d + w) - min[w]) / len);
		vecLeftCoordinate[w] = temp * len;
		addr = (addr << n) | temp;
	}
	return addr;
}

long Index::Findaddr(TStream& tstream, int order, int d, vector<double>& vecLeftCoordinate, double len, int n)
{
	long addr = 0;
	for (int k1 = 0; k1 < d; k1++)
	{

		int temp = (tstream.getData(order * d + k1) - vecLeftCoordinate[k1]) / (len);
		addr = (addr << n) | temp;
	}
	return addr;
}

void Index::FindPointIndex(int d, int v[][24], int n, vector<long>& pointIndex, long index, int addr)
{
	pointIndex.clear();
	for (int z1 = 0; z1 < pow(2, d); z1++)
	{
		long t = index;
		for (int z2 = 0; z2 < d; z2++)
		{

			long temp = v[addr][z1 * d + z2];
			temp = (temp << n * (d - z2 - 1));
			t = t + temp;
		}
		if (t >= 0)
		{
			pointIndex.push_back(t);
		}

	}
}


void Index::SetHashbucket(Test test, long addr, vector<list<HashTable>>& Hashbucket, int order)
{
	int flag;
	int t = getHashKey(addr, Hashbucket.size());
	if (Hashbucket[t].size() == 0)
	{
		HashTable x;
		Hashbucket[t].push_back(x);
		Hashbucket[t].front().addr = addr;
		Hashbucket[t].front().order.push_back(order);
	}
	else
	{
		flag = 0;

		for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
		{
			if (addr == iter->addr)
			{
				iter->order.push_back(order);
				flag = 1;
				break;
			}
		}
		if (flag == 0)
		{
			HashTable x;
			x.addr = addr;
			x.order.push_back(order);
			Hashbucket[t].push_back(x);
		}
	}
}

void Index::SetHashbucket(Test test, long addr, vector<list<HashTable>>& Hashbucket)
{
	int flag;
	int t = getHashKey(addr, Hashbucket.size());
	if (Hashbucket[t].size() == 0)
	{
		HashTable x;
		Hashbucket[t].push_back(x);
		Hashbucket[t].front().addr = addr;
		Hashbucket[t].front().order.push_back(-1);
		Hashbucket[t].front().pointNum++;
	}
	else
	{
		flag = 0;

		for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
		{
			if (addr == iter->addr)
			{
				iter->pointNum++;
				flag = 1;
				break;
			}
		}
		if (flag == 0)
		{
			HashTable x;
			x.addr = addr;
			x.order.push_back(-1);
			x.pointNum++;
			Hashbucket[t].push_back(x);
		}
	}
}

void Index::SetHashbucket_Reduce(Test test, long addr, vector<list<HashTable>>& Hashbucket)
{
	int t = getHashKey(addr, Hashbucket.size());
	for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
	{
		if (addr == iter->addr)
		{
			if (iter->pointNum == 0)
				return;
			iter->pointNum--;
			if (iter->pointNum == 0 && iter->order.front() == -1 && iter->order.size() == 1)
			{
				Hashbucket[t].erase(iter);
			}
			break;
		}
	}
}

void Index::GetPoint(Hash& vecHash, vector<int>& point, TStream& tstream)
{
	point.reserve(vecHash.HashBucket.size() / 2);
	for (auto iter2 = vecHash.HashBucket.begin(); iter2 != vecHash.HashBucket.end(); iter2++)
	{
		if (iter2->size() == 0)
		{
			continue;
		}
		for (auto iter1 = iter2->begin(); iter1 != iter2->end(); iter1++)
		{
			for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
			{
				if (*iter < 0 || *iter < tstream.vecData_begin)
					continue;
				point.push_back(*iter);
			}
		}
	}
}

void Index::HandelPointNeighbor(TStream& tstream, Test test, int& tag1, int& tag2)
{
	double mid = 0;
	Hash temp;
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	long addr = 0;
	nth_element(tstream.pointNeighbor.begin(), tstream.pointNeighbor.begin() + tag1 / 2, tstream.pointNeighbor.begin() + tag1);
	mid = tstream.pointNeighbor[tag1 / 2].distance;

	mid = pow(2, floor(log2(mid)));


	fprintf(fp2, "��ʼ��pointNeighbor�Ĵ�СΪ   %d   ������λ��Ϊ   %lf   \n", (int)tstream.pointNeighbor.size(), mid);


	int n = ceil(log2(tstream.getLength() / (mid)));
	Hashbucket.clear();
	Hashbucket.resize(tag1 * 1.5);


	if (tag1 <= test.GetK())
	{
		for (int i = 0; i < tag1; i++)
		{
			addr = Findaddr(tstream, tstream.pointNeighbor[i].order, test.GetD(), dimensionMin, mid, n);
			if (addr < 0)
			{
				continue;
			}
			SetHashbucket(test, addr, Hashbucket, tstream.pointNeighbor[i].order);
		}
		fprintf(fp2, "�߳�Ϊ   %lf   �Ĺ�ϣͰ��   %d   ����\n", mid, tag1);
	}
	else
	{
		for (int i = 0; i < tag1; i++)
		{
			if (tstream.pointNeighbor[i].distance >= mid)
			{
				tag2++;
				addr = Findaddr(tstream, tstream.pointNeighbor[i].order, test.GetD(), dimensionMin, mid, n);
				if (addr < 0)
				{
					continue;
				}
				SetHashbucket(test, addr, Hashbucket, tstream.pointNeighbor[i].order);
			}
		}
		fprintf(fp2, "�߳�Ϊ   %lf   �Ĺ�ϣͰ��   %d   ����\n", mid, tag2);
	}

	nth_element(tstream.pointNeighbor.begin(), tstream.pointNeighbor.begin() + tag1 - tag2, tstream.pointNeighbor.begin() + tag1);


	temp.HashBucket = Hashbucket;
	temp.side = mid;
	vecHashIndex.push_back(temp);
	Hashbucket = {};
	temp = {};
}

void Index::HandelPointIndex(TStream& tstream, Test test, vector<long>& pointIndex, long addr, Hash& h, int order)
{
	for (int h1 = 0; h1 < pointIndex.size(); h1++)
	{
		addr = getHashKey(pointIndex[h1], h.HashBucket.size());
		if (h.HashBucket[addr].size() == 0)
		{
			continue;
		}
		for (auto iter1 = h.HashBucket[addr].begin(); iter1 != h.HashBucket[addr].end(); iter1++)
		{
			if (pointIndex[h1] == iter1->addr)
			{
				for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
				{
					if (*iter == order)
					{
						continue;
					}

					double distance = 0;
					for (int w = 0; w < test.GetD(); w++)
					{
						distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
					}
					distance = sqrt(distance);
					if (distance <= h.side && order != *iter && distance != 0)
					{
						if (tstream.pointNeighbor[*iter].distance > distance)
						{
							tstream.pointNeighbor[*iter].neighbor = order;
							tstream.pointNeighbor[*iter].distance = distance;
						}

						if (tstream.pointNeighbor[order].distance > distance)
						{
							tstream.pointNeighbor[order].neighbor = *iter;
							tstream.pointNeighbor[order].distance = distance;
						}
					}
				}
			}
		}
	}
}

void Index::HandelPointIndex_Updata(TStream& tstream, Test test, vector<long>& pointIndex, long addr, Hash& h, int order, double& distance, int& flag)
{
	long R = -1;
	double min = 0x3f3f3f3f;

	vector<double> dimensionMin = tstream.getLeftCoordinate();
	vector<double> vecLeftCoordinate(3);

	for (int h1 = 0; h1 < pointIndex.size(); h1++)
	{
		addr = getHashKey(pointIndex[h1], h.HashBucket.size());
		if (h.HashBucket[addr].size() == 0)
		{
			continue;
		}
		for (auto iter1 = h.HashBucket[addr].begin(); iter1 != h.HashBucket[addr].end(); iter1++)
		{
			if (pointIndex[h1] == iter1->addr)
			{
				if (iter1->pointNum > 0)
				{
					flag = 1;
				}
				for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
				{
					distance = 0;
					if (*iter == -1)
					{
						continue;
					}
					if (*iter < tstream.vecData_begin)
					{
					}
					else
					{
						for (int w = 0; w < test.GetD(); w++)
						{
							distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
						}
						distance = sqrt(distance);
						if (distance < min)
						{
							R = *iter;
							min = distance;
						}
					}
				}

			}
		}
	}

	if (R == -1)
	{
		min = h.side;
	}
	distance = min;

}

void Index::HandelMap(TStream& tstream, Test test, vector<long>& pointIndex, long addr, Hash& h, int order)
{
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	vector<double> vecLeftCoordinate(3);
	long index = 0;
	double distance = 0;
	double min = 0x3f3f3f3f;
	int R = -1;
	Point a;
	bool flag;
	for (int h1 = 0; h1 < pointIndex.size(); h1++)
	{
		addr = getHashKey(pointIndex[h1], vecHashIndex.rbegin()->HashBucket.size());
		if (vecHashIndex.rbegin()->HashBucket[addr].size() == 0)
		{
			continue;
		}
		for (auto iter1 = vecHashIndex.rbegin()->HashBucket[addr].begin(); iter1 != vecHashIndex.rbegin()->HashBucket[addr].end(); iter1++)
		{
			if (pointIndex[h1] == iter1->addr)
			{
				for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
				{
					distance = 0;
					if (*iter == order)
					{
						continue;
					}
					for (int w = 0; w < test.GetD(); w++)
					{
						distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
					}
					distance = sqrt(distance);
					if (distance < min)
					{
						R = *iter;
						min = distance;
					}
				}
			}
		}
	}

	if (R != -1)
	{
		flag = 0;
		int i = 0;
		for (auto iter = myMap_dis.begin(); iter != myMap_dis.end(); iter++)
		{
			if (R == iter->second.order && order == iter->second.neighbor)
			{
				return;
			}
			if (iter->first == min)
			{
				min += i * 0.000001;
				a.order = order;
				a.neighbor = R;
				myMap_dis[min] = a;
				return;
			}
			i++;
		}
		a.order = order;
		a.neighbor = R;
		myMap_dis[min] = a;
	}

}



void Index::PushBackHashTable(TStream& tstream, Test test, double up4, int vecS1Length, vector<Cube>& vecS1, vector<double>& dimensionMin)
{
	Hash temp;
	long addr = 0;
	int n = ceil(log2(tstream.getLength() / (up4)));//2Li
	Hashbucket.clear();
	Hashbucket.resize((vecS1.size() - vecS1Length) * 2);

	for (int i = vecS1Length; i < vecS1.size(); i++)
	{
		addr = Findaddr(tstream, vecS1[i].order, test.GetD(), dimensionMin, up4, n);
		if (addr < 0)
		{
			continue;
		}
		SetHashbucket(test, addr, Hashbucket, vecS1[i].order);

	}
	fprintf(fp2, "�߳�Ϊ   %f   �ĵ���   %d   ��\n", up4, (int)(vecS1.size() - vecS1Length));

	temp.HashBucket = Hashbucket;
	temp.side = up4;
	vecHash.push_back(temp);
	Hashbucket = {};
}
void Index::UpdataPushBackHashTable(TStream& tstream, Test test, double up4, int vecS1Length, vector<Cube>& vecS1, vector<double>& dimensionMin)
{
	Hash temp;
	long addr = 0;
	int n = ceil(log2(tstream.getLength() / (up4)));//2Li
	Hashbucket.clear();
	Hashbucket.resize((vecS1.size() - vecS1Length) * 2);
	if (Hashbucket.size() == 0)
	{
		return;
	}
	for (int i = vecS1Length; i < vecS1.size(); i++)
	{
		addr = Findaddr(tstream, vecS1[i].order, test.GetD(), dimensionMin, up4, n);
		if (addr < 0)
		{
			continue;
		}
		SetHashbucket(test, addr, Hashbucket, vecS1[i].order);

	}
	temp.HashBucket = Hashbucket;
	temp.side = up4;
	vecHashIndex.push_back(temp);
	Hashbucket = {};

}

void Index::PushBackHashTable_1(TStream& tstream, Test test, double up4, vector<Cube>& cube, vector<double>& dimensionMin, int tag1)
{
	Hash temp;
	long addr = 0;
	int n = ceil(log2(tstream.getLength() / (up4)));//2Li
	Hashbucket.clear();
	Hashbucket.resize(tag1 * 2);

	for (int i = 0; i < tag1; i++)
	{
		addr = Findaddr(tstream, cube[i].order, test.GetD(), dimensionMin, up4, n);
		if (addr < 0)
		{
			continue;
		}
		SetHashbucket(test, addr, Hashbucket, cube[i].order);

	}
	temp.HashBucket = Hashbucket;
	temp.side = up4;
	vecHash.push_back(temp);
	Hashbucket = {};
}

void Index::UpdataPushBackHashTable_1(TStream& tstream, Test test, double up4, vector<Cube>& cube, vector<double>& dimensionMin, int tag1)
{
	Hash temp;
	long addr = 0;
	int n = ceil(log2(tstream.getLength() / (up4)));//2Li
	Hashbucket.clear();
	Hashbucket.resize(tag1 * 2);

	for (int i = 0; i < tag1; i++)
	{
		addr = Findaddr(tstream, cube[i].order, test.GetD(), dimensionMin, up4, n);
		if (addr < 0)
		{
			continue;
		}
		SetHashbucket(test, addr, Hashbucket, cube[i].order);

	}
	temp.HashBucket = Hashbucket;
	temp.side = up4;
	vecHashIndex.push_back(temp);
	Hashbucket = {};
}


void Index::Init(TStream& tstream, Test test)
{
	double scale;
	vector<double> leftCoordinate(3);
	Grid grid;
	bool flag = 0;
	int pointNum = test.GetWindows() / test.GetD();
	list<struct Cell> vecCellIndex;
	map<long, Cell>myMap;
	Cell t;
	t.index.push_back(0);
	t.leftCoordinate = tstream.getLeftCoordinate();
	t.scale = tstream.getLength();
	myQue.push(t);
	for (int i = 0; i < pointNum; i++)
	{
		myQue.front().points.push_back(i);
	}
	myQue.front().addr = 0;
	while (!myQue.empty())
	{
		pointNum = myQue.front().points.size();
		if (myQue.front().index.size() > 1048576)
		{
			myQue.pop();
			continue;
		}
		scale = myQue.front().scale;
		leftCoordinate = myQue.front().leftCoordinate;
		grid.setGrid(pointNum, leftCoordinate, scale, test);
		int n = ceil(log2(tstream.getLength() / (grid.getLength())));

		if ((myQue.front().points.size() <= 5 && myQue.front().index.size() >= 10) || n >= 20)
		{
			for (auto iter = myQue.front().points.begin(); iter != myQue.front().points.end(); iter++)
			{
				Cube t;
				t.index = myQue.front().index;
				t.order = *iter;
				t.side = myQue.front().scale;
				cube.push_back(t);
			}
			myQue.pop();
			continue;
		}

		for (auto iter = myQue.front().points.begin(); iter != myQue.front().points.end(); iter++)
		{
			int order = *iter;
			long addr = 0;
			Cell_1 c;
			for (int j = 0; j < test.GetD(); j++)
			{
				int temp = (tstream.getData((order * test.GetD()) + j) - grid.getLeftCoordinate(j)) / grid.getLength();
				c.leftCoordinate.push_back(temp * grid.getLength() + myQue.front().leftCoordinate[j]);
				addr = (addr << n) | temp;
			}
			if (addr < 0)
			{
				continue;
			}
			Cell a;
			a.addr = addr;
			a.leftCoordinate = c.leftCoordinate;
			a.index = myQue.front().index;
			a.points.push_back(order);
			a.scale = grid.getLength();
			std::pair<std::map<long, Cell>::iterator, bool> ret1;
			ret1 = myMap.insert(make_pair(addr, a));
			if (!ret1.second)
			{
				myMap[addr].points.push_back(order);
			}

		}

		for (auto iter = myMap.begin(); iter != myMap.end(); iter++)
		{
			Cube t;
			if (iter->second.points.size() == 1)
			{
				iter->second.index = myQue.front().index;
				iter->second.index.push_back(iter->first);
				t.index = iter->second.index;
				t.order = iter->second.points.front();
				t.side = iter->second.scale;
				cube.push_back(t);
			}
			else if (iter->second.points.size() > 1)
			{
				iter->second.index = myQue.front().index;
				iter->second.index.push_back(iter->first);
				myQue.push(iter->second);
			}
		}
		myQue.pop();
		myMap.clear();
	}
	printf("cube.size��%d", (int)cube.size());
}



void Index::CubeDivide(TStream& tstream, Test test)
{
	fp2 = fopen("log��־cube.txt", "w");
	vector<Cube> vecS1;
	int tag1 = cube.size(), tag2 = 0;
	double up4 = 0;
	Hash temp;
	long addr = 0;
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	while (1)
	{

		nth_element(cube.begin(), cube.begin() + tag1 / 4, cube.begin() + tag1);
		up4 = cube[tag1 / 4].side;
		int tagLength = tag1;
		int  vecS1Length = tag2;
		tag1 = 0;
		for (int i = 0; i < tagLength; i++)
		{
			if (cube[i].side >= up4)
			{
				vecS1.push_back(cube[i]);
				tag2++;
			}
			else if (cube[i].side < up4)
				cube[tag1++] = cube[i];
		}
		PushBackHashTable(tstream, test, up4 * 2, vecS1Length, vecS1, dimensionMin);
		fprintf(fp2, "�������ķ�λ��   %f   ��cube��   %d   ��\n", up4, (int)(vecS1.size() - vecS1Length));
		if (tag1 <= 200)
		{
			fprintf(fp2, "���ķ�λ�����ֵ����һ����   %d   ��cube���߽�ֵС��200��\n", tag1);
			PushBackHashTable_1(tstream, test, up4, cube, dimensionMin, tag1);
			break;

		}
	}
	cout << "/////cubedevide" << endl;
}
void Index::UpdataCubeDivide(TStream& tstream, Test test, int initPointNum)
{
	vector<Cube> vecS1;
	int tag1 = cube.size(), tag2 = 0;
	double up4 = 0;
	Hash temp;
	long addr = 0;
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	if (tag1 == 0)
	{
		return;
	}
	if (tag1 <= initPointNum)
	{
		nth_element(cube.begin(), cube.begin() + tag1 / 4, cube.begin() + tag1);
		up4 = cube[tag1 / 4].side;
		up4 = pow(2, floor(log2(up4)));
		UpdataPushBackHashTable_1(tstream, test, up4, cube, dimensionMin, tag1);
		return;
	}
	while (1)
	{

		nth_element(cube.begin(), cube.begin() + tag1 / 4, cube.begin() + tag1);
		up4 = cube[tag1 / 4].side;
		up4 = pow(2, floor(log2(up4)));


		int tagLength = tag1;
		int  vecS1Length = tag2;
		tag1 = 0;
		for (int i = 0; i < tagLength; i++)
		{
			if (cube[i].side >= up4)
			{
				vecS1.push_back(cube[i]);
				tag2++;
			}
			else if (cube[i].side < up4)
			{
				cube[tag1++] = cube[i];
			}
		}
		if (tag1 == 0)
		{
			break;
		}

		if (vecS1Length != 0)
		{
			up4 = up4 * 2;
		}
		UpdataPushBackHashTable(tstream, test, up4, vecS1Length, vecS1, dimensionMin);

		if (tag1 <= initPointNum)
		{
			UpdataPushBackHashTable_1(tstream, test, up4, cube, dimensionMin, tag1);
			return;
		}

	}
}

void Index::UpdataInit(TStream& tstream, Test test, vector<int>& point, double side)
{
	Grid grid;
	int flag;
	double scale = 0;
	vector<double> leftCoordinate;
	map<long, Cell>myMap;
	cube.clear();
	int pointNum = nowPointNum;
	list<struct Cell> vecCellIndex;
	Cell t;
	t.index.push_back(0);
	t.leftCoordinate = tstream.getLeftCoordinate();
	t.scale = side;

	myQue.push(t);
	for (int i = 0; i < point.size(); i++)
	{
		myQue.front().points.push_back(point[i]);
	}


	while (!myQue.empty())
	{

		pointNum = myQue.front().points.size();
		if (myQue.front().index.size() > 1048576)
		{
			myQue.pop();
			continue;
		}
		scale = myQue.front().scale;
		leftCoordinate = myQue.front().leftCoordinate;
		grid.setGrid(pointNum, leftCoordinate, scale, test);
		int n = ceil(log2(tstream.getLength() / (grid.getLength())));

		if ((myQue.front().points.size() <= 5 && myQue.front().index.size() >= 10) || n >= 20)
		{
			for (auto iter = myQue.front().points.begin(); iter != myQue.front().points.end(); iter++)
			{
				Cube t;
				t.index = myQue.front().index;
				t.order = *iter;
				t.side = myQue.front().scale;
				cube.push_back(t);
			}
			myQue.pop();
			continue;
		}

		for (auto iter = myQue.front().points.begin(); iter != myQue.front().points.end(); iter++)
		{
			int order = *iter;
			long addr = 0;
			Cell_1 c;
			for (int j = 0; j < test.GetD(); j++)
			{
				int temp = (tstream.getData((order * test.GetD()) + j) - grid.getLeftCoordinate(j)) / grid.getLength();
				c.leftCoordinate.push_back(temp * grid.getLength() + myQue.front().leftCoordinate[j]);
				addr = (addr << n) | temp;
			}
			if (addr < 0)
			{
				continue;
			}
			Cell a;
			a.addr = addr;
			a.leftCoordinate = c.leftCoordinate;
			a.index = myQue.front().index;
			a.points.push_back(order);
			a.scale = grid.getLength();
			std::pair<std::map<long, Cell>::iterator, bool> ret1;
			ret1 = myMap.insert(make_pair(addr, a));
			if (!ret1.second)
			{
				myMap[addr].points.push_back(order);
			}

		}

		for (auto iter = myMap.begin(); iter != myMap.end(); iter++)
		{
			Cube t;
			if (iter->second.points.size() == 1)
			{
				iter->second.index = myQue.front().index;
				iter->second.index.push_back(iter->first);
				t.index = iter->second.index;
				t.order = iter->second.points.front();
				t.side = iter->second.scale;
				cube.push_back(t);
			}
			else if (iter->second.points.size() > 1)
			{
				iter->second.index = myQue.front().index;
				iter->second.index.push_back(iter->first);
				myQue.push(iter->second);
			}
		}
		myQue.pop();
		myMap.clear();
	}
}






void Index::FindNearestNeighbor(TStream& tstream, Test test)
{
	vector<double> vecLeftCoordinate(3);
	vector<double> dimensionMin;
	vector<long> pointIndex;
	tstream.setPointNeighbor(test);
	int order;
	vector<int> point;
	long index = 0;
	long addr = 0;
	int flag = 0;
	for (auto iter3 = vecHash.rbegin(); iter3 != vecHash.rend(); iter3++)
	{
		GetPoint(*iter3, point, tstream);
		for (int i = 0; i < point.size(); i++)
		{
			order = point[i];
			for (auto iter0 = iter3; iter0 != vecHash.rend(); iter0++)
			{
				int n = ceil(log2(tstream.getLength() / (iter0->side)));

				if (n > 25)
					break;
				dimensionMin = tstream.getLeftCoordinate();


				addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, dimensionMin, iter0->side, n);

				if (addr < 0)
				{
					break;
				}

				index = addr;

				addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, iter0->side / 2, 1);


				FindPointIndex(test.GetD(), vecV, n, pointIndex, index, addr);

				HandelPointIndex(tstream, test, pointIndex, addr, *iter0, order);

			}

			if (tstream.pointNeighbor[order].neighbor == -1)
			{
				tstream.pointNeighbor[order].distance = iter3->side;
			}
		}
	}
	cout << "//////findneighbor" << endl;
}



void Index::DivideIndex(TStream& tstream, Test test)
{
	int tag1 = tstream.pointNeighbor.size(), tag2 = 0;
	double mid = 0;
	Hash temp;
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	while (1)
	{
		long addr = 0;
		tag1 = tag1 - tag2;
		tag2 = 0;
		if (tag1 == 0)
		{
			break;
		}
		if (tag1 - tag2 <= test.GetK())
		{

			HandelPointNeighbor(tstream, test, tag1, tag2);
			break;
		}
		HandelPointNeighbor(tstream, test, tag1, tag2);

	}
	cout << "/////divideindex" << endl;
}




void Index::FindIndex(TStream& tstream, Test test)
{
	fp3 = fopen("Out.txt", "w");
	int order = 0;
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	long addr = 0;
	vector<int> point;
	for (auto iter3 = vecHashIndex.rbegin(); iter3 != vecHashIndex.rend(); iter3++)
	{
		GetPoint(*iter3, point, tstream);
		for (int i = 0; i < point.size(); i++)
		{
			if (point[i] >= 0)
			{
				order = point[i];
				auto t = iter3;
				for (auto iter0 = ++t; iter0 != vecHashIndex.rend(); iter0++)
				{
					int n = ceil(log2(tstream.getLength() / (iter0->side)));
					addr = Findaddr(tstream, order, test.GetD(), dimensionMin, iter0->side, n);
					if (addr < 0)
						continue;
					SetHashbucket(test, addr, iter0->HashBucket);
				}
			}
		}
		point.clear();
	}
	cout << "////findindex" << endl;
}


void Index::UpdataTStream(TStream& tstream, Test test)
{

	tstream.SetvecData_tag(test);
	int fenlie = 0, hebin = 0;
	long order;
	long addr = 0;
	vector<double> dimensionMin = tstream.getLeftCoordinate();
	vector<double> vecLeftCoordinate(3);
	vector<long> pointIndex;
	long index = 0;
	double distance = 0;
	int flag;
	vector<int> point;
	GetPoint(*vecHashIndex.rbegin(), point, tstream);
	float test_in = test.GetIn();

	fprintf(fp2, "��ʼ��ʱ���ϲ�������   %d   ����\n", (int)point.size());

	initPointNum = point.size();
	nowPointNum = point.size();
	Point a;
	for (int i = 0; i < point.size(); i++)
	{
		order = point[i];

		int n = ceil(log2(tstream.getLength() / (vecHashIndex.rbegin()->side)));
		if (n < 0 || n>25)
			continue;

		addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, dimensionMin, vecHashIndex.rbegin()->side, n);

		if (addr < 0)
			continue;
		index = addr;

		addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, vecHashIndex.rbegin()->side / 2, 1);


		FindPointIndex(test.GetD(), vecV, n, pointIndex, index, addr);

		HandelMap(tstream, test, pointIndex, addr, *vecHashIndex.rbegin(), order);
	}
	fprintf(fp2, "��ѡ����С��%d \n", (int)myMap_dis.size());
	fprintf(fp2, "����:%d   ���ڴ�С:%d   ��ѯ����%d\n", test.GetIn(), test.GetWindows() / test.GetD(), test.GetTime());
	fprintf(fp2, "��ʼ���α���   %d   �α�ĩβӦΪ   %d\n", tstream.vecData_tag, tstream.GetvecDataLen() / test.GetD());
	fprintf(fp2, "��ʼ��ʱ��   %d   ����ϣ��\n", (int)vecHashIndex.size());
	int windows = 0;
	clock_t startTime, endTime;
	fprintf(fp3, "Time = %d\n", TIME);
	for (int tag = tstream.vecData_tag; tag < tstream.GetvecDataLen() / test.GetD(); tag++)
	{
		tstream.vecData_begin = tstream.vecData_begin + test.GetIn(); 

		order = tstream.vecData_tag++;

		if (order == 13771)
		{
			cout << "asd";
		}
		if ((tstream.vecData_tag - test.GetWindows() / test.GetD()) % 102400 == 1)
		{
			startTime = clock();
		}
		if ((tstream.vecData_tag - test.GetWindows() / test.GetD()) % 102400 == 0)
		{
			endTime = clock();
			cout << "��ǰ�α�Ϊ" << tstream.vecData_tag << "     Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
		}


		if (test_in > 1)
		{
			if (tstream.vecData_tag - tstream.vecData_begin <= (test.GetWindows() / test.GetD()) / 2)
			{
				test.SetIn(0);
			}
			if (tstream.vecData_tag - tstream.vecData_begin == (test.GetWindows() / test.GetD()))
			{
				test.SetIn(test_in);
			}
		}
		else if (test_in < 1)
		{
			if (tstream.vecData_tag - tstream.vecData_begin >= (int)((test.GetWindows() / test.GetD()) * 1.5))
			{
				test.SetIn(test_in * 100);
			}
			if (tstream.vecData_tag - tstream.vecData_begin - (test.GetWindows() / test.GetD()) <= test_in * 100)
			{
				test.SetIn(test_in);
			}
		}

		if (tstream.vecData_tag % test.GetTime() == 0)
		{
			int i = 0;
			for (auto it = myMap_dis.begin(); it != myMap_dis.end(); it++)
			{
				if (i == 50)
					break;
				fprintf(fp3, "Point :%d  Neighbor :%d  Dis :%f\n", it->second.order, it->second.neighbor, it->first);
				i++;
			}
			fprintf(fp3, "\n\n");
		}

		if (tstream.vecData_tag % (test.GetWindows() / test.GetD()) == 1)
		{
			startTime = clock();
		}
		if (tstream.vecData_tag < tstream.vecData_begin)
		{
			break;
		}
		bool flag_1 = 0;
		bool flag_2 = 0;

		if (tstream.vecData_tag % (test.GetWindows() / test.GetD()) == 0)
		{
			for (auto it = myMap_dis.begin(); it != myMap_dis.end(); )
			{
				if (it->second.neighbor < tstream.vecData_begin || it->second.order < tstream.vecData_begin)
				{
					myMap_dis.erase(it++);
				}
				else
				{
					it++;
				}
			}
			for (int k = tstream.vecData_begin - (test.GetWindows() / test.GetD()); k < tstream.vecData_begin; k++)
			{
				int flag_1 = 0;
				int flag_2 = 0;
				for (auto it = vecHashIndex.begin(); it != vecHashIndex.end(); it++)
				{
					if (it->side == vecHashIndex.rbegin()->side)
						break;
					int n = ceil(log2(tstream.getLength() / (it->side)));
					long addr1 = Findaddr(tstream, k, test.GetD(), dimensionMin, it->side, n);
					if (addr1 < 0)
						continue;
					SetHashbucket_Reduce(test, addr1, it->HashBucket);
				}


				for (auto it = vecHashIndex.begin(); it != vecHashIndex.end(); it++)
				{
					int n = ceil(log2(tstream.getLength() / (it->side)));
					long addr1 = Findaddr(tstream, k, test.GetD(), dimensionMin, it->side, n);
					if (addr1 < 0)
						continue;
					long addr = getHashKey(addr1, it->HashBucket.size());
					for (auto it1 = it->HashBucket[addr].begin(); it1 != it->HashBucket[addr].end(); it1++)
					{
						if (it1->addr == addr1)
						{
							for (auto iter = it1->order.begin(); iter != it1->order.end(); iter++)
							{
								if (*iter == k)
								{
									if (it1->order.size() == 1 && it1->pointNum != 0)
									{
										it1->order.erase(iter);
										it1->order.push_back(-1);
										flag_1 = 1;
										break;
									}
									else if (it1->order.size() == 1 && it1->pointNum == 0)
									{
										it->HashBucket[addr].erase(it1);
										flag_1 = 1;
										break;
									}
									else
									{
										it1->order.erase(iter);
										flag_1 = 1;
										break;
									}
								}
							}
							if (flag_1 == 1)
							{
								flag_2 = 1;
								break;
							}
						}
					}
					if (flag_2 == 1)
					{
						break;
					}
				}
			}


			for (auto it = vecHashIndex.begin(); it != vecHashIndex.end(); it++)
			{
				vector<int> point___1;
				GetPoint(*it, point___1, tstream);
				fprintf(fp2, "�߳�Ϊ   %f   �Ĺ�ϣͰ��   %d   ����\n", it->side, (int)point___1.size());
			}
			point.clear();
			GetPoint(*vecHashIndex.rbegin(), point, tstream);
			nowPointNum = (int)point.size();
			fprintf(fp2, "��ʼ��������   %d   ���ڵ�����Ϊ   %d\n", initPointNum, nowPointNum);

			if (vecHashIndex.size() > 2)
			{
				if (nowPointNum > 4 * initPointNum)
				{
					double side = vecHashIndex.rbegin()->side;
					UpdataInit(tstream, test, point, side);
					vecHashIndex.pop_back();
					UpdataCubeDivide(tstream, test, initPointNum);
					nowPointNum = point.size();
					fprintf(fp2, "���Ѵ���:%d\n", ++fenlie);
				}

				if (nowPointNum < initPointNum / 4)
				{
					point.clear();
					double side = vecHashIndex.rbegin()->side;
					GetPoint(*++vecHashIndex.rbegin(), point, tstream);
					vector<int>point1;
					GetPoint(*vecHashIndex.rbegin(), point1, tstream);
					for (int i = 0; i < point1.size(); i++)
					{
						if (point1[i] < 0)
							continue;
						point.push_back(point1[i]);//�ϲ�
					}

					nowPointNum = point.size();
					UpdataInit(tstream, test, point, side);
					vecHashIndex.pop_back();
					vecHashIndex.pop_back();
					UpdataCubeDivide(tstream, test, initPointNum);
					fprintf(fp2, "�ϲ�����:%d\n", ++hebin);
				}
				vector <int> down;
				vector	<int>up;
				GetPoint(*vecHashIndex.begin(), down, tstream);
				GetPoint(*vecHashIndex.rbegin(), up, tstream);
				endTime = clock();
				fprintf(fp2, "�Ѿ�������   %d   ������,ʣ��   %d   ����ϣ��,��ѡ����СΪ   %d   ���ϲ�������Ϊ   %d   ���²������Ϊ   %d   ���ĵ�ʱ��Ϊ   %lf S\n\n\n", ++windows, (int)vecHashIndex.size(), (int)myMap_dis.size(), (int)up.size(), (int)down.size(), (double)(endTime - startTime) / CLOCKS_PER_SEC);
			}
			else
			{
				vector <int> down;
				vector	<int>up;
				GetPoint(*vecHashIndex.begin(), down, tstream);
				GetPoint(*vecHashIndex.rbegin(), up, tstream);
				endTime = clock();
				fprintf(fp2, "�Ѿ�������   %d   ������,ʣ��   %d   ����ϣ��,��ѡ����СΪ   %d   ���ϲ�������Ϊ   %d   ���²������Ϊ   %d   ���ĵ�ʱ��Ϊ   %lf S\n\n\n", ++windows, (int)vecHashIndex.size(), (int)myMap_dis.size(), (int)up.size(), (int)down.size(), (double)(endTime - startTime) / CLOCKS_PER_SEC);
			}

		}



		for (auto iter = vecHashIndex.begin(); iter != vecHashIndex.end(); iter++)//�������е�����
		{

	
			distance = 0;
			flag = 0;
			int n = ceil(log2(tstream.getLength() / (iter->side)));
			if (n < 0 || n>25)
			{
				flag_2 = 1;
				break;
			}
			addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, dimensionMin, iter->side, n);

			if (addr < 0)
			{
				flag_1 = 1;
				break;
			}

			
			index = addr;

			addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, iter->side / 2, 1);

			FindPointIndex(test.GetD(), vecV, n, pointIndex, index, addr);

			HandelPointIndex_Updata(tstream, test, pointIndex, index, *iter, order, distance, flag);

			if (flag == 0)
			{
				break;
			}
		}



		if (flag_2 == 1)
		{
			continue;
		}

		if (flag_1 == 1)
		{
			continue;
		}



		
		for (auto iter = vecHashIndex.begin(); iter != vecHashIndex.end(); iter++)
		{
			if (iter->side <= distance)
			{
				
				if (iter->side == vecHashIndex.rbegin()->side)
				{
					int n = ceil(log2(tstream.getLength() / (iter->side)));

					if (n > 25)
						break;
					addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, dimensionMin, vecHashIndex.rbegin()->side, n);


					if (addr < 0)
						break;

					index = addr;

					addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, vecHashIndex.rbegin()->side / 2, 1);

					if (addr > pow(2, test.GetD()))
					{
						break;
					}


					FindPointIndex(test.GetD(), vecV, n, pointIndex, index, addr);

					SetHashbucket(test, index, iter->HashBucket, order);

					HandelMap(tstream, test, pointIndex, addr, *iter, order);
					break;
				}


				int n = ceil(log2(tstream.getLength() / (iter->side)));
				if (n > 25)
					break;
				addr = Findaddr(tstream, order, test.GetD(), dimensionMin, iter->side, n);
				if (addr < 0)
					break;
				SetHashbucket(test, addr, iter->HashBucket, order);
				break;
			}
		}
	}
}

