#pragma once


float Surplus(float temp, float &scale)
{
	while (temp > scale)
	{
		temp = temp - scale;
	}
	return temp;
}
