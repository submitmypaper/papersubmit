#include <iostream>
using namespace std;
#include "TStream.h"
#include "Test.h"
#include "Index.h"
#include <ctime>
#include <fstream>
#pragma warning(disable:4996)��


int main()
{
	FILE* fp3;
	FILE* fp2;
	fp2 = fopen("log.txt", "w");

	Test test;
	fp3 = fopen("test.txt", "r");
	clock_t startTime, endTime;

	TStream tstream;
	startTime = clock();
	tstream.setFilData();
	endTime = clock();
	Index index1;

	fprintf(fp2, "read   %d   time��%lf S\n", tstream.GetvecDataLen() / 3, (double)(endTime - startTime) / CLOCKS_PER_SEC);
	int n;
	float a;
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			if (j % 5 == 3)
			{
				fscanf(fp3, "%f", &a);
			}
			else
			{
				fscanf(fp3, "%d", &n);
			}
			if (j % 5 == 0)
			{
				test.SetD(n);
			}
			else if (j % 5 == 1)
			{
				test.SetK(n);
			}
			else if (j % 5 == 2)
			{
				test.SetWindows(n);
			}
			else if (j % 5 == 3)
			{
				test.SetIn(a);
			}
			else if (j % 5 == 4)
			{
				test.SetTime(n);
			}
		}

		if (i == 0)
		{
			tstream.setRange(test);
			tstream.pointNeighbor.clear();
			tstream.vecData_begin = 0;
			tstream.InitPoint(test);
			Index index;

			startTime = clock();
			index.Init(tstream, test);
			index.CubeDivide(tstream, test);
			index.FindNearestNeighbor(tstream, test);
			index.SetTIME(test.GetTime());
			index.SetNF(test.GetK());
			index.DivideIndex(tstream, test);
			index.FindIndex(tstream, test);
			endTime = clock();


			fprintf(fp2, "init time��%f S\n", (float)(endTime - startTime) / CLOCKS_PER_SEC);

			index1 = index;

			cout << "Time = " << (float)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;

			clock_t s1, s2;

			s1 = clock();
			index.UpdataTStream(tstream, test);
			s2 = clock();
			cout << "UpdataTime = " << (float)(s2 - s1) / CLOCKS_PER_SEC << "s" << endl;


			fprintf(fp2, "win=1MB,K=100��%f  S \n", (float)(s2 - s1) / CLOCKS_PER_SEC);
		}
		else
		{
			tstream.vecData_begin = 0;
			Index index2 = index1;

			clock_t s1, s2;

			s1 = clock();
			index2.UpdataTStream(tstream, test);
			s2 = clock();
			cout << "UpdataTime = " << (float)(s2 - s1) / CLOCKS_PER_SEC << "s" << endl;

			fprintf(fp2, "win=1MB,K=200��%f  S \n", (float)(s2 - s1) / CLOCKS_PER_SEC);
		}

	}
	system("pause");
}