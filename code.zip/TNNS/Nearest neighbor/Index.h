#pragma once
#include "Grid.h"
#include "TStream.h"
#include <queue>
#include "Cell.h"
#include <map>
#include <ctime>

#pragma warning(disable:4996)��
class Index 
{
public:
	Index();
	~Index();
	void Init(TStream &tstream, Test test);
	void CubeDivide(TStream &tstream, Test test);
	void FindNearestNeighbor(TStream& tstream, Test test);
	void DivideIndex(TStream& tstream, Test test);
	void FindIndex(TStream& tstream, Test test);
	struct HashTable
	{
		long addr;
		list<int> order;
		int pointNum = 0;
	};
	struct Hash
	{
		vector<list<HashTable>> HashBucket;
		double side;
	};
	struct Point
	{
		int order;
		int neighbor;
	};
	int getHashKey(int addr, int hashBucketSize);
	long Findaddr(TStream &tstream, int order, int d, vector<double>& vecLeftCoordinate, vector<double> &min, double len, int n);
	long Findaddr(TStream &tstream, int order, int d, vector<double> &vecLeftCoordinate, double len, int n);
	void FindPointIndex(int d, int v[][24], int n, vector<long>& pointIndex, long index, int addr);
	void SetHashbucket(Test test, long addr, vector<list<HashTable>>& Hashbucket, int order);
	void SetHashbucket(Test test, long addr, vector<list<HashTable>>& Hashbucket);
	void SetHashbucket_Reduce(Test test, long addr, vector<list<HashTable>>& Hashbucket);
	void GetPoint(Hash &vecHash, vector<int>& point,TStream &tstream);
	void HandelPointNeighbor(TStream& tstream, Test test, int& tag1, int& tag2);
	void HandelPointIndex(TStream& tstream, Test test, vector<long>& pointIndex, long addr, Hash &h, int order);
	void HandelPointIndex_Updata(TStream& tstream, Test test, vector<long>& pointIndex, long addr, Hash &h, int order, double&distance, int &flag);
	void HandelMap(TStream& tstream, Test test, vector<long>& pointIndex, long addr, Hash& h, int order);
	void PushBackHashTable(TStream& tstream, Test test, double up4, int vecS1Length, vector<Cube>& vecS1, vector<double>& dimensionMin);
	void UpdataPushBackHashTable(TStream& tstream, Test test, double up4, int vecS1Length, vector<Cube>& vecS1, vector<double>& dimensionMin);
	void PushBackHashTable_1(TStream& tstream, Test test, double up4, vector<Cube>& cube, vector<double>& dimensionMin, int tag1);
	void UpdataPushBackHashTable_1(TStream& tstream, Test test, double up4, vector<Cube> &cube, vector<double>& dimensionMin, int tag1);
	void UpdataTStream(TStream& tstream, Test test);
	void UpdataCubeDivide(TStream& tstream, Test test,int initPointNum);
	void UpdataInit(TStream& tstream, Test test, vector<int> &point, double side);
	void SetNF(int f);
	void SetTIME(int time);
private:
	FILE* fp2;
	int TIME;
	int NF;
	FILE* fp3;
	map<double, Point> myMap_dis;
	queue<struct Cell> myQue;
	vector<Cube> cube;
	int initPointNum = 0;
	int nowPointNum = 0;
	vector<list<HashTable>> Hashbucket;
	list<Hash> vecHash;

	list<Hash> vecHashIndex;
	int vecV[8][24] = { {0,0,0,-1,0,0,-1,-1,0,0,-1,0,0,0,-1,-1,0,-1,-1,-1,-1,0,-1,-1} ,
						{0,0,0,0,-1,0,1,-1,0,1,0,0,0,0,-1,0,-1,-1,1,-1,-1,1,0,-1},
						{0,0,0,-1,0,0,-1,1,0,0,1,0,0,0,-1,-1,0,-1,-1,1,-1,0,1,-1},
						{0,0,0,1,0,0,0,1,0,1,1,0,0,0,-1,1,0,-1,0,1,-1,1,1,-1},
						{0,0,0,-1,0,0,-1,-1,0,0,-1,0,0,0,1,-1,0,1,-1,-1,1,0,-1,1} ,
						{0,0,0,0,-1,0,1,-1,0,1,0,0,0,0,1,0,-1,1,1,-1,1,1,0,1},
						{0,0,0,-1,0,0,-1,1,0,0,1,0,0,0,1,-1,0,1,-1,1,1,0,1,1},
						{0,0,0,1,0,0,0,1,0,1,1,0,0,0,1,1,0,1,0,1,1,1,1,1},

	};
};

