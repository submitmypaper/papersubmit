#include "Function.h"

Index::Hash Findaddr(TStream tstream, int d, Cube vecS1, vector<float> min, int n, float len,Index::Hash temp)
{
	unsigned long addr = 0;
	for (int j = 0; j < d; j++)
	{
		long temp = ((tstream.getData(vecS1.order * d + j) - min[j]) / (len));
		addr = (addr << n) | temp;
	}

	temp.order.push_back(vecS1.order);
	temp.index[addr] = vecS1.order;
	temp.side = len;
	return temp;
	//return addr;
}

long Findaddr(TStream tstream,int order, int d, vector<float> &vecLeftCoordinate,vector<float> min, float len,int n)
{
	unsigned long addr = 0;
	//vecLeftCoordinate->resize(n);
	for (int w = 0; w < d; w++)
	{
		long temp = ((tstream.getData(order * d + w) - min[w]) / len);
		vecLeftCoordinate[w] =  temp * len; //->push_back(temp * len); //
		addr = (addr << n) | temp;
	}
	return addr;
}

long Findaddr(TStream tstream, int order, int d, vector<float> vecLeftCoordinate, float len, int n)
{
	long addr = 0;
	for (int k1 = 0; k1 < d; k1++)
	{

		int temp = (tstream.getData(order * d + k1) - vecLeftCoordinate[k1]) / (len);
		addr = (addr << n) | temp;
	}
	return addr;
}

void FindPointIndex(int d, int v[][24], int n, vector<long> &pointIndex,long index,int addr)
{
	for (int z1 = 0; z1 < pow(2, d); z1++)
	{
		long t = index;
		for (int z2 = 0; z2 < d; z2++)
		{

			long temp = v[addr][z1 * d + z2];
			temp = (temp << n * (d - z2 - 1));
			t = t + temp;
		}
		pointIndex.push_back(t);
	}
}

Index::HashIndex Findaddr1(TStream tstream, int d, int order, vector<float> min, int n, float len, Index::HashIndex temp)
{
	unsigned long addr = 0;
	for (int j = 0; j < d; j++)
	{
		long temp = ((tstream.getData(order * d + j) - min[j]) / (len));
		addr = (addr << n) | temp;
	}

	temp.order.push_back(order);

	temp.index[addr]++;
	//temp.index[addr].order.push_back(order);
	//temp.index[addr].pointNum++;
	//temp.side = len;
	return temp;
	
}
