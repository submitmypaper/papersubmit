#pragma once

class SourceFile
{
public:

	SourceFile();
	~SourceFile();

	void SetWindows(int i, float a);


	void SetD(int d);


	void SetTag(long tag);

	void SetStart(long start);


	double GetWindows(long i);


	int GetD();


	long GetTag();

	long GetStart();

private:

	float source_Windows[99999];


	int source_d = 0;


	long source_Tag = 0;


	long source_Start = 0;


};

