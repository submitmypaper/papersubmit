#include "Test.h"
#include "TStream.h"
#include "Tree.h"
int main()
{
	Test test;
	TStream tstream;
	vector<Test> vecTestFile;
	clock_t startTime, endTime;
	test.Init(vecTestFile);
	tstream.Init(vecTestFile[0]);
	FILE* fp1;
	fp1 = fopen("log_main.txt", "w");
	for (int i = 0; i < 21; i++)
	{
		double time = 0;
		Tree tree;
		tstream.SetDataStreamBegin(0);
		tstream.SetDataStreamTag(vecTestFile[i].GetWindowSize() / vecTestFile[i].GetDimension());
		startTime = clock();
		tree.CreateTree(tstream, vecTestFile[i]);
		tree.PreOrderTree(tstream, vecTestFile[i]);
		endTime = clock();
		fprintf(fp1, "init time��%lf  S          ", (double)(endTime - startTime) / CLOCKS_PER_SEC);
		cout << "Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;


		//tree1 = tree;
		startTime = clock();
		tree.UpdateDataFlow(tstream, vecTestFile[i], time);
		endTime = clock();
		fprintf(fp1, "update time��%lf  S \n", (double)(endTime - startTime) / CLOCKS_PER_SEC - time);
		cout << "UpdataTime = " << (double)(endTime - startTime) / CLOCKS_PER_SEC - time << "s" << endl;

	}


}