#pragma once
#include <vector>
#include <list>
#include <queue>
#include <map>
#include "TStream.h"
#include "Test.h"
using namespace std;
class Tree
{
public:
	Tree();

	~Tree();

	struct TreeNode
	{
		long addr = 0;
		vector<int> vecObject;
		list<TreeNode*> lstPointer;
		TreeNode* fatherNode;
		vector<double> vecLeftDown;
		vector<double> vecRightUp;
		double sideLength;
		int height;
	};
	struct Pair
	{
		int objId;
		int neighborId;
	};
	int  FindNeighbor(TStream& tstream, Test& test, int objId, double side, double& distance, int tstreamBegin,int &objectNumber);
	void InsertMapCandidateSet(int objId, int neighbor, double distance);
	long Findaddr(TStream& tstream, int objNo, int d, vector<double>& vecLeftDown, vector<double>& newVecLeftDown, vector<double>& vecRightUp, vector<double>& newVecRightUp, double side);
	void CreateTree(TStream& tstream, Test& test);
	void RootInit(TStream& tstream, Test& test);
	void TreeNodeSplit(TStream& tstream, Test& test, TreeNode* node);
	void TreeNodePushBack(int objNo, long addr, TreeNode* node, vector<double>& newVecLeftDown, vector<double>& newVecRightUp);
	void PreOrderTree(TStream& tstream, Test& test);
	void UpdateDataFlow(TStream& tstream, Test& test,double &time);

	void TreeNodeInsert(TStream& tstream, Test& test, int objId,double &side);
	void UpdataCandidateSet(int tstreamBegin);
	void PrintMapCandidateSet(Test &test,int tstreamBegin);

	void TreeNodeBatchSplit(TStream& tstream, Test& test);
	void UpdataTreeNodeSplit(TStream& tstream, Test& test, queue<TreeNode*>& queBatchSplit);

	double GetQueryRadiusInThis(TStream& tstream, Test& test, int objId, vector<int> vecObject, int& neighbor);
	double GetQueryRadiusInOther(TStream& tstream, Test& test, int objId, TreeNode* fatherNode, int& neighbor);
	double GetDistanceFromOtherNode(TStream& tstream, Test& test, int objId, vector<double>& vecLeftDown, vector<double>& vecRightUp);
private:
	FILE* fp1;

	TreeNode* root;
	map<double, Pair> mapCandidateSet;

};

