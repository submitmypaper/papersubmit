#include "Tree.h"
#include <stack>
#define NUM 1


Tree::Tree()
{
}

Tree::~Tree()
{
}

int Tree::FindNeighbor(TStream& tstream, Test& test, int objId, double side, double& distance, int tstreamBegin, int& objectNumber)
{
	double minPair = 0x3f3f3f3f;
	int neighbor = -1;
	TreeNode* node;
	queue<TreeNode*> queLevelOrder;
	queLevelOrder.push(root);


	while (!queLevelOrder.empty())
	{
		node = queLevelOrder.front();

		if (node->lstPointer.size() == 0 && node->vecObject.size() > 0)
		{
			for (auto iterLstObject = node->vecObject.begin(); iterLstObject != node->vecObject.end(); )
			{
				distance = 0;
				if (*iterLstObject < tstreamBegin)
				{
					iterLstObject = node->vecObject.erase(iterLstObject);
					continue;
				}
				for (int i = 0; i < test.GetDimension(); i++)
				{
					distance += pow(tstream.GetDataStream(objId * test.GetDimension() + i) - tstream.GetDataStream(*iterLstObject * test.GetDimension() + i), 2);
				}
				distance = sqrt(distance);
				objectNumber++;
				if (distance < minPair && distance != 0 && *iterLstObject != objId)
				{
					neighbor = *iterLstObject;
					minPair = distance;
				}
				iterLstObject++;
			}
		}

		queLevelOrder.pop();
		for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
		{
			bool flagInBox = 1;
			for (int i = 0; i < test.GetDimension(); i++)
			{
				if (tstream.GetDataStream(objId * test.GetDimension() + i) >= (*iterLstPointer)->vecLeftDown[i] && tstream.GetDataStream(objId * test.GetDimension() + i) <= (*iterLstPointer)->vecRightUp[i])
				{
					continue;
				}
				else
				{
					flagInBox = 0;
					break;
				}
			}
			if (flagInBox == 1)
			{
				queLevelOrder.push(*iterLstPointer);
				continue;
			}

			double minDistance = 0;
			minDistance = GetDistanceFromOtherNode(tstream, test, objId, (*iterLstPointer)->vecLeftDown, (*iterLstPointer)->vecRightUp);
			if (minDistance <= side)
			{
				queLevelOrder.push(*iterLstPointer);
			}
		}
	}
	distance = minPair;
	return neighbor;
}

void Tree::InsertMapCandidateSet(int objId, int neighbor, double distance)
{
	double step = 0.000001;
	Pair temp, temp1;
	temp.objId = objId;
	temp.neighborId = neighbor;
	std::pair<std::map<double, Pair>::iterator, bool> ret1;
	ret1 = mapCandidateSet.insert(make_pair(distance, temp));
	temp1 = mapCandidateSet[distance];
	while (!ret1.second)
	{
		if (temp1.objId == temp.neighborId && temp1.neighborId == temp.objId)
			return;
		else
		{
			ret1 = mapCandidateSet.insert(make_pair(distance + step, temp));
			step += 0.000001;
		}
	}
}

long Tree::Findaddr(TStream& tstream, int objNo, int d, vector<double>& vecLeftDown, vector<double>& newVecLeftDown, vector<double>& vecRightUp, vector<double>& newVecRightUp, double side)
{
	newVecLeftDown = vecLeftDown;
	newVecRightUp = vecRightUp;
	long addr = 0;
	int temp = 0;
	for (int i = 0; i < d; i++)
	{
		temp = (tstream.GetDataStream(objNo * d + i) - vecLeftDown[i]) / side;
		newVecLeftDown[i] = newVecLeftDown[i] + temp * side;
		newVecRightUp[i] = newVecRightUp[i] - (1 - temp) * side;
		addr = (addr << 1) | temp;
	}
	return addr;
}

void Tree::RootInit(TStream& tstream, Test& test)
{
	for (int i = 0; i < test.GetWindowSize() / test.GetDimension(); i++)
	{
		root->vecObject.push_back(i);
	}
	for (int i = 0; i < test.GetDimension(); i++)
	{
		root->vecLeftDown.push_back(0);
		root->vecRightUp.push_back(tstream.GetLength());
	}
	root->sideLength = tstream.GetLength();
	root->height = 0;
}

void Tree::TreeNodeSplit(TStream& tstream, Test& test, TreeNode* node)
{
	long addr = 0;
	vector<double> newVecLeftDown;
	vector<double> newVecRightUp;
	for (auto iterlstObj = node->vecObject.begin(); iterlstObj != node->vecObject.end(); iterlstObj++)
	{
		addr = Findaddr(tstream, *iterlstObj, test.GetDimension(), node->vecLeftDown, newVecLeftDown, node->vecRightUp, newVecRightUp, node->sideLength / 2);
		TreeNodePushBack(*iterlstObj, addr, node, newVecLeftDown, newVecRightUp);
	}
	node->vecObject.clear();
}
void Tree::TreeNodePushBack(int objNo, long addr, TreeNode* node, vector<double>& newVecLeftDown, vector<double>& newVecRightUp)
{
	bool flag = 0;
	for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
	{
		if ((*iterLstPointer)->addr == addr)
		{
			flag = 1;
			(*iterLstPointer)->vecObject.push_back(objNo);
		}
	}
	if (flag == 0)
	{
		TreeNode* newnode = new TreeNode;
		newnode->vecObject.push_back(objNo);
		newnode->addr = addr;
		newnode->vecLeftDown = newVecLeftDown;
		newnode->vecRightUp = newVecRightUp;
		newnode->height = node->height + 1;
		newnode->sideLength = node->sideLength / 2;
		newnode->fatherNode = node;
		node->lstPointer.push_back(newnode);
	}
}

void Tree::CreateTree(TStream& tstream, Test& test)
{
	fp1 = fopen("log.txt", "w");
	root = new TreeNode;
	RootInit(tstream, test);
	queue<TreeNode*> queCreateTree;
	queCreateTree.push(root);
	root->fatherNode = NULL;
	FILE* fp2;
	
	int leafId = 0;
	while (!queCreateTree.empty())
	{
		if (queCreateTree.front()->sideLength <= tstream.GetLength() / 1024 / 1024 / 1024)
		{
			queCreateTree.pop();
			continue;
		}
		TreeNodeSplit(tstream, test, queCreateTree.front());
		for (auto iterLstPointer = queCreateTree.front()->lstPointer.begin(); iterLstPointer != queCreateTree.front()->lstPointer.end(); iterLstPointer++)
		{
			if ((*iterLstPointer)->vecObject.size() > NUM)
			{
				queCreateTree.push((*iterLstPointer));
			}
		}
		queCreateTree.pop();
	}
}

double Tree::GetQueryRadiusInThis(TStream& tstream, Test& test, int objId, vector<int> vecObject, int& neighbor)
{
	double distance = 0;
	double minPair = 0x3f3f3f3f;
	for (auto iterLstObject = vecObject.begin(); iterLstObject != vecObject.end(); iterLstObject++)
	{
		distance = 0;
		if (*iterLstObject < tstream.GetDataStreamBegin())
			continue;
		for (int i = 0; i < test.GetDimension(); i++)
		{
			distance += pow(tstream.GetDataStream(objId * test.GetDimension() + i) - tstream.GetDataStream(*iterLstObject * test.GetDimension() + i), 2);
		}
		distance = sqrt(distance);
		if (distance < minPair && distance != 0)
		{
			neighbor = *iterLstObject;
			minPair = distance;
			break;
		}
	}
	if (minPair == 0x3f3f3f3f)
		return -1;
	return minPair;
}

double Tree::GetQueryRadiusInOther(TStream& tstream, Test& test, int objId, TreeNode* fatherNode, int& neighbor)
{
	queue<TreeNode*> queGetQueryRadius;
	queGetQueryRadius.push(fatherNode);
	TreeNode* node;
	TreeNode* minNode;
	double pairDistance = 0x3f3f3f3f;
	double minPairDistance = 0x3f3f3f3f;
	double minDistanceNode = 0x3f3f3f3f;
	double distanceNode = 0;
	while (!queGetQueryRadius.empty())
	{
		node = queGetQueryRadius.front();
		if (node->lstPointer.size() == 0 && node->vecObject.size() > 0)
		{
			pairDistance = GetQueryRadiusInThis(tstream, test, objId, node->vecObject, neighbor);
			break;
		}
		queGetQueryRadius.pop();
		for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
		{
			bool flagInBox = 1;
			for (int i = 0; i < test.GetDimension(); i++)
			{
				if (tstream.GetDataStream(objId * test.GetDimension() + i) >= (*iterLstPointer)->vecLeftDown[i] && tstream.GetDataStream(objId * test.GetDimension() + i) < (*iterLstPointer)->vecRightUp[i])
				{
					continue;
				}
				else
				{
					flagInBox = 0;
					break;
				}
			}
			if (flagInBox == 1 && (*iterLstPointer)->vecObject.size() == 1)
			{
				continue;
			}
			distanceNode = 0;
			distanceNode = GetDistanceFromOtherNode(tstream, test, objId, (*iterLstPointer)->vecLeftDown, (*iterLstPointer)->vecRightUp);
			if (distanceNode < minDistanceNode)
			{
				queGetQueryRadius.push(*iterLstPointer);
				break;
			}
		}
	}
	if (pairDistance == -1)
		return -1;
	if (pairDistance == 0x3f3f3f3f)
		return -1;
	return pairDistance;
}

double Tree::GetDistanceFromOtherNode(TStream& tstream, Test& test, int objId, vector<double>& vecLeftDown, vector<double>& vecRightUp)
{
	double distanceLeft = 0;
	double disRight = 0;
	double minDistance = 0x3f3f3f3f;
	for (int i = 0; i < test.GetDimension(); i++)
	{
		distanceLeft += pow(tstream.GetDataStream(objId * test.GetDimension() + i) - vecLeftDown[i], 2);
		disRight += pow(tstream.GetDataStream(objId * test.GetDimension() + i) - vecRightUp[i], 2);
	}
	distanceLeft = sqrt(distanceLeft);
	disRight = sqrt(disRight);
	distanceLeft < disRight ? minDistance = distanceLeft : minDistance = disRight;
	return minDistance;
}

void Tree::PreOrderTree(TStream& tstream, Test& test)
{
	stack<TreeNode*> stkPreOrder;
	int neighbor = -1;
	double distance = 0;
	TreeNode* orderPointer = root;
	mapCandidateSet.clear();
	double queryRadius = 0;
	if (orderPointer != NULL)
		stkPreOrder.push(orderPointer);
	while (!stkPreOrder.empty())
	{
		orderPointer = stkPreOrder.top();

		stkPreOrder.pop();

		if (orderPointer->lstPointer.size() == 0)
		{
			if (orderPointer->vecObject.size() > 1)
			{
				for (auto iterObject = orderPointer->vecObject.begin(); iterObject != orderPointer->vecObject.end(); iterObject++)
				{
					queryRadius = GetQueryRadiusInThis(tstream, test, *iterObject, orderPointer->vecObject, neighbor);
					if (queryRadius == -1)
						queryRadius = orderPointer->sideLength;
					neighbor = -1;
					int a = 0;
					neighbor = FindNeighbor(tstream, test, *iterObject, queryRadius, distance, 0, a);
					if (neighbor != -1)
						InsertMapCandidateSet(*iterObject, neighbor, distance);
				}
			}
			else if (orderPointer->vecObject.size() == 1)
			{
				int neighbor1 = -1;
				queryRadius = GetQueryRadiusInOther(tstream, test, *orderPointer->vecObject.begin(), (*orderPointer).fatherNode, neighbor1);

				if (queryRadius == -1)
				{
					queryRadius = 2 * sqrt(test.GetDimension()) * orderPointer->sideLength;
				}
				int a = 0;
				neighbor = -1;
				neighbor = FindNeighbor(tstream, test, *orderPointer->vecObject.begin(), queryRadius, distance, 0, a);
				if (neighbor != -1)
					InsertMapCandidateSet(*orderPointer->vecObject.begin(), neighbor, distance);
				else
					InsertMapCandidateSet(*orderPointer->vecObject.begin(), neighbor1, queryRadius);
			}
			continue;
		}
		for (auto iterLstPointer = orderPointer->lstPointer.begin(); iterLstPointer != orderPointer->lstPointer.end(); iterLstPointer++)
		{
			stkPreOrder.push(*iterLstPointer);
		}
	}
}

void Tree::UpdateDataFlow(TStream& tstream, Test& test, double& time)
{
	int newObj = test.GetWindowSize() / test.GetDimension();
	int neighbor = -1;
	double distance = 0;
	double queryRadius = 0;
	tstream.SetDataStreamTag(test.GetWindowSize() / test.GetDimension());
	tstream.SetDataStreamBegin(0);

	time = 0;
	clock_t startTime, endTime;
	vector<int>vecObjectNumber;
	int objectNumber = 0;

	for (; tstream.GetDataStreamTag() < tstream.GetDataStreamLength() / test.GetDimension(); )
	{
		double step = 0.0000001;

		tstream.AddDataStreamBegin(test.GetOutFlow());
		tstream.AddDataStreamTag(test.GetInFlow());



		if ((tstream.GetDataStreamTag() - tstream.GetDataStreamBegin()) >= 10 * (test.GetWindowSize() / test.GetDimension()))
		{
			tstream.SetDataStreamBegin(tstream.GetDataStreamTag() - (test.GetWindowSize() / test.GetDimension()));
		}

		if ((tstream.GetDataStreamTag() - tstream.GetDataStreamBegin()) <= 0.1 * (test.GetWindowSize() / test.GetDimension()))
		{
			tstream.SetDataStreamTag(tstream.GetDataStreamBegin() + (test.GetWindowSize() / test.GetDimension()));
			if (tstream.GetDataStreamTag() > tstream.GetDataStreamLength() / test.GetDimension())
			{
				tstream.SetDataStreamTag(tstream.GetDataStreamLength() / test.GetDimension());
			}

		}

		if (tstream.GetDataStreamTag() % test.GetQueryCycle() == 0)
		{
			PrintMapCandidateSet(test, tstream.GetDataStreamBegin());
		}

		if (test.GetInFlow() == 1 && test.GetOutFlow() == 1 && (tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 1048576 == 0)
		{
			startTime = clock();

			UpdataCandidateSet(tstream.GetDataStreamBegin());
			endTime = clock();
			time += (double)(endTime - startTime) / CLOCKS_PER_SEC;
		}

		for (int i = newObj; i < tstream.GetDataStreamTag(); i++)
		{
			queryRadius = 0;
			neighbor = -1;
			TreeNodeInsert(tstream, test, i, queryRadius);  
			neighbor = FindNeighbor(tstream, test, i, queryRadius, distance, tstream.GetDataStreamBegin(), objectNumber);
			if (neighbor != -1)
				InsertMapCandidateSet(i, neighbor, distance);
		}
		newObj = tstream.GetDataStreamTag();
	}

}

void Tree::TreeNodeInsert(TStream& tstream, Test& test, int objId, double& side)
{
	bool flagInsert = 0;
	TreeNode* node = NULL;
	queue<TreeNode*> queInsert;
	queInsert.push(root);
	double distance = 0;
	double minPair = 0x3f3f3f3f;
	while (!queInsert.empty())
	{
		node = queInsert.front();

		if (node->lstPointer.size() == 0)
		{

			for (auto iterVecObject = node->vecObject.begin(); iterVecObject != node->vecObject.end(); )
			{
				if (*iterVecObject < tstream.GetDataStreamBegin())
				{
					iterVecObject = node->vecObject.erase(iterVecObject);
				}
				else
				{
					iterVecObject++;
				}
			}
			node->vecObject.push_back(objId);


			if (node->vecObject.size() == 1)
			{
				int neighbor1 = -1;
				minPair = GetQueryRadiusInOther(tstream, test, *node->vecObject.begin(), (*node).fatherNode, neighbor1);

				if (minPair == -1)
				{
					minPair = node->sideLength;
				}
			}
			else
			{

				int neighbor1 = -1;
				minPair = GetQueryRadiusInThis(tstream, test, objId, node->vecObject, neighbor1);
				if (minPair == -1)
					minPair = node->sideLength;
				if (node->sideLength > tstream.GetLength() / 1024 / 1024 / 1024)
				{
					TreeNodeSplit(tstream, test, node);
				}

			}
			flagInsert = 1;
			side = minPair;
			return;
		}
		queInsert.pop();

		for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
		{
			bool flagInBox = 1;
			for (int i = 0; i < test.GetDimension(); i++)
			{
				if (tstream.GetDataStream(objId * test.GetDimension() + i) >= (*iterLstPointer)->vecLeftDown[i] && tstream.GetDataStream(objId * test.GetDimension() + i) < (*iterLstPointer)->vecRightUp[i])
				{
					continue;
				}
				else
				{
					flagInBox = 0;
					break;
				}
			}
			if (flagInBox == 1)
			{
				queInsert.push(*iterLstPointer);
				break;
			}
		}

	}

	if (flagInsert == 0)
	{
		node->vecObject.push_back(objId);
		TreeNodeSplit(tstream, test, node);
		int neighbor1 = -1;
		minPair = GetQueryRadiusInOther(tstream, test, objId, node, neighbor1);

		if (minPair == -1)
		{
			minPair = node->sideLength / 2.0;
		}
		side = minPair;
	}
}

void Tree::UpdataCandidateSet(int tstreamBegin)
{
	for (auto iterMapCandidateSet = mapCandidateSet.begin(); iterMapCandidateSet != mapCandidateSet.end(); )
	{
		if (iterMapCandidateSet->second.neighborId < tstreamBegin || iterMapCandidateSet->second.objId < tstreamBegin)
		{
			mapCandidateSet.erase(iterMapCandidateSet++);
		}
		else
		{
			iterMapCandidateSet++;
		}
	}
}

void Tree::PrintMapCandidateSet(Test& test, int tstreamBegin)
{
	int k = 0;
	for (auto iterMapCandidateSet = mapCandidateSet.begin(); iterMapCandidateSet != mapCandidateSet.end(); iterMapCandidateSet++)
	{
		if (k == 10)
		{
			fprintf(fp1, "\n\n\n");
			break;
		}
		if (iterMapCandidateSet->second.objId < tstreamBegin || iterMapCandidateSet->second.neighborId < tstreamBegin)
		{
			continue;
		}
		fprintf(fp1, "����%d  ���������%d,  �����ǣ�%lf\n", iterMapCandidateSet->second.objId, iterMapCandidateSet->second.neighborId, iterMapCandidateSet->first);
		k++;
	}
}

void Tree::TreeNodeBatchSplit(TStream& tstream, Test& test)
{
	stack<TreeNode*> stkPreOrder;

	TreeNode* orderPointer = root;
	queue<TreeNode*> queBatchSplit;

	if (orderPointer != NULL)
		stkPreOrder.push(orderPointer);
	while (!stkPreOrder.empty())
	{
		orderPointer = stkPreOrder.top();

		stkPreOrder.pop();
		if (orderPointer->lstPointer.size() == 0 && orderPointer->vecObject.size() > NUM)//˵���õ�ΪҶ�ӽڵ� �ͳ�ʼ��һ�����жϣ������
		{
			queBatchSplit.push(orderPointer);

		}

		for (auto iterLstPointer = orderPointer->lstPointer.begin(); iterLstPointer != orderPointer->lstPointer.end();)
		{
			if ((*iterLstPointer)->lstPointer.size() == 0 && (*iterLstPointer)->vecObject.size() > NUM)
			{
				for (auto iterVecobject = (*iterLstPointer)->vecObject.begin(); iterVecobject != (*iterLstPointer)->vecObject.end(); )
				{
					if (*iterVecobject < tstream.GetDataStreamBegin())
					{
						iterVecobject = (*iterLstPointer)->vecObject.erase(iterVecobject);
					}
					else
					{
						iterVecobject++;
					}
				}
			}
			if ((*iterLstPointer)->lstPointer.size() == 0 && (*iterLstPointer)->vecObject.size() == 0)
			{
				orderPointer->lstPointer.erase(iterLstPointer++);
			}
			else
				stkPreOrder.push(*iterLstPointer++);
		}
	}
	UpdataTreeNodeSplit(tstream, test, queBatchSplit);
}

void Tree::UpdataTreeNodeSplit(TStream& tstream, Test& test, queue<TreeNode*>& queBatchSplit)
{
	TreeNode* node;
	while (!queBatchSplit.empty())
	{
		node = queBatchSplit.front();
		if (queBatchSplit.front()->sideLength <= tstream.GetLength() / 1024 / 1024 / 1024)
		{
			queBatchSplit.pop();
			continue;
		}
		TreeNodeSplit(tstream, test, queBatchSplit.front());
		for (auto iterLstPointer = queBatchSplit.front()->lstPointer.begin(); iterLstPointer != queBatchSplit.front()->lstPointer.end(); iterLstPointer++)
		{
			if ((*iterLstPointer)->vecObject.size() > NUM)
			{
				queBatchSplit.push((*iterLstPointer));
			}
		}
		queBatchSplit.pop();
	}
}