#pragma once
class Test
{
public:

	Test();
	~Test();

	void SetD(int d);

	void SetK(int k);

	void SetWindows(long w);

	void SetIn(float in);

	
	void SetTime(int time);

	int GetD();

	int GetK();

	long GetWindows();

	float GetIn();

	int GetTime();
	void setTestData();


private:

	int t_D;

	int t_K;

	long t_Windows;

	float t_In;

	int t_Time;

};

