#pragma once
#include <vector>
#include <list>
#include "TStream.h"
#include <queue>
#include<iostream>
#include <map>
#pragma warning(disable:4996)��
using namespace std;
class Tree
{
public:
	struct TreeNode
	{
		int r = 0;
		struct TreeNode* Lchild;
		struct TreeNode* Rchild;
		struct TreeNode* Father;
		vector<float> leftDown;
		vector<float> rightUp;
		list<int> order;
		int heigh = 0;
	};
	struct Point
	{
		int order;
		int neighbor;
	};
	void CreateTree(TStream &tstream, Test &test);
	void PreOrder(TStream& tstream, Test& test);
	void UpdataTStream(TStream& tstream, Test& test);

private:
	map<float, Point> myMap_dis;
	TreeNode* root;
	FILE* fp3;
	FILE* fp4;

};

