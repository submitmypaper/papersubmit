#include "TStream.h"
#include <fstream>
#include <iostream>
using namespace std;
#pragma warning(disable:4996)��
#include <cmath>

TStream::TStream()
{
}


TStream::~TStream()
{
}

float TStream::getData(int ID)
{
	return vecData[ID];
}

long TStream::GetvecDataLen()
{
	return vecData.size();
}

void TStream::setRange(Test& test)
{
	int dimension = test.GetD();
	int pointNum = vecData.size() / dimension;
	int tag = 0;
	for (int i = 0; i < pointNum; i++)
	{
		for (int j = 0; j < dimension; j++)
		{
			if (i == 0)
			{
				dimensionMax.push_back(vecData[tag]);
				dimensionMin.push_back(vecData[tag]);
			}
			else
			{
				//if (vecData[tag] > 60)
				//{
				//	cout << "asd";
				//}
				if (dimensionMax[j] < vecData[tag])
				{

					//copy(dimensionMax[j], dimensionMax[j], vecData[tag]);
					dimensionMax[j] = vecData[tag];
				}
				if (dimensionMin[j] > vecData[tag])
				{
					dimensionMin[j] = vecData[tag];
				}
			}
			tag++;
		}
	}
	leftCoordinate = dimensionMin;
	float max = 0;
	for (int i = 0; i < dimension; i++)
	{
		if (i == 0)
		{
			max = dimensionMax[i] - dimensionMin[i];
		}
		else
		{
			if (max < dimensionMax[i] - dimensionMin[i])
			{
				max = dimensionMax[i] - dimensionMin[i];
			}
		}
	}
	max = ceil(max);
	length = max;
}

vector<float> TStream::getLeftCoordinate()
{
	return leftCoordinate;
}

vector<float> TStream::getDimensionMax()
{

	return dimensionMax;
}

void TStream::InitPoint(Test &test)
{
	PointNeighbor t;
	for (int i = 0; i < test.GetWindows() / test.GetD(); i++)
	{
		t.neighbor = -1;
		t.distance = 0x3f3f3f3f;
		pointNeighbor.push_back(t);
	}
}

float TStream::getLength()
{
	return length;
}

void TStream::SetvecData_tag(Test &test)
{
	vecData_tag = test.GetWindows() / test.GetD();
}





void TStream::setFilData()
{
	FILE* fp1;
	double dlNumber;
	double maxData = 0;
	double step = 0.05;
	int objectNumber = 0;
	if ((fp1 = fopen("SourceFile.txt", "r")) != NULL)
	{
		while (fscanf(fp1, "%lf", &dlNumber) != EOF)
		{
			if (dlNumber > 1000)
			{
				continue;
			}
			objectNumber++;

			dlNumber = dlNumber + step;
			step += 0.05;
			if (step >= 5)
				step = 0.05;

			if (objectNumber >= 18862080 * 3 && objectNumber <= 20910080 * 3)
				continue;

			if (objectNumber >= 21729280 * 3 && objectNumber <= 22650880 * 3)
				continue;

			if (maxData < dlNumber)
				maxData = dlNumber;
			vecData.push_back(dlNumber);

			if (objectNumber >= 27258880 * 3)
			{
				cout << "Object amount" << objectNumber / 3 << endl;
				break;
			}
		}
	}
}

void TStream::setPointNeighbor(Test& test)
{
	pointNeighbor.resize(test.GetWindows() / test.GetD());
	for (int i = 0; i < test.GetWindows() / test.GetD(); i++)
	{
		pointNeighbor[i].order = i;
	}
}



