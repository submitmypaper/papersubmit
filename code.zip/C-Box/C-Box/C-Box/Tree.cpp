#include "Tree.h"
#include <numeric>
#include <cmath>
#include<algorithm>
#include <stack>
#define NUM 10
void Tree::CreateTree(TStream& tstream, Test& test)
{
	fp3 = fopen("out.txt", "w");
	queue<TreeNode*> myQue;
	root = new TreeNode;
	int r = 0;
	int r = 0;
	float max = 0;

	for (int j = 0; j < test.GetD(); j++)
	{
		vector<float> t;
		for (int i = j; i < test.GetWindows(); i += test.GetD())
		{
			t.push_back(tstream.getData(i));
		}
		float sum = accumulate(t.begin(), t.end(), 0.0);
		float mean = sum / t.size();

		float accum = 0.0;
		for (int k = 0; k < t.size(); k++)
		{
			accum += (t[k] - mean) * (t[k] - mean);
		}

		float stdev = sqrt(accum / (t.size() - 1));
		if (max < stdev)
		{
			max = stdev;
			r = j;
		}
	}

	for (int i = 0; i < test.GetWindows() / test.GetD(); i++)
	{
		root->order.push_back(i);
	}
	root->leftDown = tstream.getLeftCoordinate();
	root->rightUp = tstream.getDimensionMax();
	root->r = r;
	root->heigh++;
	myQue.push(root);
	root->Father = NULL;

	while (!myQue.empty())
	{
		float dis = 0;
		for (int i = 0; i < myQue.front()->leftDown.size(); i++)
		{
			dis += pow(myQue.front()->rightUp[i] - myQue.front()->leftDown[i], 2);
		}
		dis = sqrt(dis);
		int n = tstream.getLength() / dis;

		r = myQue.front()->r;
		if (myQue.front()->order.size() <= NUM || n > 1000000)
		{
			myQue.pop();
			continue;
		}
		vector<float>t;
		for (auto iter = myQue.front()->order.begin(); iter != myQue.front()->order.end(); iter++)
		{
			t.push_back(tstream.getData(*iter * test.GetD() + myQue.front()->r));
		}
		nth_element(t.begin(), t.begin() + t.size() / 2, t.end());
		float mid = t[t.size() / 2];
		TreeNode* lchild = new TreeNode;
		TreeNode* rchild = new TreeNode;
		for (auto iter = myQue.front()->order.begin(); iter != myQue.front()->order.end(); iter++)
		{
			if (tstream.getData(*iter * test.GetD() + myQue.front()->r) < mid)
				lchild->order.push_back(*iter);
			else if (tstream.getData(*iter * test.GetD() + myQue.front()->r) >= mid)
				rchild->order.push_back(*iter);
		}

		lchild->leftDown = myQue.front()->leftDown;
		lchild->rightUp = myQue.front()->rightUp;
		rchild->leftDown = myQue.front()->leftDown;
		rchild->rightUp = myQue.front()->rightUp;

		lchild->rightUp[r] = mid;
		rchild->leftDown[r] = mid;

		lchild->Lchild = NULL;
		lchild->Rchild = NULL;
		rchild->Lchild = NULL;
		rchild->Rchild = NULL;



		r = (r + 1) % test.GetD();
		lchild->r = r;
		rchild->r = r;

		lchild->Father = myQue.front();
		rchild->Father = myQue.front();
		myQue.front()->Lchild = lchild;
		myQue.front()->Rchild = rchild;


		myQue.push(lchild);
		myQue.push(rchild);
		myQue.front()->order.clear();
		myQue.pop();

	}
}

void Tree::PreOrder(TStream& tstream, Test& test)
{

	stack<TreeNode*> stack;
	long R = -1;
	float min = 0x3f3f3f3f;
	float min1 = 0x3f3f3f3f;
	float dis = 0;
	Point a;
	float step1 = 0.000001;
	TreeNode* p = root;
	while (p || !stack.empty())
	{
		if (p != NULL)
		{
			stack.push(p);
			if (p->Lchild == NULL && p->Rchild == NULL)
			{
				for (auto iter = p->order.begin(); iter != p->order.end(); iter++)
				{
					min = 0x3f3f3f3f;
					float dis = 0;
					R = -1;
					for (auto iter1 = p->order.begin(); iter1 != p->order.end(); iter1++)
					{
						dis = 0;
						for (int w = 0; w < test.GetD(); w++)
						{
							dis += pow(tstream.getData(*iter * test.GetD() + w) - tstream.getData(*iter1 * test.GetD() + w), 2);
						}
						dis = sqrt(dis);
						if (dis < min && dis != 0)
						{
							R = *iter1;
							min = dis;
						}
					}
					min1 = min;

					queue<TreeNode*> nodeQueue;
					nodeQueue.push(root);
					TreeNode* node;

					while (!nodeQueue.empty())
					{
						node = nodeQueue.front();
						if (node->Lchild == NULL && node->Rchild == NULL && node != p)
						{
							for (auto iter2 = node->order.begin(); iter2 != node->order.end(); iter2++)
							{
								dis = 0;
								for (int w = 0; w < test.GetD(); w++)
								{
									dis += pow(tstream.getData(*iter * test.GetD() + w) - tstream.getData(*iter2 * test.GetD() + w), 2);
								}
								dis = sqrt(dis);
								if (dis < min && dis != 0)
								{
									R = *iter2;
									min = dis;
								}
							}
						}
						nodeQueue.pop();
						if (node->Lchild)
						{
							float min2 = 0x3f3f3f3f;
							float dis1 = 0;
							float dis2 = 0;
							for (int w = 0; w < test.GetD(); w++)
							{
								dis1 += pow(tstream.getData(*iter * test.GetD() + w) - node->Lchild->leftDown[w], 2);
								dis2 += pow(tstream.getData(*iter * test.GetD() + w) - node->Lchild->rightUp[w], 2);
							}
							dis1 = sqrt(dis1);
							dis2 = sqrt(dis2);
							dis1 < dis2 ? min2 = dis1 : min2 = dis2;
							if (min2 <= min1 && min2 != 0)
							{
								min1 = min2;
								nodeQueue.push(node->Lchild);
							}
						}
						if (node->Rchild)
						{
							float min2 = 0x3f3f3f3f;
							float dis1 = 0;
							float dis2 = 0;
							for (int w = 0; w < test.GetD(); w++)
							{
								dis1 += pow(tstream.getData(*iter * test.GetD() + w) - node->Rchild->leftDown[w], 2);
								dis2 += pow(tstream.getData(*iter * test.GetD() + w) - node->Rchild->rightUp[w], 2);
							}
							dis1 = sqrt(dis1);
							dis2 = sqrt(dis2);
							dis1 < dis2 ? min2 = dis1 : min2 = dis2;
							if (min2 <= min1 && min2 != 0)
							{
								min1 = min2;
								nodeQueue.push(node->Rchild);
							}
						}

					}

					if (R != -1)
					{
						a.order = *iter;
						a.neighbor = R;
						std::pair<std::map<float, Point>::iterator, bool> ret1;
						ret1 = myMap_dis.insert(make_pair(min, a));
						while (!ret1.second)
						{
							ret1 = myMap_dis.insert(make_pair(min + step1, a));
							step1 += 0.000001;
						}
					}
				}
			}


			p = p->Lchild;
		}
		else
		{
			p = stack.top();
			stack.pop();

			p = p->Rchild;
		}
	}

	int num = 0;
	p = root;
	num += 48;
	while (p || !stack.empty())
	{
		if (p != NULL)
		{
			num += 48;

			stack.push(p);

			if (p->Lchild == NULL && p->Rchild == NULL)
			{
				num += 44;
				num += p->order.size() * 12;
			}
			p = p->Lchild;
		}
		else
		{

			p = stack.top();
			stack.pop();
			p = p->Rchild;
		}
	}
	for (auto iter = myMap_dis.begin(); iter != myMap_dis.end(); iter++)
	{
		num += 12 * 2;
	}
	cout << num << endl;
}



void Tree::UpdataTStream(TStream& tstream, Test& test)
{
	tstream.SetvecData_tag(test);
	fp4 = fopen("height.txt", "w");
	for (tstream.vecData_tag; tstream.vecData_tag < tstream.GetvecDataLen() / test.GetD(); )
	{
		int height = 1;
		int ceng = 0;
		int no_height = 0;
		int no_objectNumber = 0;
		int objectNumber = 0;
		float step1 = 0.000001;
		long R = -1;
		float min = 0x3f3f3f3f;
		float min1 = 0x3f3f3f3f;
		float dis = 0;
		Point a;

		tstream.vecData_begin += test.GetIn();
		int order = tstream.vecData_tag++;

		TreeNode* node;
		node = root;
		int flag_1 = 0, flag_2 = 0;

		TreeNode* Lastnode;

		if (tstream.vecData_tag % (test.GetWindows() / test.GetD()) == 0)
		{
			for (auto it = myMap_dis.begin(); it != myMap_dis.end(); )
			{
				if (it->second.neighbor < tstream.vecData_begin || it->second.order < tstream.vecData_begin)
				{
					myMap_dis.erase(it++);
				}
				else
				{
					it++;
				}
			}
		}
		if (tstream.vecData_tag % (test.GetTime()) == 0)
		{
			int j = 0;
			for (auto it = myMap_dis.begin(); it != myMap_dis.end(); it++)
			{
				if (j == 10)
					break;
				fprintf(fp3, "Point :%d  Neighbor :%d  Dis :%f\n", it->second.order, it->second.neighbor, it->first);
				j++;
			}
			fprintf(fp3, "\n\n");
		}

		while (node)
		{
			if (node->Lchild == NULL && node->Rchild == NULL)
			{
				Lastnode = node;
				node->order.push_back(order);

				for (auto iter = node->order.begin(); iter != node->order.end(); )
				{
					if (*iter < tstream.vecData_begin)
					{
						node->order.erase(iter++);
						continue;
					}
					objectNumber++;
					dis = 0;
					for (int w = 0; w < test.GetD(); w++)
					{
						dis += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
					}
					dis = sqrt(dis);
					if (dis < min && dis != 0)
					{
						R = *iter;
						min = dis;
					}
					iter++;
				}
				min1 = min;


				queue<TreeNode*> nodeQueue_1;
				nodeQueue_1.push(root);
				TreeNode* node_1;

				while (!nodeQueue_1.empty())
				{
					node_1 = nodeQueue_1.front();
					if (node_1->Lchild == NULL && node_1->Rchild == NULL && node != node_1)
					{
						for (auto iter2 = node_1->order.begin(); iter2 != node_1->order.end(); )
						{
							if (*iter2 < tstream.vecData_begin)
							{
								node_1->order.erase(iter2++);
								continue;
							}
							objectNumber++;
							dis = 0;
							for (int w = 0; w < test.GetD(); w++)
							{
								dis += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter2 * test.GetD() + w), 2);
							}
							dis = sqrt(dis);
							if (dis < min && dis != 0)
							{
								R = *iter2;
								min = dis;
							}
							iter2++;
						}
					}
					nodeQueue_1.pop();
					if (node_1->Lchild)
					{
						float min2 = 0x3f3f3f3f;
						float dis1 = 0;
						float dis2 = 0;
						for (int w = 0; w < test.GetD(); w++)
						{
							dis1 += pow(tstream.getData(order * test.GetD() + w) - node_1->Lchild->leftDown[w], 2);
							dis2 += pow(tstream.getData(order * test.GetD() + w) - node_1->Lchild->rightUp[w], 2);
						}
						dis1 = sqrt(dis1);
						dis2 = sqrt(dis2);
						dis1 < dis2 ? min2 = dis1 : min2 = dis2;
						if (min2 <= min1 && min2 != 0)
						{
							min1 = min2;
							nodeQueue_1.push(node_1->Lchild);
							ceng++;
						}
					}
					if (node_1->Rchild)
					{
						float min2 = 0x3f3f3f3f;
						float dis1 = 0;
						float dis2 = 0;
						for (int w = 0; w < test.GetD(); w++)
						{
							dis1 += pow(tstream.getData(order * test.GetD() + w) - node_1->Rchild->leftDown[w], 2);
							dis2 += pow(tstream.getData(order * test.GetD() + w) - node_1->Rchild->rightUp[w], 2);
						}
						dis1 = sqrt(dis1);
						dis2 = sqrt(dis2);
						dis1 < dis2 ? min2 = dis1 : min2 = dis2;
						if (min2 <= min1 && min2 != 0)
						{
							min1 = min2;
							nodeQueue_1.push(node_1->Rchild);
						}
					}

				}

				if (R == -1)
				{
					TreeNode* father = Lastnode;
					TreeNode* n = Lastnode;
					while (R == -1 && father->Father)
					{
						min = 0x3f3f3f3f;
						dis = 0;
						queue<TreeNode*> nodeQueue2;
						TreeNode* n1;
						n = father;
						father = father->Father;
						if (father->Lchild == n)
						{
							nodeQueue2.push(father->Rchild);
						}
						else if (father->Rchild == n)
						{
							nodeQueue2.push(father->Lchild);
						}

						while (!nodeQueue2.empty())
						{
							n1 = nodeQueue2.front();
							if (n1->Lchild == NULL && n1->Rchild == NULL)
							{
								for (auto iter2 = n1->order.begin(); iter2 != n1->order.end(); )
								{
									if (*iter2 < tstream.vecData_begin)
									{
										n1->order.erase(iter2++);
										continue;
									}
									no_objectNumber++;
									dis = 0;
									for (int w = 0; w < test.GetD(); w++)
									{
										dis += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter2 * test.GetD() + w), 2);
									}
									dis = sqrt(dis);
									if (dis < min && dis != 0)
									{
										R = *iter2;
										min = dis;
									}
									iter2++;
								}
							}
							if (R != -1)
								break;
							nodeQueue2.pop();
							if (n1->Lchild)
							{
								nodeQueue2.push(n1->Lchild);
								no_height++;
								if (n1->Rchild)
								{
									nodeQueue2.push(n1->Rchild);
									no_height++;
								}
							}
						}
					}

					if (R != -1)
					{
						a.order = order;
						a.neighbor = R;
						std::pair<std::map<float, Point>::iterator, bool> ret1;
						ret1 = myMap_dis.insert(make_pair(min, a));
						while (!ret1.second)
						{
							ret1 = myMap_dis.insert(make_pair(min + step1, a));
							step1 += 0.000001;
						}
					}

					if (node->order.size() > 2 * NUM)
					{


						int r = node->r;
						vector<float> t;
						for (auto it = node->order.begin(); it != node->order.end(); )
						{
							if (*it < tstream.vecData_begin)
							{
								node->order.erase(it++);
								continue;
							}
							t.push_back(tstream.getData(*it * test.GetD() + r));
							it++;
						}
						nth_element(t.begin(), t.begin() + t.size() / 2, t.end());
						float mid = t[t.size() / 2];


						TreeNode* lchild = new TreeNode;
						TreeNode* rchild = new TreeNode;
						for (auto it1 = node->order.begin(); it1 != node->order.end(); it1++)
						{
							if (*it1 < tstream.vecData_begin)
								continue;
							if (tstream.getData(*it1 * test.GetD() + node->r) < mid)
								lchild->order.push_back(*it1);
							else if (tstream.getData(*it1 * test.GetD() + node->r) >= mid)
								rchild->order.push_back(*it1);
						}

						lchild->leftDown = node->leftDown;
						lchild->rightUp = node->rightUp;
						rchild->leftDown = node->leftDown;
						rchild->rightUp = node->rightUp;

						lchild->rightUp[r] = mid;
						rchild->leftDown[r] = mid;

						lchild->Lchild = NULL;
						lchild->Rchild = NULL;
						rchild->Lchild = NULL;
						rchild->Rchild = NULL;



						r = (r + 1) % test.GetD();
						lchild->r = r;
						rchild->r = r;

						node->Lchild = lchild;

						node->Rchild = rchild;
						lchild->Father = node;
						rchild->Father = node;
						node->order.clear();
					}
					break;
				}

				flag_1 = 0;

				if (node->Lchild)
				{
					for (int w = 0; w < test.GetD(); w++)
					{
						if (tstream.getData(order * test.GetD() + w) >= node->Lchild->leftDown[w] && tstream.getData(order * test.GetD() + w) <= node->Lchild->rightUp[w])
						{
							continue;
						}
						else
						{
							flag_1 = 1;
							break;
						}
					}
					if (flag_1 == 0)
					{
						node = node->Lchild;
						height++;
					}
					else
						node = node->Rchild;
				}
			}
		}
	}
}