#include<iostream>
using namespace std;
#include "TStream.h"
#include "Test.h"
#include "Tree.h"
#include "SourceFile.h"
int main()
{
	FILE* fp3;
	FILE* fp2;
	fp2 = fopen("log-1.txt", "w");

	fp3 = fopen("test.txt", "r");
	clock_t startTime, endTime;
	clock_t s1, s2;
	Test test;
	TStream tstream;
	Tree tree, tree1;
	startTime = clock();
	tstream.setFilData();

	endTime = clock();
	fprintf(fp2, "read   %d   time��%lf S\n", tstream.GetvecDataLen() / 3, (double)(endTime - startTime) / CLOCKS_PER_SEC);
	int n;
	float a;
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			if (j % 5 == 3)
			{
				fscanf(fp3, "%f", &a);
			}
			else
			{
				fscanf(fp3, "%d", &n);
			}
			if (j % 5 == 0)
			{
				test.SetD(n);
			}
			else if (j % 5 == 1)
			{
				test.SetK(n);
			}
			else if (j % 5 == 2)
			{
				test.SetWindows(n);
			}
			else if (j % 5 == 3)
			{
				test.SetIn(a);
			}
			else if (j % 5 == 4)
			{
				test.SetTime(n);
			}
		}
		if (i == 0)
		{
			startTime = clock();
			tstream.setRange(test);
			tree.CreateTree(tstream, test);
			tree.PreOrder(tstream, test);
			endTime = clock();

			cout << "Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;

			tree1 = tree;
			s1 = clock();
			tree.UpdataTStream(tstream, test);


			s2 = clock();
			cout << "UpdataTime = " << (double)(s2 - s1) / CLOCKS_PER_SEC << "s" << endl;
			//fprintf(fp2, "1MB,K=100��%f  S \n", (float)(s2 - s1) / CLOCKS_PER_SEC);
		}
		else
		{
			tstream.vecData_begin = 0;

			Tree tree2 = tree1;

			clock_t s1, s2;

			s1 = clock();
			tree2.UpdataTStream(tstream, test);
			s2 = clock();
			cout << "UpdataTime = " << (float)(s2 - s1) / CLOCKS_PER_SEC << "s" << endl;


			fprintf(fp2, "1MB,K=200��%f  S \n", (float)(s2 - s1) / CLOCKS_PER_SEC);
		}
	}
}