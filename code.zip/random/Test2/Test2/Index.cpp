#include "Index.h"
#include <iostream>
using namespace std;

void Index::PrintOut()
{
	vector<int> point;
	for (auto it = vecHash.begin(); it != vecHash.end(); it++)
	{
		point.clear();
		GetPoint(*it, point);
		fprintf(fp2, "side-length   %f   count   %d   \n", it->side, (int)point.size());
	}
	fprintf(fp2, "\n\n\n");
}

void Index::SetTIME(int time)
{
	TIME = time;
}

long Index::Findaddr(TStream& tstream, int order, int d, vector<float>& vecLeftCoordinate, float len, int n)
{
	long addr = 0;
	for (int k1 = 0; k1 < d; k1++)
	{

		int temp = (tstream.getData(order * d + k1) - vecLeftCoordinate[k1]) / (len);
		addr = (addr << n) | temp;
	}
	return addr;
}

long Index::Findaddr(TStream& tstream, int order, int d, vector<float>& vecLeftCoordinate, vector<float>& min, float len, int n)
{
	long addr = 0;
	for (int w = 0; w < d; w++)
	{
		long temp = ((tstream.getData(order * d + w) - min[w]) / len);
		vecLeftCoordinate[w] = temp * len;
		addr = (addr << n) | temp;
	}
	return addr;
}

void Index::FindPointIndex(int d, int v[], int n, vector<long>& pointIndex, long addr)
{
	pointIndex.clear();
	for (int z1 = 0; z1 < pow(3, d); z1++)
	{
		long t = addr;
		for (int z2 = 0; z2 < d; z2++)
		{
			long temp = v[z1 * d + z2];
			temp = (temp << n * (d - z2 - 1));
			t = t + temp;
		}
		if (t >= 0)
		{
			pointIndex.push_back(t);
		}
	}
}

void Index::SetHashbucket(long addr, vector<list<HashTable>>& Hashbucket, int order)
{
	int flag;
	int t = addr % (Hashbucket.size());
	if (Hashbucket[t].size() == 0)
	{
		HashTable x;
		Hashbucket[t].push_back(x);
		Hashbucket[t].front().addr = addr;
		Hashbucket[t].front().order.push_back(order);
	}
	else
	{
		flag = 0;

		for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
		{
			if (addr == iter->addr)
			{
				iter->order.push_back(order);
				flag = 1;
				break;
			}
		}
		if (flag == 0)
		{
			HashTable x;
			x.addr = addr;
			x.order.push_back(order);
			Hashbucket[t].push_back(x);
		}
	}
}

void Index::HandelMap(TStream& tstream, Test test, vector<long>& pointIndex, long addr, Hash& h, int order)
{
	vector<float> dimensionMin = tstream.getLeftCoordinate();
	vector<float> vecLeftCoordinate(3);
	long index = 0;
	float distance = 0;
	float min = 0x3f3f3f3f;
	int R = -1;
	Point a;
	bool flag;
	for (int h1 = 0; h1 < pointIndex.size(); h1++)
	{
		addr = pointIndex[h1] % (vecHash.rbegin()->HashBucket.size());
		if (vecHash.rbegin()->HashBucket[addr].size() == 0)
		{
			continue;
		}
		for (auto iter1 = vecHash.rbegin()->HashBucket[addr].begin(); iter1 != vecHash.rbegin()->HashBucket[addr].end(); iter1++)
		{
			if (pointIndex[h1] == iter1->addr)
			{
				for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
				{
					if (*iter == order)
					{
						continue;
					}
					for (int w = 0; w < test.GetD(); w++)
					{
						distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
					}
					distance = sqrt(distance);
					if (distance < min)
					{
						R = *iter;
						min = distance;
					}
				}
			}
		}
	}

	if (R != -1)
	{
		flag = 0;
		int i = 0;
		for (auto iter = myMap_dis.begin(); iter != myMap_dis.end(); iter++)
		{
			if (R == iter->second.order && order == iter->second.neighbor)
			{
				return;
			}
			if (iter->first == min)
			{
				min += i * 0.000001;
				a.order = order;
				a.neighbor = R;
				myMap_dis[min] = a;
				return;
			}
			i++;
		}
		a.order = order;
		a.neighbor = R;
		myMap_dis[min] = a;
	}
	else
		return;
}


void Index::SetHashbucket(Test test, long addr, vector<list<HashTable>>& Hashbucket)
{
	int flag;
	int t = addr % (Hashbucket.size());
	if (Hashbucket[t].size() == 0)
	{
		HashTable x;
		Hashbucket[t].push_back(x);
		Hashbucket[t].front().addr = addr;
		Hashbucket[t].front().order.push_back(-1);
		Hashbucket[t].front().pointNum++;
	}
	else
	{
		flag = 0;

		for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
		{
			if (addr == iter->addr)
			{
				iter->pointNum++;
				flag = 1;
				break;
			}
		}
		if (flag == 0)
		{
			HashTable x;
			x.addr = addr;
			x.order.push_back(-1);
			x.pointNum++;
			Hashbucket[t].push_back(x);
		}
	}
}

void Index::SetHashbucket_Reduce(Test test, long addr, vector<list<HashTable>>& Hashbucket)
{
	int t = addr % (Hashbucket.size());
	for (auto iter = Hashbucket[t].begin(); iter != Hashbucket[t].end(); iter++)
	{
		if (addr == iter->addr)
		{
			if (iter->pointNum == 0)
				return;
			iter->pointNum--;
			if (iter->pointNum == 0 && iter->order.front() == -1)
			{
				Hashbucket[t].erase(iter);
			}
			break;
		}
	}
}

void Index::GetPoint(Hash& vecHash, vector<int>& point)
{
	point.reserve(vecHash.HashBucket.size() / 2);
	for (auto iter2 = vecHash.HashBucket.begin(); iter2 != vecHash.HashBucket.end(); iter2++)
	{
		if (iter2->size() == 0)
		{
			continue;
		}
		for (auto iter1 = iter2->begin(); iter1 != iter2->end(); iter1++)
		{
			for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
			{
				if (*iter >= 0)
					point.push_back(*iter);
			}
		}
	}
}


void Index::HandelPointIndex(TStream& tstream, Test test, vector<long>& pointIndex, long addr, vector<list<HashTable>>& Hashbucket, int order, float side, vector<int>& vecPoint, int vecPoint_begin, int vecPoint_end)
{
	int R = -1;
	bool flag = 0;
	long addr1 = 0;
	for (int h1 = 0; h1 < pointIndex.size(); h1++)
	{
		addr = pointIndex[h1] % (Hashbucket.size());
		if (Hashbucket[addr].size() == 0)
		{
			continue;
		}
		for (auto iter1 = Hashbucket[addr].begin(); iter1 != Hashbucket[addr].end(); iter1++)
		{
			if (pointIndex[h1] == iter1->addr)
			{
				for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
				{
					if (*iter == order)
					{
						addr1 = pointIndex[h1];
						continue;
					}
					float distance = 0;
					for (int w = 0; w < test.GetD(); w++)
					{
						distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
					}
					distance = sqrt(distance);
					if (distance == 0)
						continue;
					if (distance < side && order != *iter)
					{
						vecPoint.push_back(*iter);
						R = *iter;
						if (iter1->order.size() == 1)
						{
							Hashbucket[addr].erase(iter1);
							iter1 = Hashbucket[addr].begin();
							break;
						}
						else
						{
							iter1->order.remove(*iter);
							iter = iter1->order.begin();
							if (iter1->order.size() == 0)
							{
								break;
							}
							continue;
						}
					}
				}

				if (Hashbucket[addr].size() == 0)
				{
					break;
				}
			}
		}
	}

	if (R != -1)
	{
		for (int i = vecPoint_end - 1; i < vecPoint.size(); i++)
		{
			if (vecPoint[i] == order)
			{
				flag = 1;
				break;
			}
		}
		if (flag == 0)
		{
			vecPoint.push_back(order);
		}
		addr1 = addr1 % Hashbucket.size();
		for (auto iter1 = Hashbucket[addr1].begin(); iter1 != Hashbucket[addr1].end(); iter1++)
		{
			for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
			{
				if (*iter == order)
				{
					if (iter1->order.size() == 1)
					{
						Hashbucket[addr1].erase(iter1);
						return;
					}
					else
					{
						iter1->order.remove(*iter);
						return;
					}
				}
			}
		}
	}
}

void Index::FindNeighbor(TStream& tstream, Test& test, float side, vector<int>& vecPoint, int& vecPoint_begin, int& vecPoint_end)
{
	vector<float> vecLeftCoordinate(3);
	vector<float> dimensionMin = tstream.getLeftCoordinate();;
	vector<long> pointIndex;
	int order;
	vector<int> point;
	long index = 0;
	long addr = 0;
	int n = ceil(log2(tstream.getLength() / (side)));
	for (int i = vecPoint_begin; i < vecPoint.size(); i++)
	{
		order = vecPoint[i];

		addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, dimensionMin, side, n);

		if (addr < 0)
			continue;


		FindPointIndex(test.GetD(), vecV, n, pointIndex, addr);

		HandelPointIndex(tstream, test, pointIndex, addr, Hashbucket, order, side, vecPoint, vecPoint_begin, vecPoint_end);
	}
}


void Index::HandelPointIndex_Updata(TStream& tstream, Test test, vector<long>& pointIndex, long addr, Hash& h, int order, float& distance, int& flag)
{
	long R = -1;
	float min = 0x3f3f3f3f;

	vector<float> dimensionMin = tstream.getLeftCoordinate();
	vector<float> vecLeftCoordinate(3);

	for (int h1 = 0; h1 < pointIndex.size(); h1++)
	{
		addr = pointIndex[h1] % (h.HashBucket.size());
		if (h.HashBucket[addr].size() == 0)
		{
			continue;
		}
		for (auto iter1 = h.HashBucket[addr].begin(); iter1 != h.HashBucket[addr].end(); iter1++)
		{
			if (pointIndex[h1] == iter1->addr)
			{
				if (iter1->pointNum > 0)
				{
					flag = 1;
				}
				for (auto iter = iter1->order.begin(); iter != iter1->order.end(); iter++)
				{
					if (*iter == -1)
					{
						continue;
					}
					if (*iter < tstream.vecData_begin)
					{
						//c.n--
						for (auto iter3 = vecHash.begin(); iter3 != vecHash.end(); iter3++)
						{
							if (iter3->side == h.side)
								break;
							int n = ceil(log2(tstream.getLength() / (iter3->side)));
							long addr1 = Findaddr(tstream, *iter, test.GetD(), dimensionMin, iter3->side, n);
							SetHashbucket_Reduce(test, addr1, iter3->HashBucket);
						}
						if (iter1->order.size() == 1)
						{
							h.HashBucket[addr].erase(iter1);
							iter1 = h.HashBucket[addr].begin();
							break;
						}
						else
						{
							iter1->order.remove(*iter);
							iter = iter1->order.begin();
							if (iter1->order.size() == 0)
							{
								break;
							}
							continue;
						}
					}
					else
					{
						for (int w = 0; w < test.GetD(); w++)
						{
							distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(*iter * test.GetD() + w), 2);
						}
						distance = sqrt(distance);
						if (distance < min)
						{
							R = *iter;
							min = distance;
						}
					}
				}
				if (h.HashBucket[addr].size() == 0)
				{
					break;
				}
			}
		}
	}

	if (R == -1)
	{
		min = h.side;
	}
	distance = min;
}

void Index::Init(TStream& tstream, Test test)
{
	fp2 = fopen("log.txt", "w");
	vector<int> vecPoint;
	int vecPoint_begin = 0;
	int vecPoint_end;
	vector<float> leftCoordinate = tstream.getLeftCoordinate();
	for (int i = 0; i < test.GetWindows() / test.GetD(); i++)
	{
		vecPoint.push_back(i);
	}
	vecPoint_end = vecPoint.size();


	while (vecPoint_end - vecPoint_begin >= 1000)
	{
		long R = -1;
		int order = 0;
		float min = 0x3f3f3f3f;

		for (int i = vecPoint_begin; i < vecPoint_end; i++)
		{
			if (vecPoint[i] != -1)
			{
				order = vecPoint[i];
				break;
			}
		}

		for (int i = vecPoint_begin; i < vecPoint.size(); i++)
		{
			float distance = 0;
			if (vecPoint[i] == -1 || order == vecPoint[i])
				continue;
			for (int w = 0; w < test.GetD(); w++)
			{
				distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(vecPoint[i] * test.GetD() + w), 2);
			}
			distance = sqrt(distance);
			if (distance == 0 && order != vecPoint[i])
			{
				vecPoint[i] = -1;
				continue;
			}
			if (distance < min)
			{
				R = vecPoint[i];
				min = distance;
			}
		}

		float side = min;
		int n = ceil(log2(tstream.getLength() / side));
		if (n < 0)
			break;
		Hashbucket.clear();
		Hashbucket.resize((vecPoint_end - vecPoint_begin) * 2);
		for (int i = vecPoint_begin; i < vecPoint.size(); i++)
		{
			long addr = Findaddr(tstream, vecPoint[i], test.GetD(), leftCoordinate, side, n);
			if (addr < 0)
				continue;
			SetHashbucket(addr, Hashbucket, vecPoint[i]);
		}

		FindNeighbor(tstream, test, side, vecPoint, vecPoint_begin, vecPoint_end);
		Hash hash;
		hash.HashBucket = Hashbucket;
		hash.side = side;
		vecHash.push_back(hash);

		vecPoint_begin = vecPoint_end;
		vecPoint_end = vecPoint.size();
	}

	if (vecPoint_end - vecPoint_begin != 0)
	{
		long R = -1;
		int order = vecPoint[vecPoint_begin];
		float min = 0x3f3f3f3f;
		for (int i = vecPoint_begin + 1; i < vecPoint.size(); i++)
		{
			float distance = 0;
			for (int w = 0; w < test.GetD(); w++)
			{
				distance += pow(tstream.getData(order * test.GetD() + w) - tstream.getData(vecPoint[i] * test.GetD() + w), 2);
			}
			distance = sqrt(distance);
			if (distance < min && distance != 0)
			{
				R = vecPoint[i];
				min = distance;
			}
		}

		float side = min;
		int n = ceil(log2(tstream.getLength() / side));
		Hashbucket.clear();
		Hashbucket.resize((vecPoint_end - vecPoint_begin));

		for (int i = vecPoint_begin; i < vecPoint.size(); i++)
		{
			long addr = Findaddr(tstream, vecPoint[i], test.GetD(), leftCoordinate, side, n);
			if (addr < 0)
				continue;
			SetHashbucket(addr, Hashbucket, vecPoint[i]);
		}
		Hash hash;
		hash.HashBucket = Hashbucket;
		hash.side = side;
		vecHash.push_back(hash);

	}

	tstream.vecData_tag = test.GetWindows() / test.GetD();

}


void Index::FindIndex(TStream& tstream, Test test)
{
	fp3 = fopen("out.txt", "w");
	int order = 0;
	vector<float> dimensionMin = tstream.getLeftCoordinate();
	long addr = 0;
	vector<int> point;
	for (auto iter3 = vecHash.rbegin(); iter3 != vecHash.rend(); iter3++)
	{
		GetPoint(*iter3, point);
		for (int i = 0; i < point.size(); i++)
		{
			if (point[i] >= 0)
			{
				order = point[i];
				auto t = iter3;
				for (auto iter0 = ++t; iter0 != vecHash.rend(); iter0++)
				{
					int n = ceil(log2(tstream.getLength() / (iter0->side)));
					addr = Findaddr(tstream, order, test.GetD(), dimensionMin, iter0->side, n);
					if (addr < 0)
						continue;
					SetHashbucket(test, addr, iter0->HashBucket);
				}
			}
		}
		point.clear();
	}

	int num = 0;
	for (auto iter = vecHash.begin(); iter != vecHash.end(); iter++)
	{
		num += 8;
		for (auto iter1 = iter->HashBucket.begin(); iter1 != iter->HashBucket.end(); iter1++)
		{
			if (iter1->size() == 0)
			{
				num += 4;
			}
			for (auto iter2 = iter1->begin(); iter2 != iter1->end(); iter2++)
			{
				num += 8;
				num += iter2->order.size() * 12;
				num += 4;
				num += 8;
			}
		}
	}
	cout << num << endl;
}


void Index::UpdataTStream(TStream& tstream, Test test)
{

	tstream.SetvecData_tag(test);
	int order;
	long addr = 0;
	vector<float> dimensionMin = tstream.getLeftCoordinate();
	vector<float> vecLeftCoordinate(3);
	vector<long> pointIndex;
	long index = 0;
	float distance;
	int flag;
	vector<int> point;
	GetPoint(*vecHash.rbegin(), point);
	fprintf(fp2, "��ѯ����Ϊ   %d   ʱ����ʼ��ʱ���ϣ���������\n", test.GetTime());
	PrintOut();

	clock_t startTime, endTime;

	int windows = 0;

	for (int i = 0; i < point.size(); i++)
	{
		long R = -1;
		float min = 0x3f3f3f3f;
		float distance = 0;
		order = point[i];

		int n = ceil(log2(tstream.getLength() / (vecHash.rbegin()->side)));
		if (n < 0)
			continue;

		addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, dimensionMin, vecHash.rbegin()->side, n);

		if (addr < 0)
			continue;


		FindPointIndex(test.GetD(), vecV, n, pointIndex, addr);

		HandelMap(tstream, test, pointIndex, addr, *vecHash.rbegin(), order);
	}

	for (int i = test.GetWindows() / test.GetD(); i < tstream.GetvecDataLen() / test.GetD(); i++)//��������
	{
		tstream.vecData_begin += test.GetIn();
		order = tstream.vecData_tag++;
		int overDueOrder = tstream.vecData_begin - test.GetIn();
		if (tstream.vecData_tag % (test.GetWindows() / test.GetD()) == 1)
		{
			startTime = clock();
		}
		if (tstream.vecData_tag % (test.GetWindows() / test.GetD()) == 0)
		{

			endTime = clock();
			fprintf(fp2, "������%d������ʱ,��ϣ���������������   %fS\n", ++windows, (double)(endTime - startTime) / CLOCKS_PER_SEC);
			PrintOut();
		}


		if (tstream.vecData_tag % TIME == 0)
		{
			int z = 0;
			for (auto it = myMap_dis.begin(); it != myMap_dis.end(); it++)
			{
				if (z == TIME)
					break;
				fprintf(fp3, "Point :%d  Neighbor :%d  Dis :%f\n", it->second.order, it->second.neighbor, it->first);
				z++;
			}
			fprintf(fp3, "\n\n");
		}


		for (auto it = myMap_dis.begin(); it != myMap_dis.end(); )
		{
			if (it->second.neighbor < tstream.vecData_begin || it->second.order < tstream.vecData_begin)
			{
				myMap_dis.erase(it++);
			}
			else
			{
				it++;
			}
		}

		for (int k = overDueOrder; k < tstream.vecData_begin; k++)
		{
			int flag_1 = 0;
			int flag_2 = 0;
			for (auto it = vecHash.begin(); it != vecHash.end(); it++)
			{
				if (it->side == vecHash.rbegin()->side)
					break;
				int n = ceil(log2(tstream.getLength() / (it->side)));
				long addr1 = Findaddr(tstream, k, test.GetD(), dimensionMin, it->side, n);
				if (addr1 < 0)
					continue;
				SetHashbucket_Reduce(test, addr1, it->HashBucket);
			}


			for (auto it = vecHash.begin(); it != vecHash.end(); it++)
			{
				int n = ceil(log2(tstream.getLength() / (it->side)));
				long addr1 = Findaddr(tstream, k, test.GetD(), dimensionMin, it->side, n);
				if (addr1 < 0)
					continue;
				long addr = addr1 % it->HashBucket.size();
				for (auto it1 = it->HashBucket[addr].begin(); it1 != it->HashBucket[addr].end(); it1++)
				{
					if (it1->addr == addr1)
					{
						for (auto iter = it1->order.begin(); iter != it1->order.end(); iter++)
						{
							if (*iter == k)
							{
								if (it1->order.size() == 1 && it1->pointNum != 0)
								{
									it1->order.erase(iter);
									it1->order.push_back(-1);
									flag_1 = 1;
									break;
								}
								else if (it1->order.size() == 1 && it1->pointNum == 0)
								{
									it->HashBucket[addr].erase(it1);
									flag_1 = 1;
									break;
								}
								else
								{
									it1->order.erase(iter);
									flag_1 = 1;
									break;
								}
							}
						}
						if (flag_1 == 1)
						{
							flag_2 = 1;
							break;
						}
					}
				}
				if (flag_2 == 1)
				{
					break;
				}
			}
		}

		for (auto iter = vecHash.begin(); iter != vecHash.end(); iter++)//�������е�����
		{
			distance = 0;
			flag = 0;
			int n = ceil(log2(tstream.getLength() / (iter->side)));
			addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, dimensionMin, iter->side, n); \

				if (addr < 0)
					continue;

			FindPointIndex(test.GetD(), vecV, n, pointIndex, addr);

			HandelPointIndex_Updata(tstream, test, pointIndex, index, *iter, order, distance, flag);

			if (flag == 0)
			{
				break;
			}
		}


		for (auto iter = vecHash.begin(); iter != vecHash.end(); iter++)
		{
			if (iter->side <= distance)
			{
				if (iter->side == vecHash.rbegin()->side)
				{
					int n = ceil(log2(tstream.getLength() / (vecHash.rbegin()->side)));
					if (n < 0)
						continue;

					addr = Findaddr(tstream, order, test.GetD(), vecLeftCoordinate, dimensionMin, vecHash.rbegin()->side, n);

					if (addr < 0)
						continue;



					FindPointIndex(test.GetD(), vecV, n, pointIndex, addr);

					HandelMap(tstream, test, pointIndex, addr, *vecHash.rbegin(), order);
				}

				int n = ceil(log2(tstream.getLength() / (iter->side)));
				addr = Findaddr(tstream, order, test.GetD(), dimensionMin, iter->side, n);
				if (addr < 0)
					continue;
				SetHashbucket(addr, iter->HashBucket, order);
				break;
			}
		}
	}
}

