#pragma once
#pragma once
#include "TStream.h"
#include <list>
#include <map>
#include <fstream>
#include <ctime>
#pragma warning(disable:4996)��
class Index
{
public:
	struct HashTable
	{
		long addr;
		list<int> order;
		int pointNum = 0;
	};
	struct Hash
	{
		vector<list<HashTable>> HashBucket;
		float side;
	};
	struct Point
	{
		int order;
		int neighbor;
	};
	void Init(TStream& tstream, Test test);
	long Findaddr(TStream& tstream, int order, int d, vector<float>& vecLeftCoordinate, float len, int n);
	long Findaddr(TStream& tstream, int order, int d, vector<float>& vecLeftCoordinate, vector<float>& min, float len, int n);
	void FindPointIndex(int d, int v[], int n, vector<long>& pointIndex, long addr);
	void SetHashbucket(long addr, vector<list<HashTable>>& Hashbucket, int order);
	void HandelMap(TStream& tstream, Test test, vector<long>& pointIndex, long addr, Hash& h, int order);
	void HandelPointIndex(TStream& tstream, Test test, vector<long>& pointIndex, long addr, vector<list<HashTable>>& Hashbucket, int order, float side, vector<int>& vecPoint, int vecPoint_begin, int vecPoint_end);
	void FindNeighbor(TStream& tstream, Test& test, float side, vector<int>& vecPoint, int& vecPoint_begin, int& vecPoint_end);
	void FindIndex(TStream& tstream, Test test);
	void SetHashbucket(Test test, long addr, vector<list<HashTable>>& Hashbucket);
	void SetHashbucket_Reduce(Test test, long addr, vector<list<HashTable>>& Hashbucket);
	void GetPoint(Hash& vecHash, vector<int>& point);
	void UpdataTStream(TStream& tstream, Test test);
	void HandelPointIndex_Updata(TStream& tstream, Test test, vector<long>& pointIndex, long addr, Hash& h, int order, float& distance, int& flag);
	void PrintOut();
	void SetTIME(int time);

private:
	FILE* fp2;
	FILE* fp3;
	int TIME;
	vector<list<HashTable>> Hashbucket;
	list<Hash> vecHash;
	map<float, Point> myMap_dis;
	int vecV[81] = { 0,0,0,0,0,-1,0,0,1,0,-1,0,0,-1,-1,0,-1,1,0,1,0,0,1,-1,0,1,1,
					1,0,0,1,0,-1,1,0,1,1,-1,0,1,-1,-1,1,-1,1,1,1,0,1,1,-1,1,1,1,
					-1,0,0,-1,0,-1,-1,0,1,-1,-1,0,-1,-1,-1,-1,-1,1,-1,1,0,-1,1,-1,-1,1,1 };
};

