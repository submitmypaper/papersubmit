#include "SourceFile.h"



SourceFile::SourceFile()
{
}


SourceFile::~SourceFile()
{
}


void SourceFile::SetWindows(int i, float a)
{
	source_Windows[i] = a;
}


void SourceFile::SetD(int d)
{
	source_d = d;
}

void SourceFile::SetTag(long tag)
{
	source_Tag = tag;
}

void SourceFile::SetStart(long start)
{
	source_Start = start;
}


double SourceFile::GetWindows(long i)
{
	return source_Windows[i];
}


int SourceFile::GetD()
{
	return source_d;
}


long SourceFile::GetTag()
{
	return source_Tag;
}

long SourceFile::GetStart()
{
	return source_Start;
}

