#pragma once
#include "TStream.h"
#include "Test.h"
#include "Index.h"
#include <fstream>
#include <ctime>
#include <iostream>
using namespace std;
#pragma warning(disable:4996)��
int main()
{

	FILE* fp3;
	FILE* fp2;
	fp2 = fopen("log��־.txt", "w");

	Test test;
	fp3 = fopen("test.txt", "r");
	clock_t startTime, endTime;

	TStream tstream;
	startTime = clock();
	tstream.setFilData();
	endTime = clock();
	Index index1;

	fprintf(fp2, "��ȡ   %d   �����ݵ�ʱ��Ϊ��%lf S\n", tstream.GetvecDataLen() / 3, (double)(endTime - startTime) / CLOCKS_PER_SEC);
	int n;
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			fscanf(fp3, "%d", &n);
			if (j % 5 == 0)
			{
				test.SetD(n);
			}
			else if (j % 5 == 1)
			{
				test.SetK(n);
			}
			else if (j % 5 == 2)
			{
				test.SetWindows(n);
			}
			else if (j % 5 == 3)
			{
				test.SetIn(n);
			}
			else if (j % 5 == 4)
			{
				test.SetTime(n);
			}
		}
		if (i == 0)
		{
			tstream.vecData_begin = 0;
			tstream.setRange(test);

			Index index;
			startTime = clock();
			index.Init(tstream, test);
			endTime = clock();
			fprintf(fp2, "��ʼ����ʱ��Ϊ��%f S\n", (float)(endTime - startTime) / CLOCKS_PER_SEC);
			cout << "Time = " << (float)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;

			index1 = index;
			startTime = clock();
			index.UpdataTStream(tstream, test);
			endTime = clock();
			fprintf(fp2, "���ڴ�СΪ1MB��TIMEΪ100ʱʱ����ʱ��Ϊ��%f  S \n", (float)(endTime - startTime) / CLOCKS_PER_SEC);
			cout << "UpdataTime = " << (float)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;

		}
		else
		{
			tstream.vecData_begin = 0;
			clock_t s1, s2;

			Index index2 = index1;
			s1 = clock();
			index2.UpdataTStream(tstream, test);
			s2 = clock();
			cout << "UpdataTime = " << (float)(s2 - s1) / CLOCKS_PER_SEC << "s" << endl;


			fprintf(fp2, "���ڴ�СΪ1MB��TIMEΪ100ʱʱ����ʱ��Ϊ��%f  S \n", (float)(s2 - s1) / CLOCKS_PER_SEC);

		}


	}

}