#include "Index.h"
#include <random>
#include <iostream>
#include <math.h>
void Index::Init(TStream& tstream, Test test)
{
	fp2 = fopen("Out.txt", "w");
	float step = 0.000001;
	float step1 = 0.000001;
	for (int i = 0; i < test.GetWindows() / test.GetD(); i++)
	{
		int j = 1;
		int flag = 0;
		vector<float> t;
		for (int h = 1; h < test.GetD() + 1; h++)
		{
			if (h == test.GetD())
			{
				t.push_back(i);
			}
			else
			{
				t.push_back(tstream.getData(i * test.GetD() + h));
			}
		}
		std::pair<std::map<float, vector<float>>::iterator, bool> ret;
		ret = Map_d1.insert(make_pair(tstream.getData(i * test.GetD()), t));
		while (!ret.second)
		{
			ret = Map_d1.insert(make_pair(tstream.getData(i * test.GetD()) + step, t));
			step += 0.000001;
		}
	}
	float max = 0;
	for (int i = 0; i < 5; i++)
	{
		float min = 0x3f3f3f3f;
		int R = -1;
		Point a;
		for (int j = i + 1; j < test.GetWindows() / test.GetD(); j++)
		{
			float distance = 0;
			for (int w = 0; w < test.GetD(); w++)
			{
				distance += pow(tstream.getData(i * test.GetD() + w) - tstream.getData(j * test.GetD() + w), 2);
			}
			distance = sqrt(distance);
			if (distance <= min && distance != 0)
			{
				min = distance;
				R = j;
			}
		}
		if (min > max)
			max = min;
	}

	for (auto it = Map_d1.begin(); it != Map_d1.end(); it++)
	{
		auto iter = Map_d1.lower_bound(it->first);

		float min = max;
		int R = -1;
		Point a;
		float dis = 0;

		
		while (it->first - iter->first < max)
		{
			int flag_1 = 0;
			dis = 0;
			
			if (iter == Map_d1.begin())
			{
				dis += pow(iter->first - it->first, 2);
				for (int i = 0; i < iter->second.size() - 1; i++)
				{
					dis += pow(it->second[i] - iter->second[i], 2);
					if (dis > pow(max, 2))
					{
						flag_1 = 1;
						break;
					}
				}
				if (flag_1 == 1)
					break;
				dis = sqrt(dis);
				if (dis < min && dis != 0)
				{
					min = dis;
					R = *iter->second.rbegin();
				}
				break;
			}
			dis += pow(iter->first - it->first, 2);
			for (int i = 0; i < iter->second.size() - 1; i++)
			{
				dis += pow(it->second[i] - iter->second[i], 2);
				if (dis > pow(max, 2))
				{
					flag_1 = 1;
					break;
				}
			}
			if (flag_1 == 1)
			{
				iter--;
				continue;
			}
			dis = sqrt(dis);
			if (dis < min && dis != 0)
			{
				min = dis;
				R = *iter->second.rbegin();
			}
			iter--;
		}

		
		while (iter->first - it->first < max)
		{
			int flag_1 = 0;
			dis = 0;
			if (*iter == *Map_d1.rbegin())
			{
				dis += pow(iter->first - it->first, 2);
				for (int i = 0; i < iter->second.size() - 1; i++)
				{
					dis += pow(iter->second[i] - it->second[i], 2);
					if (dis > pow(max, 2))
					{
						flag_1 = 1;
						break;
					}
				}
				if (flag_1 == 1)
					break;
				dis = sqrt(dis);
				if (dis < min && dis != 0)
				{
					min = dis;
					R = *iter->second.rbegin();
				}
				break;
			}
			dis += pow(iter->first - it->first, 2);
			for (int i = 0; i < iter->second.size() - 1; i++)
			{
				dis += pow(iter->second[i] - it->second[i], 2);
				if (dis > pow(max, 2))
				{
					flag_1 = 1;
					break;
				}
			}
			if (flag_1 == 1)
			{
				iter++;
				continue;
			}

			dis = sqrt(dis);
			if (dis < min && dis != 0)
			{
				min = dis;
				R = *iter->second.rbegin();
			}
			iter++;
		}

		if (R != -1)
		{
			a.order = *it->second.rbegin();
			a.neighbor = R;
			std::pair<std::map<float, Point>::iterator, bool> ret1;
			ret1 = myMap_dis.insert(make_pair(min, a));
			while (!ret1.second)
			{
				ret1 = myMap_dis.insert(make_pair(min + step1, a));
				step1 += 0.000001;
			}
		}
	}
	cout << "asd";
}

void Index::UpdataTStream(TStream& tstream, Test test)
{
	tstream.SetvecData_tag(test);
	fprintf(fp2, "Time:%d\n", test.GetTime());
	float first = myMap_dis.rbegin()->first;
	for (int i = tstream.vecData_tag; i < tstream.GetvecDataLen() / test.GetD(); i++)
	{
		tstream.vecData_begin += test.GetIn(); 
		int order = tstream.vecData_tag++;
		int R = -1;
		float min;
		Point a;
		vector<float> temp;
		clock_t s1, s2;
		float step = 0.000001;
		float step1 = 0.000001;


		if (tstream.vecData_tag % test.GetTime() == 0)
		{
			   
			for (auto it = myMap_dis.begin(); it != myMap_dis.end(); )
			{
				if (it->second.neighbor < tstream.vecData_begin || it->second.order < tstream.vecData_begin)
				{
					myMap_dis.erase(it++);
				}
				else
				{
					it++;
				}
			}
			int x = 0;
			for (auto it = myMap_dis.begin(); it != myMap_dis.end(); it++)
			{
				if (x == 10)
					break;
				fprintf(fp2, "Point :%d  Neighbor :%d  Dis :%f\n", it->second.order, it->second.neighbor, it->first);
				x++;
			}
			fprintf(fp2, "\n\n");
		}

		for (int j = tstream.vecData_begin - test.GetIn(); j < tstream.vecData_begin; j++)
		{
			Map_d1.erase(tstream.getData(j * test.GetD()));
		}

		for (int h = 1; h < test.GetD() + 1; h++)
		{
			if (h == test.GetD())
			{
				temp.push_back(order);
			}
			else
			{
				temp.push_back(tstream.getData(order * test.GetD() + h));
			}
		}
		

		std::pair<std::map<float, vector<float>>::iterator, bool> ret;
		ret = Map_d1.insert(make_pair(tstream.getData(order * test.GetD()), temp));
		while (!ret.second)
		{
			ret = Map_d1.insert(make_pair(tstream.getData(order * test.GetD()) + step, temp));
			step += 0.000001;
		}

		float d1 = tstream.getData(order * test.GetD());
		auto iter = Map_d1.lower_bound(d1);
		float max = myMap_dis.rbegin()->first;
		if (myMap_dis.size() < (test.GetWindows() / test.GetD()) / 2)
			max = first;
		min = max;
		R = -1;
		float dis = 0;

		
		while (d1 - iter->first < max)
		{
			int flag_1 = 0;
			dis = 0;
			
			if (iter == Map_d1.begin())
			{
				dis += pow(d1 - iter->first, 2);
				for (int i = 0; i < iter->second.size() - 1; i++)
				{
					dis += pow(tstream.getData(order * test.GetD() + i + 1) - iter->second[i], 2);
					if (dis > pow(max, 2))
					{
						flag_1 = 1;
						break;
					}
				}
				if (flag_1 == 1)
					break;
				dis = sqrt(dis);
				if (dis < min && dis != 0 && order != *iter->second.rbegin())
				{
					min = dis;
					R = *iter->second.rbegin();
				}
				break;
			}
			dis += pow(d1 - iter->first, 2);
			for (int i = 0; i < iter->second.size() - 1; i++)
			{
				dis += pow(tstream.getData(order * test.GetD() + i + 1) - iter->second[i], 2);
				if (dis > pow(max, 2))
				{
					flag_1 = 1;
					break;
				}
			}
			if (flag_1 == 1)
			{
				iter--;
				continue;
			}
				
			dis = sqrt(dis);
			if (dis < min && dis != 0 && order != *iter->second.rbegin())
			{
				min = dis;
				R = *iter->second.rbegin();
			}
			iter--;
		}

		
		while (iter->first - d1 < max)
		{
			int flag_1 = 0;
			dis = 0;
			
			if (*iter == *Map_d1.rbegin())
			{
				dis += pow(iter->first - d1, 2);
				for (int i = 0; i < iter->second.size() - 1; i++)
				{
					dis += pow(tstream.getData(order * test.GetD() + i + 1) - iter->second[i], 2);
					if (dis > pow(max, 2))
					{
						flag_1 = 1;
						break;
					}
				}
				if (flag_1 == 1)
					break;
				dis = sqrt(dis);
				if (dis < min && dis != 0 && order != *iter->second.rbegin())
				{
					min = dis;
					R = *iter->second.rbegin();
				}
				break;
			}
			dis += pow(d1 - iter->first, 2);
			for (int i = 0; i < iter->second.size() - 1; i++)
			{
				dis += pow(tstream.getData(order * test.GetD() + i + 1) - iter->second[i], 2);
				if (dis > pow(max, 2))
				{
					flag_1 = 1;
					break;
				}
			}
			if (flag_1 == 1)
			{
				iter++;
				continue;
			}
			dis = sqrt(dis);
			if (dis < min && dis != 0 && order != *iter->second.rbegin())
			{
				min = dis;
				R = *iter->second.rbegin();
			}
			iter++;
		}

		if (R != -1)
		{
			a.order = *iter->second.rbegin();
			a.neighbor = R;
			std::pair<std::map<float, Point>::iterator, bool> ret1;
			ret1 = myMap_dis.insert(make_pair(min, a));
			while (!ret1.second)
			{
				ret1 = myMap_dis.insert(make_pair(min + step1, a));
				step1 += 0.000001;
			}
		}
	}
}
