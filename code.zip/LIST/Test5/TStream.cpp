#include "TStream.h"
#include <fstream>
#include <iostream>
using namespace std;
#pragma warning(disable:4996)��
#include <cmath>

TStream::TStream()
{
}


TStream::~TStream()
{
}

float TStream::getData(int ID)
{
	return vecData[ID];
}

long TStream::GetvecDataLen()
{
	return vecData.size();
}

void TStream::setRange(Test test)
{
	int dimension = test.GetD();
	int pointNum = test.GetWindows() / dimension;
	int tag = 0;
	for (int i = 0; i < pointNum; i++)
	{
		for (int j = 0; j < dimension; j++)
		{
			if (i == 0)
			{
				dimensionMax.push_back(vecData[tag]);
				dimensionMin.push_back(vecData[tag]);
			}
			else
			{

				if (dimensionMax[j] < vecData[tag])
				{
					dimensionMax[j] = vecData[tag];
				}
				if (dimensionMin[j] > vecData[tag])
				{
					dimensionMin[j] = vecData[tag];
				}
			}
			tag++;
		}
	}
	leftCoordinate = dimensionMin;
	float max = 0;
	for (int i = 0; i < dimension; i++)
	{
		if (i == 0)
		{
			max = dimensionMax[i] - dimensionMin[i];
		}
		else
		{
			if (max < dimensionMax[i] - dimensionMin[i])
			{
				max = dimensionMax[i] - dimensionMin[i];
			}
		}
	}
	max = ceil(max);
	length = max;
}

vector<float> TStream::getLeftCoordinate()
{
	return leftCoordinate;
}

void TStream::InitPoint(Test test)
{
	PointNeighbor t;
	for (int i = 0; i < test.GetWindows() / test.GetD(); i++)
	{
		t.neighbor = -1;
		t.distance = 0x3f3f3f3f;
		pointNeighbor.push_back(t);
	}
}

float TStream::getLength()
{
	return length;
}

void TStream::SetvecData_tag(Test test)
{
	vecData_tag = test.GetWindows() / test.GetD();
}





void TStream::setFilData()
{
	FILE* fp1;
	float n;
	if ((fp1 = fopen("SourceFile.txt", "r")) != NULL)
	{
		while (fscanf(fp1, "%f", &n) != EOF)
		{
			vecData.push_back(n);
		}
	}
}

void TStream::setPointNeighbor(Test test)
{
	pointNeighbor.resize(test.GetWindows() / test.GetD());
	for (int i = 0; i < test.GetWindows() / test.GetD(); i++)
	{
		pointNeighbor[i].order = i;
	}
}



