#pragma once
#include <vector>
#include "Test.h"
using namespace std;
class TStream
{
public:
	TStream();
	~TStream();

	void setFilData();

	void setPointNeighbor(Test test);

	float getData(int ID);

	long GetvecDataLen();

	void setRange(Test test);
	vector<float> getLeftCoordinate();

	void InitPoint(Test test);
	float getLength();
	struct PointNeighbor
	{
		int order;
		int neighbor;
		float distance;

		bool operator < (const PointNeighbor& P)const
		{
			return distance < P.distance;
		}
	};
	vector<PointNeighbor> pointNeighbor;
	long vecData_begin = 0;
	long vecData_tag = 0;
	void SetvecData_tag(Test test);
private:
	vector<float> vecData;
	vector<float> leftCoordinate;
	vector<float> dimensionMax;
	vector<float> dimensionMin;
	float length;

};

