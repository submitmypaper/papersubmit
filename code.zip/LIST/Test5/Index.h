#pragma once
#include "Test.h"
#include "TStream.h"
#include<map>
#pragma warning(disable:4996)��

using namespace std;
class Index
{
	struct Point
	{
		int order;
		int neighbor;
	};
			
public:
	void Init(TStream& tstream, Test test);
	void UpdataTStream(TStream& tstream, Test test);
private:
	map<float, Point> myMap_dis;
	map<float, vector<float>> Map_d1;
	FILE* fp2;

};

