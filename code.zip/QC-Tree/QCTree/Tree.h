#pragma once
#include <vector>
#include <list>
#include <queue>
#include <map>
#include "TStream.h"
#include "Test.h"
class Tree
{
public:
	struct Grid
	{
		int n;
		double sideLength;
	};
	struct TreeNode
	{
		long addr = 0;
		vector<int> vecObject;
		list<TreeNode*> lstPointer;
		TreeNode* fatherNode;
		vector<double> vecLeftDown;
		vector<double> vecRightUp;
		double sideLength;
		int height;
		int objecNumber = 0;
		int rootId;               
		Grid grid;			  	 
	};
	struct HashIndex
	{
		long addr;
		int rootId;
		list<int> lstObject;
		int objectNumber = 0;
		vector<double> vecLeftDown;
		vector<double> vecRightUp;
	};
	Grid StructGrid(double tstreamLength, int objectNumber, int dimension, double sideLength);
	void StructHashBucket(TStream& tstream, Test& test, Grid& grid, vector<int>& vecObject);
	long FindObjectAddr(TStream& tstream, int objId, int d, Grid& grid, vector<double>& vecLeftDown, vector<double>& vecRightUp);
	long FindObjectAddrIndex(TStream& tstream, int objId, int d, Grid& grid);
	bool HashBucketPushBack(long addr, int objId, vector<double>& vecLeftDown, vector<double>& vecRightUp, int rootId);
	void RootInit(TStream& tstream, Test& test, Grid& grid);
	void CreateTreeRoot(TStream& tstream, Test& test);
	void TreeNodeSplit(TStream& tstream, Test& test, TreeNode* node);
	HashIndex GetHashIndex(TStream& tstream, Test& test, int objId, int rootId, Grid& grid);
	TreeNode* CreateCubeNewTreeNode(TStream& tstream, Test& test, TreeNode* node, HashIndex hashIndex);
	void TreeNodeCubePushBack(TStream& tstream, Test& test, TreeNode* node, HashIndex hashIndex, int d);
	long Findaddr(TStream& tstream, int objNo, int d, vector<double>& vecLeftDown, vector<double>& newVecLeftDown, vector<double>& vecRightUp, vector<double>& newVecRightUp, double side);
	void TreeNodePushBack(int objNo, int objectNumber, long addr, TreeNode* node, vector<double>& newVecLeftDown, vector<double>& newVecRightUp);
	void CreateTree(TStream& tstream, Test& test);


	int  FindNeighbor(TStream& tstream, Test& test, int objId, double side, double& distance, int tstreamBegin);
	void InsertMapCandidateSet(int objId, int neighbor, double distance);
	double GetQueryRadiusInThis(TStream& tstream, Test& test, int objId, vector<int> vecObject, int& neighbor);
	double GetQueryRadiusInOther(TStream& tstream, Test& test, int objId, TreeNode* fatherNode, int& neighbor);
	double GetDistanceFromOtherNode(TStream& tstream, Test& test, int objId, vector<double>& vecLeftDown, vector<double>& vecRightUp);
	void PreOrderTree(TStream& tstream, Test& test);

	void TreeNodeSplitUpdata(TStream& tstream, Test& test, TreeNode* node);
	void PrintMapCandidateSet(Test& test, int tstreamBegin);
	void TreeNodeInsert(TStream& tstream, Test& test, int objId, double& side);
	void UpdataCandidateSet(int tstreamBegin);
	void TreeNodeBatchSplit(TStream& tstream, Test& test);
	void TreeNodeBatchDelete(TStream& tstream, Test& test, int tstreamBegin);
	void CreateCube(TStream& tstream, Test& test, TreeNode* node);
	void UpdataCreateTree(TStream& tstream, Test& test, TreeNode* node);
	void UpdataTreeNodeSplit(TStream& tstream, Test& test, queue<TreeNode*>& queBatchSplit);
	void UpdateDataFlow(TStream& tstream, Test& test,double &time);


private:
	struct Pair
	{
		int objId;
		int neighborId;
	};
	vector<list<HashIndex>> vecHashBucket;
	int rootID = 0;
	TreeNode* root;
	map<double, Pair> mapCandidateSet;
	FILE* fp1;
};

