#include "TStream.h"
#include <cmath>
TStream::TStream()
{
}

TStream::~TStream()
{
}

void TStream::ReadDataFile()
{
	FILE* fp1;
	double dlNumber;
	double maxData = 0;
	double step = 0.05;
	int objectNumber = 0;
	if ((fp1 = fopen("SourceFile.txt", "r")) != NULL)
	{
		while (fscanf(fp1, "%lf", &dlNumber) != EOF)
		{
			if (dlNumber > 1000)
			{
				continue;
			}
			objectNumber++;

			dlNumber = dlNumber + step;
			step += 0.05;
			if (step >= 5)
				step = 0.05;

			if (objectNumber >= 18862080 * 3 && objectNumber <= 20910080 * 3)
				continue;

			if (objectNumber >= 21729280 * 3 && objectNumber <= 22650880 * 3)
				continue;

			if (maxData < dlNumber)
				maxData = dlNumber;
			vecDataStream.push_back(dlNumber);

			if (objectNumber >= 27258880 * 3)
			{
				cout << "�������" << objectNumber/3 << endl;
				break;
			}
		}
	}
	length = maxData;
	length = pow(2, ceil(log2(length)));
	cout << "�������ֵ" << length << endl;
}

double TStream::GetDataStream(int intObjectNumber)
{
	return vecDataStream[intObjectNumber];
}

int TStream::GetDataStreamLength()
{
	return vecDataStream.size();
}



double TStream::GetLength()
{
	return length;
}

int TStream::GetDataStreamBegin()
{
	return dataStreamBegin;
}

int TStream::GetDataStreamTag()
{
	return dataStreamTag;
}

void TStream::SetDataStreamBegin(int begin)
{
	dataStreamBegin = begin;
}

void TStream::SetDataStreamTag(int tag)
{
	dataStreamTag = tag;
}

void TStream::Init(Test test)
{
	ReadDataFile();
	SetDataStreamBegin(0);
}

void TStream::AddDataStreamBegin(int outflow)
{
	dataStreamBegin += outflow;
}

void TStream::AddDataStreamTag(int inflow)
{
	dataStreamTag += inflow;
}
