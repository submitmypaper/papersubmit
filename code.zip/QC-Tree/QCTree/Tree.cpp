#include "Tree.h"
#include<cmath>
#include <stack>
#define NUM 1
void Tree::StructHashBucket(TStream& tstream, Test& test, Grid& grid, vector<int>& vecObject)
{

	vector<double> vecLeftDown;
	vector<double> vecRightUp;
	long addr = -1;
	vecHashBucket.clear();
	vecHashBucket.resize(vecObject.size());
	vecLeftDown.resize(test.GetDimension());
	vecRightUp.resize(test.GetDimension());
	for (int i = 0; i < vecObject.size(); i++)
	{
		addr = FindObjectAddr(tstream, vecObject[i], test.GetDimension(), grid, vecLeftDown, vecRightUp);
		HashBucketPushBack(addr, vecObject[i], vecLeftDown, vecRightUp, rootID);
	}
}


long Tree::FindObjectAddr(TStream& tstream, int objId, int d, Grid& grid, vector<double>& vecLeftDown, vector<double>& vecRightUp)
{
	long addr = 0;
	for (int i = 0; i < d; i++)
	{
		long temp = (tstream.GetDataStream(objId * d + i)) / grid.sideLength;
		vecLeftDown[i] = temp * grid.sideLength;
		vecRightUp[i] = vecLeftDown[i] + grid.sideLength;
		addr = (addr << grid.n) | temp;
	}
	return addr;
}

long Tree::FindObjectAddrIndex(TStream& tstream, int objId, int d, Grid& grid)
{
	long addr = 0;
	for (int i = 0; i < d; i++)
	{
		long temp = (tstream.GetDataStream(objId * d + i)) / grid.sideLength;
		addr = (addr << grid.n) | temp;
	}
	return addr;
}


bool Tree::HashBucketPushBack(long addr, int objId, vector<double>& vecLeftDown, vector<double>& vecRightUp, int rootId)
{
	bool flag = 0;
	int key = addr % vecHashBucket.size();
	if (vecHashBucket[key].size() == 0)
	{
		HashIndex x;
		vecHashBucket[key].push_back(x);
		vecHashBucket[key].front().addr = addr;
		vecHashBucket[key].front().lstObject.push_back(objId);
		vecHashBucket[key].front().vecLeftDown = vecLeftDown;
		vecHashBucket[key].front().vecRightUp = vecRightUp;
		vecHashBucket[key].front().objectNumber++;
		vecHashBucket[key].front().rootId = rootId;
	}
	else
	{
		for (auto iter = vecHashBucket[key].begin(); iter != vecHashBucket[key].end(); iter++)
		{
			if (addr == iter->addr && iter->rootId == rootId)
			{
				iter->lstObject.push_back(objId);
				iter->objectNumber++;
				flag = 1;
				break;
			}
		}
		if (flag == 0)
		{
			HashIndex temp;
			temp.addr = addr;
			temp.lstObject.push_back(objId);
			temp.objectNumber++;
			temp.vecLeftDown = vecLeftDown;
			temp.vecRightUp = vecRightUp;
			temp.rootId = rootId;
			vecHashBucket[key].push_back(temp);
		}
	}
	return flag;
}


Tree::Grid Tree::StructGrid(double tstreamLength, int objectNumber, int dimension, double sideLength)
{
	Grid grid;
	grid.n = ceil(log2(pow(objectNumber, (double)1 / dimension)));
	grid.sideLength = sideLength / pow(2, grid.n);
	grid.n = log2(tstreamLength / grid.sideLength);
	return grid;
}

void Tree::RootInit(TStream& tstream, Test& test, Grid& grid)
{
	root = new TreeNode;
	for (int i = 0; i < vecHashBucket.size(); i++)
	{
		for (auto iterLstHash = vecHashBucket[i].begin(); iterLstHash != vecHashBucket[i].end(); iterLstHash++)
		{
			root->vecObject.push_back(*iterLstHash->lstObject.begin());
			root->objecNumber += iterLstHash->lstObject.size();
		}
	}
	for (int i = 0; i < test.GetDimension(); i++)
	{
		root->vecLeftDown.push_back(0);
		root->vecRightUp.push_back(tstream.GetLength());
	}
	root->sideLength = tstream.GetLength();
	root->height = 0;
	root->rootId = rootID;
	root->fatherNode = NULL;
	root->grid = grid;
}

void Tree::CreateTreeRoot(TStream& tstream, Test& test)
{

	vector<double> vecGridLeftDonw;
	vector<int>vecObject;
	vecGridLeftDonw.resize(test.GetDimension());
	for (int i = 0; i < test.GetWindowSize() / test.GetDimension(); i++)
	{
		vecObject.push_back(i);
	}
	Grid grid = StructGrid(tstream.GetLength(), test.GetWindowSize() / test.GetDimension(), test.GetDimension(), tstream.GetLength());
	StructHashBucket(tstream, test, grid, vecObject);
	RootInit(tstream, test, grid);

}

void Tree::TreeNodeSplit(TStream& tstream, Test& test, TreeNode* node)
{
	long addr = 0;
	vector<double> newVecLeftDown;
	vector<double> newVecRightUp;
	HashIndex hashTemp = {};
	double branchNumber = pow(2, test.GetDimension());
	if (node->sideLength <= node->grid.sideLength)
	{
		for (auto iterVecObj = node->vecObject.begin(); iterVecObj != node->vecObject.end(); iterVecObj++)
		{
			addr = Findaddr(tstream, *iterVecObj, test.GetDimension(), node->vecLeftDown, newVecLeftDown, node->vecRightUp, newVecRightUp, node->sideLength / 2);
			TreeNodePushBack(*iterVecObj, 1, addr, node, newVecLeftDown, newVecRightUp);
		}
	}
	else
	{
		for (auto iterVecObj = node->vecObject.begin(); iterVecObj != node->vecObject.end(); iterVecObj++)
		{

			hashTemp = GetHashIndex(tstream, test, *iterVecObj, node->rootId, node->grid);
			if ((double)node->objecNumber > pow(2, test.GetDimension() + 1) && hashTemp.objectNumber > (double)node->objecNumber / branchNumber && hashTemp.objectNumber != node->objecNumber)
			{
				TreeNodeCubePushBack(tstream, test, node, hashTemp, test.GetDimension());
				continue;
			}
			addr = Findaddr(tstream, *iterVecObj, test.GetDimension(), node->vecLeftDown, newVecLeftDown, node->vecRightUp, newVecRightUp, node->sideLength / 2);
			TreeNodePushBack(*iterVecObj, hashTemp.lstObject.size(), addr, node, newVecLeftDown, newVecRightUp);
		}
	}
	node->vecObject.clear();
}

Tree::HashIndex Tree::GetHashIndex(TStream& tstream, Test& test, int objId, int rootId, Grid& grid)
{
	long addr = -1;
	long key = -1;
	addr = FindObjectAddrIndex(tstream, objId, test.GetDimension(), grid);
	key = addr % vecHashBucket.size();
	for (auto iterLstHashIndex = vecHashBucket[key].begin(); iterLstHashIndex != vecHashBucket[key].end(); iterLstHashIndex++)
	{
		if (iterLstHashIndex->addr == addr && iterLstHashIndex->rootId == rootId)
		{
			return *iterLstHashIndex;
		}
	}
}

Tree::TreeNode* Tree::CreateCubeNewTreeNode(TStream& tstream, Test& test, TreeNode* node, HashIndex hashIndex)
{
	TreeNode* newNode = new TreeNode;

	newNode->addr = -1;
	newNode->fatherNode = node;
	newNode->height = node->height + 1;
	newNode->objecNumber = hashIndex.objectNumber;
	newNode->sideLength = hashIndex.vecRightUp[0] - hashIndex.vecLeftDown[0];
	newNode->vecLeftDown = hashIndex.vecLeftDown;
	newNode->vecRightUp = hashIndex.vecRightUp;
	newNode->rootId = ++rootID;
	return newNode;
}

void Tree::TreeNodeCubePushBack(TStream& tstream, Test& test, TreeNode* node, HashIndex hashIndex, int d)
{
	long addr = -1;
	vector<double> vecLeftDown;
	vector<double> vecRightUp;
	vecLeftDown.resize(test.GetDimension());
	vecRightUp.resize(test.GetDimension());

	TreeNode* newNode = CreateCubeNewTreeNode(tstream, test, node, hashIndex);

	newNode->grid = StructGrid(tstream.GetLength(), newNode->objecNumber, d, newNode->sideLength);

	for (auto iterLstObject = hashIndex.lstObject.begin(); iterLstObject != hashIndex.lstObject.end(); iterLstObject++)
	{
		addr = FindObjectAddr(tstream, *iterLstObject, test.GetDimension(), newNode->grid, vecLeftDown, vecRightUp);
		if (!HashBucketPushBack(addr, *iterLstObject, vecLeftDown, vecRightUp, newNode->rootId))
			newNode->vecObject.push_back(*iterLstObject);
	}

	node->lstPointer.push_back(newNode);
}

long Tree::Findaddr(TStream& tstream, int objNo, int d, vector<double>& vecLeftDown, vector<double>& newVecLeftDown, vector<double>& vecRightUp, vector<double>& newVecRightUp, double side)
{
	newVecLeftDown = vecLeftDown;
	newVecRightUp = vecRightUp;
	long addr = 0;
	int temp = 0;
	for (int i = 0; i < d; i++)
	{
		temp = (tstream.GetDataStream(objNo * d + i) - vecLeftDown[i]) / side;
		newVecLeftDown[i] = vecLeftDown[i] + temp * side;
		newVecRightUp[i] = newVecLeftDown[i] + side;
		addr = (addr << 1) | temp;
	}
	return addr;
}

void Tree::TreeNodePushBack(int objNo, int objectNumber, long addr, TreeNode* node, vector<double>& newVecLeftDown, vector<double>& newVecRightUp)
{
	bool flag = 0;
	for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
	{
		if ((*iterLstPointer)->addr == addr)
		{
			flag = 1;
			(*iterLstPointer)->vecObject.push_back(objNo);
			(*iterLstPointer)->objecNumber += objectNumber;
		}
	}
	if (flag == 0)
	{
		TreeNode* newnode = new TreeNode;
		newnode->vecObject.push_back(objNo);
		newnode->addr = addr;
		newnode->vecLeftDown = newVecLeftDown;
		newnode->vecRightUp = newVecRightUp;
		newnode->height = node->height + 1;
		newnode->sideLength = node->sideLength / 2;
		newnode->fatherNode = node;
		newnode->objecNumber += objectNumber;
		newnode->rootId = node->rootId;
		newnode->grid = node->grid;
		node->lstPointer.push_back(newnode);
	}
}

void Tree::CreateTree(TStream& tstream, Test& test)
{
	CreateTreeRoot(tstream, test);
	queue<TreeNode*> queCreateTree;
	queCreateTree.push(root);
	HashIndex hashTemp = {};
	while (!queCreateTree.empty())
	{
		if (queCreateTree.front()->sideLength <= tstream.GetLength() / 1024 / 1024 / 1024)
		{
			hashTemp = GetHashIndex(tstream, test, *queCreateTree.front()->vecObject.begin(), queCreateTree.front()->rootId, queCreateTree.front()->grid);
			for (auto iterLstObject = hashTemp.lstObject.begin(); iterLstObject != hashTemp.lstObject.end(); iterLstObject++)
			{
				if (iterLstObject == hashTemp.lstObject.begin())
					continue;
				queCreateTree.front()->vecObject.push_back(*iterLstObject);
			}
			queCreateTree.pop();
			continue;
		}
		if (queCreateTree.front()->sideLength == queCreateTree.front()->grid.sideLength)
		{

			hashTemp = GetHashIndex(tstream, test, *queCreateTree.front()->vecObject.begin(), queCreateTree.front()->rootId, queCreateTree.front()->grid);
			for (auto iterLstObject = hashTemp.lstObject.begin(); iterLstObject != hashTemp.lstObject.end(); iterLstObject++)
			{
				if (iterLstObject == hashTemp.lstObject.begin())
					continue;
				queCreateTree.front()->vecObject.push_back(*iterLstObject);
			}
		}

		TreeNodeSplit(tstream, test, queCreateTree.front());

		for (auto iterLstPointer = queCreateTree.front()->lstPointer.begin(); iterLstPointer != queCreateTree.front()->lstPointer.end(); iterLstPointer++)
		{
			if ((*iterLstPointer)->objecNumber > NUM)
			{
				queCreateTree.push(*iterLstPointer);
			}
		}
		queCreateTree.pop();
	}
}

int Tree::FindNeighbor(TStream& tstream, Test& test, int objId, double side, double& distance, int tstreamBegin)
{
	double minPair = 0x3f3f3f3f;
	int neighbor = -1;
	TreeNode* node;
	queue<TreeNode*> queLevelOrder;
	queLevelOrder.push(root);


	while (!queLevelOrder.empty())
	{
		node = queLevelOrder.front();

		if (node->lstPointer.size() == 0 && node->vecObject.size() > 0)
		{
			for (auto iterLstObject = node->vecObject.begin(); iterLstObject != node->vecObject.end(); )
			{
				distance = 0;
				if (*iterLstObject < tstreamBegin)
				{
					iterLstObject = node->vecObject.erase(iterLstObject);
					continue;
				}
				for (int i = 0; i < test.GetDimension(); i++)
				{
					distance += pow(tstream.GetDataStream(objId * test.GetDimension() + i) - tstream.GetDataStream(*iterLstObject * test.GetDimension() + i), 2);
				}
				distance = sqrt(distance);
				if (distance < minPair && distance != 0 && *iterLstObject != objId)
				{
					neighbor = *iterLstObject;
					minPair = distance;
				}
				iterLstObject++;
			}
		}

		queLevelOrder.pop();

		for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
		{
			bool flagInBox = 1;
			for (int i = 0; i < test.GetDimension(); i++)
			{
				if (tstream.GetDataStream(objId * test.GetDimension() + i) >= (*iterLstPointer)->vecLeftDown[i] && tstream.GetDataStream(objId * test.GetDimension() + i) <= (*iterLstPointer)->vecRightUp[i])
				{
					continue;
				}
				else
				{
					flagInBox = 0;
					break;
				}
			}
			if (flagInBox == 1)
			{
				queLevelOrder.push(*iterLstPointer);
				continue;
			}

			double minDistance = 0;
			minDistance = GetDistanceFromOtherNode(tstream, test, objId, (*iterLstPointer)->vecLeftDown, (*iterLstPointer)->vecRightUp);
			if (minDistance <= side)
			{
				queLevelOrder.push(*iterLstPointer);
			}
		}

	}
	distance = minPair;
	return neighbor;
}

void Tree::InsertMapCandidateSet(int objId, int neighbor, double distance)
{
	double step = 0.000001;
	Pair temp, temp1;
	temp.objId = objId;
	temp.neighborId = neighbor;
	std::pair<std::map<double, Pair>::iterator, bool> ret1;
	ret1 = mapCandidateSet.insert(make_pair(distance, temp));
	temp1 = mapCandidateSet[distance];
	while (!ret1.second)
	{
		if (temp1.objId == temp.neighborId && temp1.neighborId == temp.objId)
			return;
		else
		{
			ret1 = mapCandidateSet.insert(make_pair(distance + step, temp));
			step += 0.000001;
		}
	}
}

double Tree::GetQueryRadiusInThis(TStream& tstream, Test& test, int objId, vector<int> vecObject, int& neighbor)
{
	double distance = 0;
	double minPair = 0x3f3f3f3f;
	for (auto iterLstObject = vecObject.begin(); iterLstObject != vecObject.end(); iterLstObject++)
	{
		distance = 0;
		if (*iterLstObject < tstream.GetDataStreamBegin())
			continue;
		for (int i = 0; i < test.GetDimension(); i++)
		{
			distance += pow(tstream.GetDataStream(objId * test.GetDimension() + i) - tstream.GetDataStream(*iterLstObject * test.GetDimension() + i), 2);
		}
		distance = sqrt(distance);
		if (distance < minPair && distance != 0)
		{
			neighbor = *iterLstObject;
			minPair = distance;
		}
	}
	if (minPair == 0x3f3f3f3f)
		return -1;
	return minPair;
}

double Tree::GetQueryRadiusInOther(TStream& tstream, Test& test, int objId, TreeNode* fatherNode, int& neighbor)
{
	queue<TreeNode*> queGetQueryRadius;
	queGetQueryRadius.push(fatherNode);
	TreeNode* node;
	TreeNode* minNode;
	double pairDistance = 0x3f3f3f3f;
	double minPairDistance = 0x3f3f3f3f;
	double minDistanceNode = 0x3f3f3f3f;
	double distanceNode = 0;
	while (!queGetQueryRadius.empty())
	{
		node = queGetQueryRadius.front();
		if (node->lstPointer.size() == 0 && node->vecObject.size() > 0)
		{
			pairDistance = GetQueryRadiusInThis(tstream, test, objId, node->vecObject, neighbor);
			break;
		}
		queGetQueryRadius.pop();
		for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
		{
			bool flagInBox = 1;
			for (int i = 0; i < test.GetDimension(); i++)
			{
				if (tstream.GetDataStream(objId * test.GetDimension() + i) >= (*iterLstPointer)->vecLeftDown[i] && tstream.GetDataStream(objId * test.GetDimension() + i) < (*iterLstPointer)->vecRightUp[i])
				{
					continue;
				}
				else
				{
					flagInBox = 0;
					break;
				}
			}
			if (flagInBox == 1 && (*iterLstPointer)->vecObject.size() == 1)
			{
				continue;
			}
			distanceNode = 0;
			distanceNode = GetDistanceFromOtherNode(tstream, test, objId, (*iterLstPointer)->vecLeftDown, (*iterLstPointer)->vecRightUp);
			if (distanceNode < minDistanceNode)
			{
				queGetQueryRadius.push(*iterLstPointer);
				break;
			}
		}
	}
	if (pairDistance == -1)
		return -1;
	if (pairDistance == 0x3f3f3f3f)
		return -1;
	return pairDistance;
}

double Tree::GetDistanceFromOtherNode(TStream& tstream, Test& test, int objId, vector<double>& vecLeftDown, vector<double>& vecRightUp)
{
	double distanceLeft = 0;
	double disRight = 0;
	double minDistance = 0x3f3f3f3f;
	for (int i = 0; i < test.GetDimension(); i++)
	{
		distanceLeft += pow(tstream.GetDataStream(objId * test.GetDimension() + i) - vecLeftDown[i], 2);
		disRight += pow(tstream.GetDataStream(objId * test.GetDimension() + i) - vecRightUp[i], 2);
	}
	distanceLeft = sqrt(distanceLeft);
	disRight = sqrt(disRight);
	distanceLeft < disRight ? minDistance = distanceLeft : minDistance = disRight;
	return minDistance;
}

void Tree::PreOrderTree(TStream& tstream, Test& test)
{
	fp1 = fopen("log.txt", "w");
	stack<TreeNode*> stkPreOrder;
	int neighbor = -1;
	double distance = 0;
	double step1 = 0.000001;
	TreeNode* orderPointer = root;
	mapCandidateSet.clear();
	double queryRadius = 0;
	if (orderPointer != NULL)
		stkPreOrder.push(orderPointer);
	while (!stkPreOrder.empty())
	{
		orderPointer = stkPreOrder.top();
		stkPreOrder.pop();
		if (orderPointer->lstPointer.size() == 0)
		{
			if (orderPointer->vecObject.size() > 1)
			{
				for (auto iterObject = orderPointer->vecObject.begin(); iterObject != orderPointer->vecObject.end(); iterObject++)
				{
					queryRadius = GetQueryRadiusInThis(tstream, test, *iterObject, orderPointer->vecObject, neighbor);
					if (queryRadius == -1)
						queryRadius = orderPointer->sideLength;
					neighbor = -1;
					neighbor = FindNeighbor(tstream, test, *iterObject, queryRadius, distance, 0);
					if (neighbor != -1)
						InsertMapCandidateSet(*iterObject, neighbor, distance);
				}
			}
			else if (orderPointer->vecObject.size() == 1)
			{
				int neighbor1 = -1;
				queryRadius = GetQueryRadiusInOther(tstream, test, *orderPointer->vecObject.begin(), (*orderPointer).fatherNode, neighbor1);

				if (queryRadius == -1)
				{
					queryRadius = 2 * sqrt(test.GetDimension()) * orderPointer->sideLength;
				}
				neighbor = -1;
				neighbor = FindNeighbor(tstream, test, *orderPointer->vecObject.begin(), queryRadius, distance, 0);
				if (neighbor != -1)
					InsertMapCandidateSet(*orderPointer->vecObject.begin(), neighbor, distance);
				else
					InsertMapCandidateSet(*orderPointer->vecObject.begin(), neighbor1, queryRadius);
			}
			continue;
		}
		for (auto iterLstPointer = orderPointer->lstPointer.begin(); iterLstPointer != orderPointer->lstPointer.end(); iterLstPointer++)
		{
			stkPreOrder.push(*iterLstPointer);
		}
	}

	PrintMapCandidateSet(test, 0);
}


void Tree::TreeNodeSplitUpdata(TStream& tstream, Test& test, TreeNode* node)
{
	long addr = 0;
	vector<double> newVecLeftDown;
	vector<double> newVecRightUp;

	for (auto iterVecObj = node->vecObject.begin(); iterVecObj != node->vecObject.end(); iterVecObj++)
	{
		addr = Findaddr(tstream, *iterVecObj, test.GetDimension(), node->vecLeftDown, newVecLeftDown, node->vecRightUp, newVecRightUp, node->sideLength / 2);
		TreeNodePushBack(*iterVecObj, 1, addr, node, newVecLeftDown, newVecRightUp);
	}
	node->vecObject.clear();
}

void Tree::PrintMapCandidateSet(Test& test, int tstreamBegin)
{
	int k = 0;
	for (auto iterMapCandidateSet = mapCandidateSet.begin(); iterMapCandidateSet != mapCandidateSet.end(); iterMapCandidateSet++)
	{
		if (k == 10)
		{
			fprintf(fp1, "\n\n\n");
			break;
		}
		if (iterMapCandidateSet->second.objId < tstreamBegin || iterMapCandidateSet->second.neighborId < tstreamBegin)
		{
			continue;
		}
		fprintf(fp1, "Object:%d          Neighbor%d          Distance��%lf\n", iterMapCandidateSet->second.objId, iterMapCandidateSet->second.neighborId, iterMapCandidateSet->first);
		k++;
	}
}

void Tree::TreeNodeInsert(TStream& tstream, Test& test, int objId, double& side)
{
	double branchNumber = pow(2, test.GetDimension());
	queue<TreeNode*> queSplit;

	bool flagInsert = 0;
	bool flagInCube = 1;
	TreeNode* node = NULL;
	TreeNode* nodeTemp = NULL;
	queue<TreeNode*> queInsert;
	queInsert.push(root);
	double distance = 0;
	double minPair = 0x3f3f3f3f;
	while (!queInsert.empty())
	{
		node = queInsert.front();

		if (node->lstPointer.size() == 0)
		{
			for (auto iterVecObject = node->vecObject.begin(); iterVecObject != node->vecObject.end(); )
			{
				if (*iterVecObject < tstream.GetDataStreamBegin())
				{
					iterVecObject = node->vecObject.erase(iterVecObject);
					node->objecNumber--;
					node->fatherNode->objecNumber--;
				}
				else
				{
					iterVecObject++;
				}
			}

			node->vecObject.push_back(objId);
			node->objecNumber++;
			node->fatherNode->objecNumber++;

			if (node->vecObject.size() == 1)
			{
				int neighbor1 = -1;
				minPair = GetQueryRadiusInOther(tstream, test, *node->vecObject.begin(), (*node).fatherNode, neighbor1);

				if (minPair == -1)
				{
					minPair = node->sideLength;
				}
			}
			else//Ҷ���еĶ������>1
			{

				int neighbor1 = -1;
				minPair = GetQueryRadiusInThis(tstream, test, objId, node->vecObject, neighbor1);
				if (minPair == -1)
					minPair = node->sideLength;
				if (node->vecObject.size() > branchNumber)
				{
					queSplit.push(node);
					UpdataTreeNodeSplit(tstream, test, queSplit);
				}
			}
			flagInsert = 1;
			side = minPair;
			return;
		}

		queInsert.pop();

		flagInCube = 1;
		for (auto iterLstPointer = node->lstPointer.begin(); iterLstPointer != node->lstPointer.end(); iterLstPointer++)
		{
			bool flagInBox = 1;
			for (int i = 0; i < test.GetDimension(); i++)
			{
				if (tstream.GetDataStream(objId * test.GetDimension() + i) >= (*iterLstPointer)->vecLeftDown[i] && tstream.GetDataStream(objId * test.GetDimension() + i) < (*iterLstPointer)->vecRightUp[i])
				{
					continue;
				}
				else
				{
					flagInBox = 0;
					break;
				}
			}
			if (flagInBox == 1 && (*iterLstPointer)->addr == -1)
			{
				flagInCube = 1;
				queInsert.push(*iterLstPointer);
				break;
			}
			else if (flagInBox == 1 && (*iterLstPointer)->addr != -1)
			{
				flagInCube = 0;
				nodeTemp = *iterLstPointer;
			}
		}
		if (flagInCube == 0)
		{
			queInsert.push(nodeTemp);
		}
	}


	if (flagInsert == 0)
	{
		node->vecObject.push_back(objId);
		node->objecNumber++;
		if (node->fatherNode != NULL)
			node->fatherNode->objecNumber++;
		TreeNodeSplitUpdata(tstream, test, node);

		int neighbor1 = -1;
		minPair = GetQueryRadiusInOther(tstream, test, objId, node, neighbor1);

		if (minPair == -1)
		{
			minPair = node->sideLength / 2.0;
		}
		side = minPair;
	}
}

void Tree::UpdataCandidateSet(int tstreamBegin)
{
	for (auto iterMapCandidateSet = mapCandidateSet.begin(); iterMapCandidateSet != mapCandidateSet.end(); )
	{
		if (iterMapCandidateSet->second.neighborId < tstreamBegin || iterMapCandidateSet->second.objId < tstreamBegin)
		{
			mapCandidateSet.erase(iterMapCandidateSet++);
		}
		else
		{
			iterMapCandidateSet++;
		}
	}
}

void Tree::TreeNodeBatchSplit(TStream& tstream, Test& test)
{


	HashIndex hashTemp = {};
	double branchNumber = pow(2, test.GetDimension());
	stack<TreeNode*> stkPreOrder;

	TreeNode* orderPointer = root;
	queue<TreeNode*> queBatchSplit;

	if (orderPointer != NULL)
		stkPreOrder.push(orderPointer);
	while (!stkPreOrder.empty())
	{
		orderPointer = stkPreOrder.top();

		stkPreOrder.pop();
		if (orderPointer->lstPointer.size() == 0 && orderPointer->vecObject.size() > NUM)
		{
			queBatchSplit.push(orderPointer);

		}

		for (auto iterLstPointer = orderPointer->lstPointer.begin(); iterLstPointer != orderPointer->lstPointer.end();)
		{
			if ((*iterLstPointer)->lstPointer.size() == 0 && (*iterLstPointer)->vecObject.size() > NUM)
			{
				for (auto iterVecobject = (*iterLstPointer)->vecObject.begin(); iterVecobject != (*iterLstPointer)->vecObject.end(); )
				{
					if (*iterVecobject < tstream.GetDataStreamBegin())
					{
						iterVecobject = (*iterLstPointer)->vecObject.erase(iterVecobject);
						(*iterLstPointer)->objecNumber--;
						(*iterLstPointer)->fatherNode->objecNumber--;
					}
					else
					{
						iterVecobject++;
					}
				}
			}
			if ((*iterLstPointer)->lstPointer.size() == 0 && (*iterLstPointer)->vecObject.size() == 0)
			{
				orderPointer->lstPointer.erase(iterLstPointer++);
			}
			else
				stkPreOrder.push(*iterLstPointer++);
		}
	}
	UpdataTreeNodeSplit(tstream, test, queBatchSplit);
}

void Tree::TreeNodeBatchDelete(TStream& tstream, Test& test, int tstreamBegin)
{
	stack<TreeNode*> stkPreOrder;
	TreeNode* orderPointer = root;
	vector<int> vecAddr;
	if (orderPointer != NULL)
		stkPreOrder.push(orderPointer);
	while (!stkPreOrder.empty())
	{
		orderPointer = stkPreOrder.top();

		stkPreOrder.pop();

		if (orderPointer->lstPointer.size() == 0)
		{
			for (auto iterLstObject = orderPointer->vecObject.begin(); iterLstObject != orderPointer->vecObject.end(); )
			{
				if (*iterLstObject < tstreamBegin)
				{
					iterLstObject = orderPointer->vecObject.erase(iterLstObject);
					orderPointer->objecNumber--;
				}
				else
				{
					iterLstObject++;
				}
			}
			continue;
		}
		for (auto iterLstPointer = orderPointer->lstPointer.begin(); iterLstPointer != orderPointer->lstPointer.end(); iterLstPointer++)
		{
			stkPreOrder.push(*iterLstPointer);
		}
	}
}

void Tree::CreateCube(TStream& tstream, Test& test, TreeNode* node)
{
	Grid grid = StructGrid(tstream.GetLength(), node->vecObject.size(), test.GetDimension(), node->sideLength);
	StructHashBucket(tstream, test, grid, node->vecObject);
	node->vecObject.clear();
	for (int i = 0; i < vecHashBucket.size(); i++)
	{
		for (auto iterLstHash = vecHashBucket[i].begin(); iterLstHash != vecHashBucket[i].end(); iterLstHash++)
		{
			node->vecObject.push_back(*iterLstHash->lstObject.begin());
		}
	}
	node->grid = grid;
	node->rootId = rootID;
}

void Tree::UpdataCreateTree(TStream& tstream, Test& test, TreeNode* node)
{
	queue<TreeNode*> queCreateTree;
	queCreateTree.push(node);
	HashIndex hashTemp = {};
	while (!queCreateTree.empty())
	{
		if (queCreateTree.front()->sideLength <= tstream.GetLength() / 1024 / 1024 / 1024)
		{
			hashTemp = GetHashIndex(tstream, test, *queCreateTree.front()->vecObject.begin(), queCreateTree.front()->rootId, queCreateTree.front()->grid);
			for (auto iterLstObject = hashTemp.lstObject.begin(); iterLstObject != hashTemp.lstObject.end(); iterLstObject++)
			{
				if (iterLstObject == hashTemp.lstObject.begin())
					continue;
				queCreateTree.front()->vecObject.push_back(*iterLstObject);
			}
			queCreateTree.pop();
			continue;
		}
		if (queCreateTree.front()->sideLength == queCreateTree.front()->grid.sideLength)
		{

			hashTemp = GetHashIndex(tstream, test, *queCreateTree.front()->vecObject.begin(), queCreateTree.front()->rootId, queCreateTree.front()->grid);
			for (auto iterLstObject = hashTemp.lstObject.begin(); iterLstObject != hashTemp.lstObject.end(); iterLstObject++)
			{
				if (iterLstObject == hashTemp.lstObject.begin())
					continue;
				queCreateTree.front()->vecObject.push_back(*iterLstObject);
			}
		}

		TreeNodeSplit(tstream, test, queCreateTree.front());

		for (auto iterLstPointer = queCreateTree.front()->lstPointer.begin(); iterLstPointer != queCreateTree.front()->lstPointer.end(); iterLstPointer++)
		{
			if ((*iterLstPointer)->objecNumber > NUM)
			{
				queCreateTree.push(*iterLstPointer);
			}
		}
		queCreateTree.pop();
	}
}

void Tree::UpdataTreeNodeSplit(TStream& tstream, Test& test, queue<TreeNode*>& queBatchSplit)
{
	long addr = 0;
	vector<double> newVecLeftDown;
	vector<double> newVecRightUp;
	HashIndex hashTemp = {};
	double branchNumber = pow(2, test.GetDimension());
	TreeNode* node;
	while (!queBatchSplit.empty())
	{
		node = queBatchSplit.front();
		if (queBatchSplit.front()->sideLength <= tstream.GetLength() / 1024 / 1024 / 1024)
		{
			queBatchSplit.pop();
			continue;
		}

		if (node->objecNumber > node->fatherNode->objecNumber / branchNumber && node->fatherNode->objecNumber > pow(2, test.GetDimension() + 1))
		{
			rootID = 0;
			CreateCube(tstream, test, node);
			UpdataCreateTree(tstream, test, node);
		}
		else
		{
			TreeNodeSplitUpdata(tstream, test, node);
		}
		queBatchSplit.pop();
	}
}

void Tree::UpdateDataFlow(TStream& tstream, Test& test, double& time)
{
	int newObj = test.GetWindowSize() / test.GetDimension();
	int neighbor = -1;
	double queryRadius = 0;
	double distance = 0;
	tstream.SetDataStreamTag(test.GetWindowSize() / test.GetDimension());
	tstream.SetDataStreamBegin(0);
	clock_t startTime, endTime;

	time = 0;
	for (; tstream.GetDataStreamTag() < tstream.GetDataStreamLength() / test.GetDimension(); )
	{
		double step = 0.0000001;

		tstream.AddDataStreamBegin(test.GetOutFlow());
		tstream.AddDataStreamTag(test.GetInFlow());

		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 102400 == 1)
		{
			startTime = clock();
		}
		if ((tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % 102400 == 0)
		{
			endTime = clock();
			cout << "��ǰ�α�Ϊ" << tstream.GetDataStreamTag() << "     Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
		}

		if ((tstream.GetDataStreamTag() - tstream.GetDataStreamBegin()) >= 10 * (test.GetWindowSize() / test.GetDimension()))
		{
			tstream.SetDataStreamBegin(tstream.GetDataStreamTag() - (test.GetWindowSize() / test.GetDimension()));
		}

		if ((tstream.GetDataStreamTag() - tstream.GetDataStreamBegin()) <= 0.1 * (test.GetWindowSize() / test.GetDimension()))
		{
			tstream.SetDataStreamTag(tstream.GetDataStreamBegin() + (test.GetWindowSize() / test.GetDimension()));
			if (tstream.GetDataStreamTag() > tstream.GetDataStreamLength() / test.GetDimension())
			{
				tstream.SetDataStreamTag(tstream.GetDataStreamLength() / test.GetDimension());
			}

		}

		if (tstream.GetDataStreamTag() % test.GetQueryCycle() == 0)
		{
			PrintMapCandidateSet(test, tstream.GetDataStreamBegin());
		}

		if (test.GetInFlow() == 1 && test.GetOutFlow() == 1 && (tstream.GetDataStreamTag() - test.GetWindowSize() / test.GetDimension()) % (test.GetWindowSize() / test.GetDimension() * 3 / 2) == 0)
		{
			startTime = clock();
			UpdataCandidateSet(tstream.GetDataStreamBegin());

			endTime = clock();
			time += (double)(endTime - startTime) / CLOCKS_PER_SEC;
		}

		for (int i = newObj; i < tstream.GetDataStreamTag(); i++)
		{
			queryRadius = 0;
			neighbor = -1;
			TreeNodeInsert(tstream, test, i, queryRadius);  
			neighbor = FindNeighbor(tstream, test, i, queryRadius, distance, tstream.GetDataStreamBegin());
			if (neighbor != -1)
				InsertMapCandidateSet(i, neighbor, distance);
		}
		newObj = tstream.GetDataStreamTag();
	}
}