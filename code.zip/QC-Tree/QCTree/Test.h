#pragma once
#include <vector>
#include <stdlib.h>
#include <iostream>
#pragma warning(disable:4996)��
using namespace std;
class Test
{
public:
	Test();
	~Test();
	int GetDimension();
	int GetTopK();
	int GetF();
	int GetWindowSize();
	int GetInFlow();
	int GetOutFlow();
	int GetQueryCycle();

	void SetDimension(int d);
	void SetTopK(int k);
	void SetF(int f);
	void SetWindowSize(int w);
	void SetInFlow(int in);
	void SetOutFlow(int out);
	void SetQueryCycle(int c);
	void Init(vector<Test>& vecTestFile);

private:
	int dimension = 0;			
	int topK = 0;				
	int f = 0;					
	int windowSize = 0;				
	int inFlow = 0;				
	int outFlow = 0;			
	int queryCycle = 0;			
};

