#include "Test.h"

Test::Test()
{
}

Test::~Test()
{
}

int Test::GetDimension()
{
	return dimension;
}

int Test::GetTopK()
{
	return topK;
}

int Test::GetF()
{
	return f;
}

int Test::GetWindowSize()
{
	return windowSize;
}

int Test::GetInFlow()
{
	return inFlow;
}

int Test::GetOutFlow()
{
	return outFlow;
}

int Test::GetQueryCycle()
{
	return queryCycle;
}

void Test::SetDimension(int d)
{
	dimension = d;
}

void Test::SetTopK(int k)
{
	topK = k;
}

void Test::SetF(int f1)
{
	f = f1;
}

void Test::SetWindowSize(int w)
{
	windowSize = w;
}

void Test::SetInFlow(int in)
{
	inFlow = in;
}

void Test::SetOutFlow(int out)
{
	outFlow = out;
}

void Test::SetQueryCycle(int c)
{
	queryCycle = c;
}




void Test::Init(vector<Test>& vecTestFile)
{
	Test test;
	test.SetTopK(100);
	test.SetDimension(3);
	test.SetInFlow(1);
	test.SetOutFlow(1);
	test.SetWindowSize(1048576 * 3);
	int queryCycle = 100;
	for (int i = 0; i < 7; i++)
	{
		test.SetQueryCycle(queryCycle);
		vecTestFile.push_back(test);
		queryCycle += 100;
	}

	test.SetQueryCycle(100);
	int windowsize[] = { 102400,204800, 512000,1048576,2097152,5242880,10485760 };
	for (int i = 0; i < 7; i++)
	{
		test.SetWindowSize(windowsize[i] * 3);
		vecTestFile.push_back(test);
	}

	test.SetWindowSize(1048576 * 3);
	int currentSpeed[] = { 10,1,5,1,2,1,1,1,1,2,1,5,1,10 };
	for (int i = 0; i < 7; i++)
	{
		test.SetOutFlow(currentSpeed[i * 2]);
		test.SetInFlow(currentSpeed[i * 2 + 1] );
		vecTestFile.push_back(test);
	}
	FILE* fpLog;

}
